"""
CREATURES - the roster. THE file to edit for new pets.

Each entry:
    "no":      roster number
    "type":    one of the 8 TYPES (data/types.py)
    "subtype": one of the 32 SUBTYPES - sets a stat bias, passive name and signature move
    "base":    base stats [HP, ATK, DEF, SPD]. 30 weak, 50 average, 80+ great, 100+ legendary
    "catch":   how easy to sign. 255 trivial, 45 starter, 3 legendary
    "exp":     base EXP given when beaten
    "moves":   {level: "MOVE NAME"} (level 1 = known from the start)
    "evolve":  {"level": 16, "into": "NAME"}  optional
    "tier":    power tier - PRACTICE SQUAD / WAIVER WIRE / FLEX / STARTER / FIRST-ROUNDER /
               ALL-PRO / FRANCHISE PLAYER / HALL OF FAMER / LEAGUE BREAKER
    "rarity":  COMMON / UNCOMMON / RARE / VERY RARE / UNIQUE   (how often it shows up)
    "lore":    NORMAL / FRANCHISE LINE / HALL OF FAMER / LEAGUE BREAKER
    "entry":   roster flavor text
    "palette": 4 colors (lightest..darkest) used to color the hand-drawn text-art sprite
    "png":     optional file id in sprites/creatures/ (NAME.png). If the PNG exists it is used.
    "homage":  optional note for wink/nod creatures

Adding a creature = copy a block, give it a new "no", draw or drop in a sprite,
and add it to an encounter table in data/maps.py.
"""

CREATURES = {}


def _c(name, **kw):
    kw.setdefault("rarity", "COMMON")
    kw.setdefault("lore", "NORMAL")
    CREATURES[name] = kw


# ---- FIRST-ROUNDERS (starters) ------------------------------------------
_c("PIGSKLET", no=1, type="RUSHING", subtype="BRUISER", base=[45, 52, 43, 55], catch=45, exp=64,
   moves={1: "CARRY", 4: "HOLD THE POCKET", 7: "CUTBACK", 12: "STIFF ARM", 18: "SPIN MOVE", 24: "TRUCK STICK", 32: "GOAL-LINE DIVE"},
   evolve={"level": 16, "into": "HOGBACK"}, tier="FIRST-ROUNDER", rarity="UNIQUE",
   palette=[(240, 205, 170), (196, 120, 70), (130, 65, 35), (50, 25, 15)],
   entry="A leathery little piglet. It tucks itself under one arm and refuses to be fumbled.")
_c("HOGBACK", no=2, type="RUSHING", subtype="BRUISER", base=[65, 74, 62, 68], catch=45, exp=142,
   moves={1: "CARRY", 4: "HOLD THE POCKET", 7: "CUTBACK", 12: "STIFF ARM", 20: "SPIN MOVE", 27: "TRUCK STICK", 36: "GOAL-LINE DIVE"},
   tier="STARTER", rarity="UNIQUE",
   palette=[(230, 180, 140), (170, 90, 50), (110, 45, 25), (40, 20, 10)],
   entry="Its hide hardened into full pads. It lowers its shoulder and never goes down on first contact.")
_c("AERLING", no=3, type="RECEIVER", subtype="DEEP THREAT", base=[40, 48, 40, 68], catch=45, exp=64,
   moves={1: "RELEASE", 4: "AUDIBLE", 8: "CROSSER", 13: "STUTTER STEP", 19: "TOE TAP", 25: "GO ROUTE", 33: "TAKE THE TOP OFF"},
   evolve={"level": 16, "into": "AIRHAWK"}, tier="FIRST-ROUNDER", rarity="UNIQUE",
   palette=[(235, 245, 255), (120, 180, 240), (40, 100, 190), (20, 40, 90)],
   entry="A fledgling that glides in perfect spirals. It always seems to know where the ball is going.")
_c("AIRHAWK", no=4, type="RECEIVER", subtype="DEEP THREAT", base=[60, 68, 55, 92], catch=45, exp=142,
   moves={1: "RELEASE", 4: "AUDIBLE", 8: "CROSSER", 13: "STUTTER STEP", 21: "TOE TAP", 28: "GO ROUTE", 37: "TAKE THE TOP OFF"},
   tier="STARTER", rarity="UNIQUE",
   palette=[(250, 240, 200), (90, 150, 230), (30, 80, 170), (15, 30, 80)],
   entry="Its wingspan covers half the field. Defenders look up and it is already gone.")
_c("TURFLING", no=5, type="O-LINE", subtype="BRICK WALL", base=[55, 45, 60, 35], catch=45, exp=64,
   moves={1: "CHIP BLOCK", 4: "HOLD THE POCKET", 8: "DOUBLE TEAM", 13: "BRACE", 19: "PANCAKE", 26: "NO PRESSURE", 34: "FINISH THE BLOCK"},
   evolve={"level": 16, "into": "SODWALL"}, tier="FIRST-ROUNDER", rarity="UNIQUE",
   palette=[(190, 235, 120), (100, 180, 70), (50, 110, 45), (60, 40, 20)],
   entry="A clump of living turf with a stubborn streak. It digs in and simply will not be moved.")
_c("SODWALL", no=6, type="O-LINE", subtype="BRICK WALL", base=[80, 62, 90, 42], catch=45, exp=142,
   moves={1: "CHIP BLOCK", 4: "HOLD THE POCKET", 8: "DOUBLE TEAM", 13: "BRACE", 22: "PANCAKE", 29: "NO PRESSURE", 38: "FINISH THE BLOCK"},
   tier="STARTER", rarity="UNIQUE",
   palette=[(170, 220, 100), (80, 160, 60), (40, 95, 40), (55, 35, 15)],
   entry="A rolling wall of sod and roots. Entire defensive fronts have bounced off it.")

# ---- ROUTE WILDLIFE ------------------------------------------------------
_c("REFBIT", no=7, type="O-LINE", subtype="LEAD BLOCK", base=[35, 38, 40, 60], catch=255, exp=40,
   moves={1: "CHIP BLOCK", 6: "AUDIBLE", 11: "PULLING GUARD", 17: "BRACE", 23: "LEAD THROUGH"},
   tier="PRACTICE SQUAD",
   palette=[(250, 250, 250), (170, 170, 170), (70, 70, 70), (20, 20, 20)],
   entry="A striped rabbit that blows a whistle when startled. Nobody has ever seen it throw a flag.")
_c("CLEATLE", no=8, type="O-LINE", subtype="ANCHOR", base=[40, 50, 50, 38], catch=200, exp=48,
   moves={1: "CHIP BLOCK", 5: "HOLD THE POCKET", 10: "DOUBLE TEAM", 16: "SET THE POCKET", 22: "PANCAKE"},
   tier="WAIVER WIRE",
   palette=[(220, 225, 230), (140, 150, 165), (75, 85, 100), (25, 30, 40)],
   entry="A beetle with studded legs. The clicking of its cleats on concrete carries for miles.")
_c("WHISTLET", no=9, type="SPECIALIST", subtype="PUNTER", base=[32, 40, 30, 72], catch=220, exp=44,
   moves={1: "PUNT", 5: "WHISTLE", 9: "ONSIDE KICK", 15: "COFFIN CORNER", 21: "FIELD GOAL"},
   tier="PRACTICE SQUAD",
   palette=[(255, 250, 200), (240, 200, 60), (160, 120, 30), (60, 45, 10)],
   entry="A tiny bird with a shrill call. Flocks of them circle the field before every kickoff.")
_c("PYLONK", no=10, type="D-LINE", subtype="IMMOVABLE OBJECT", base=[50, 35, 68, 18], catch=180, exp=52,
   moves={1: "BULL RUSH", 6: "TWO-GAP", 12: "NOT AN INCH", 18: "SACK", 26: "EAT THE DOUBLE"},
   tier="FLEX", rarity="UNCOMMON",
   palette=[(255, 200, 120), (245, 120, 30), (170, 70, 15), (60, 30, 10)],
   entry="It stands perfectly still at the corner of the end zone. Touch it and the whole play is over.")
_c("CHALKAT", no=11, type="PASSING", subtype="FIELD GENERAL", base=[38, 45, 32, 65], catch=150, exp=56,
   moves={1: "SCREEN PASS", 7: "AUDIBLE", 12: "SLANT", 18: "CHECK WITH ME", 25: "PLAY ACTION"},
   tier="FLEX", rarity="UNCOMMON",
   palette=[(255, 255, 255), (200, 170, 230), (120, 80, 170), (50, 25, 80)],
   entry="A cat drawn in yard-line chalk. It smudges itself to dodge, then redraws its own whiskers.")
_c("TACKLEON", no=12, type="LINEBACKER", subtype="COVERAGE", base=[45, 58, 42, 55], catch=120, exp=66,
   moves={1: "RUN FIT", 6: "SPY", 11: "WRAP UP", 17: "CARRY THE SEAM", 24: "A-GAP BLITZ"},
   tier="FLEX", rarity="UNCOMMON",
   palette=[(190, 230, 170), (90, 170, 100), (40, 100, 70), (20, 40, 35)],
   entry="A chameleon that matches the color of the opposing jersey right before it pounces.")
_c("KICKOON", no=13, type="SPECIALIST", subtype="KICKER", base=[42, 48, 40, 55], catch=140, exp=60,
   moves={1: "PUNT", 6: "ONSIDE KICK", 11: "SQUIB KICK", 16: "FIELD GOAL", 23: "WALK-OFF"},
   tier="FLEX", rarity="UNCOMMON",
   palette=[(240, 230, 200), (200, 160, 60), (110, 90, 50), (40, 30, 20)],
   entry="A raccoon with one oversized hind leg. It has never once hit the net on a practice kick.")
_c("BLITZARD", no=14, type="D-LINE", subtype="SACK ARTIST", base=[48, 68, 44, 64], catch=90, exp=78,
   moves={1: "BULL RUSH", 5: "ONSIDE KICK", 9: "STUNT", 14: "SWIM MOVE", 20: "SACK", 28: "STRIP SACK"},
   tier="STARTER", rarity="RARE",
   palette=[(225, 245, 255), (120, 190, 230), (40, 90, 150), (15, 35, 70)],
   entry="A frost-scaled lizard that comes off the edge like a snowstorm. Quarterbacks fear the cold.")
_c("UPRIGHT", no=15, type="SPECIALIST", subtype="KICKER", base=[70, 55, 82, 25], catch=30, exp=120,
   moves={1: "PUNT", 8: "HOLD THE POCKET", 14: "FIELD GOAL", 20: "PANCAKE", 30: "WALK-OFF"},
   tier="ALL-PRO", rarity="VERY RARE",
   palette=[(255, 255, 210), (250, 220, 60), (180, 150, 30), (70, 55, 15)],
   entry="A towering goalpost that walked off the field one night. Very rare. Very yellow.")

# ---- STADIUM LOT (concept-board creatures, real PNG art) ----------------
_c("BELLCOW", no=16, type="RUSHING", subtype="BELL-COW", base=[80, 78, 68, 45], catch=60, exp=150,
   moves={1: "CARRY", 6: "STIFF ARM", 12: "HOLD THE POCKET", 18: "FEED ME", 26: "TRUCK STICK", 34: "GOAL-LINE DIVE"},
   tier="STARTER", rarity="UNCOMMON", png="BELLCOW",
   palette=[(240, 200, 150), (180, 110, 60), (120, 60, 30), (40, 20, 10)],
   entry="Gets the work. Every week. Everywhere. Twenty-five carries and it asks for more.")
_c("WAIVERN", no=17, type="DEFENSIVE BACK", subtype="BALL HAWK", base=[55, 68, 50, 82], catch=45, exp=165,
   moves={1: "JAM", 7: "CENTER FIELD", 13: "STRIP", 19: "BALL HAWK", 27: "PICK SIX", 35: "TAKE THE TOP OFF"},
   tier="ALL-PRO", rarity="RARE", png="WAIVERN",
   palette=[(220, 230, 200), (110, 170, 110), (50, 110, 70), (25, 45, 35)],
   entry="Feeds on opportunity. Its wings are made of waiver claims nobody else bothered to file.")
_c("LOCKDOWN", no=18, type="DEFENSIVE BACK", subtype="SHUT DOWN", base=[60, 62, 75, 85], catch=45, exp=170,
   moves={1: "JAM", 6: "PRESS MAN", 12: "CENTER FIELD", 18: "ERASE", 25: "BALL HAWK", 33: "BIG HIT"},
   tier="ALL-PRO", rarity="RARE", png="LOCKDOWN",
   palette=[(200, 210, 230), (90, 110, 160), (40, 55, 110), (15, 20, 50)],
   entry="Shuts it down. No easy yards. Receivers come back to the huddle without a word.")
_c("CHAINGEIST", no=19, type="SPECIALIST", subtype="PUNTER", base=[58, 50, 60, 70], catch=70, exp=140,
   moves={1: "PUNT", 6: "WHISTLE", 12: "COFFIN CORNER", 18: "SQUIB KICK", 24: "FAKE INJURY", 32: "HOUSE CALL"},
   tier="STARTER", rarity="UNCOMMON", png="CHAINGEIST",
   palette=[(240, 235, 255), (180, 160, 230), (100, 80, 170), (40, 25, 80)],
   entry="Always watching the line. Knows what down it is. Nobody remembers hiring it.")
_c("BOOMBUST", no=20, type="PASSING", subtype="GUNSLINGER", base=[52, 70, 45, 62], catch=100, exp=130,
   moves={1: "SCREEN PASS", 5: "PLAY ACTION", 11: "SLANT", 17: "HERO BALL", 24: "DEEP BALL", 32: "HAIL MARY"},
   tier="FLEX", rarity="UNCOMMON", png="BOOMBUST",
   palette=[(255, 230, 120), (240, 140, 40), (60, 90, 160), (30, 30, 60)],
   entry="Huge upside. Also huge downside. Start it and pray.")
_c("SACKOLITH", no=21, type="D-LINE", subtype="IMMOVABLE OBJECT", base=[95, 70, 95, 20], catch=8, exp=260,
   moves={1: "BULL RUSH", 2: "TWO-GAP", 10: "NOT AN INCH", 20: "SACK", 30: "COLLAPSE POCKET", 40: "EAT THE DOUBLE"},
   tier="HALL OF FAMER", rarity="UNIQUE", lore="HALL OF FAMER", png="SACKOLITH",
   palette=[(220, 200, 240), (150, 120, 180), (80, 60, 110), (30, 20, 45)],
   entry="Carries the weight of last place. And more. The plaque is crooked on purpose.")

# ---- LEAGUE LEGENDS (homage creatures) -----------------------------------
_c("TOM_GOAT", no=22, type="PASSING", subtype="FIELD GENERAL", base=[95, 100, 85, 80], catch=3, exp=340,
   moves={1: "SLANT", 2: "AUDIBLE", 15: "CHECK WITH ME", 25: "PLAY ACTION", 35: "DEEP BALL", 45: "HAIL MARY"},
   tier="LEAGUE BREAKER", rarity="UNIQUE", lore="LEAGUE BREAKER", png="TOM_GOAT", homage="the QB GOAT, #12",
   palette=[(250, 250, 250), (200, 200, 210), (120, 40, 40), (30, 30, 50)],
   entry="Climbs every mountain. Finds a way. Seven rings hang from its horns.")
_c("RICEIVER", no=23, type="RECEIVER", subtype="ALPHA", base=[85, 105, 70, 110], catch=3, exp=340,
   moves={1: "RELEASE", 2: "STUTTER STEP", 15: "CROSSER", 25: "MOSSED", 35: "TAKE THE TOP OFF", 45: "GO ROUTE"},
   tier="LEAGUE BREAKER", rarity="UNIQUE", lore="LEAGUE BREAKER", png="RICEIVER", homage="the all-time receiver, #80",
   palette=[(255, 240, 200), (230, 60, 50), (170, 120, 30), (60, 20, 20)],
   entry="Catches everything. Still open. Working name - Bobbie decides what it's called.")
_c("AD18N", no=24, type="RUSHING", subtype="BELL-COW", base=[90, 100, 70, 70], catch=5, exp=300,
   moves={1: "CARRY", 2: "STIFF ARM", 15: "FEED ME", 25: "TRUCK STICK", 35: "SPIN MOVE", 45: "GOAL-LINE DIVE"},
   tier="HALL OF FAMER", rarity="UNIQUE", lore="HALL OF FAMER", png="AD18N", homage="the workhorse, #28",
   palette=[(230, 200, 255), (150, 90, 220), (80, 40, 140), (30, 15, 60)],
   entry="All day. Every day. Till the clock runs out. The smoke is not a special effect.")
_c("JOE_BURROWL", no=25, type="PASSING", subtype="SNIPER", base=[75, 90, 65, 85], catch=15, exp=230,
   moves={1: "SCREEN PASS", 2: "SLANT", 12: "PLAY ACTION", 20: "BACK-SHOULDER DART", 30: "DEEP BALL", 42: "HAIL MARY"},
   tier="FRANCHISE PLAYER", rarity="VERY RARE", lore="FRANCHISE LINE", png="JOE_BURROWL", homage="the cool franchise QB, #9",
   palette=[(255, 220, 160), (245, 130, 30), (60, 60, 60), (20, 20, 20)],
   entry="Ice in his veins. Finds his targets. Wears the cape indoors.")

DISPLAY_NAMES = {"TOM_GOAT": "TOM GOAT", "JOE_BURROWL": "JOE BURROWL"}


def get(name):
    return CREATURES[name]


def display_name(name):
    return DISPLAY_NAMES.get(name, name)


def by_number():
    return sorted(CREATURES.items(), key=lambda kv: kv[1]["no"])
