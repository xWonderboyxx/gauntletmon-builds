"""
Graphics helpers: the 320x180 canvas (16:9, six times into 1080p), color palettes, pixel-art
decoding, PNG sprite loading, bitmap text, and the framed UI boxes.

Pixel art format (data/sprites.py): a list of equal-length strings, one
character per pixel. '.' = transparent; other characters are looked up in a
palette. The classic 4-shade art uses '0' (lightest) .. '3' (darkest);
people also use '4' (hair) and '5' (shirt).
"""
import os
import pygame
import settings
from engine import font

W, H = 320, 180        # 16:9 - scales x6 to 1920x1080 exactly
TRANSPARENT = (255, 0, 255)  # "magic pink", never shown

# League UI theme (from the scoreboard branding)
UI = {
    "paper": (247, 240, 222),
    "light": (205, 210, 222),
    "mid": (96, 112, 150),
    "ink": (18, 24, 44),
    "navy": (7, 8, 13),
    "cobalt": (36, 88, 255),
    "red": (230, 56, 47),
    "gold": (247, 202, 32),
    "white": (255, 255, 255),
    "green": (70, 190, 90),
    "yellow": (240, 200, 40),
    "sky": (200, 226, 240),
    "field": (96, 176, 72),
}
_RAMP = [UI["paper"], UI["light"], UI["mid"], UI["ink"]]

GAME_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SPRITE_DIR = os.path.join(GAME_DIR, "sprites")

_art_cache = {}
_png_cache = {}


def shade(i):
    """UI ramp: 0 paper .. 3 ink. Accepts an RGB tuple and passes it through."""
    if isinstance(i, tuple):
        return i
    return _RAMP[max(0, min(3, i))]


def new_surface(w, h, transparent=True):
    s = pygame.Surface((w, h))
    if transparent:
        s.fill(TRANSPARENT)
        s.set_colorkey(TRANSPARENT)
    return s


def art(rows, palette=None, mirror=False, scale=1, key=None):
    """Turn pixel-art strings into a Surface (cached by key).
    palette: list of 4 colors (for '0'..'3') or a dict {char: color}."""
    cache_key = (key or id(rows), mirror, scale, id(palette) if palette is not None else None)
    if cache_key in _art_cache:
        return _art_cache[cache_key]
    if palette is None:
        palette = _RAMP
    if isinstance(palette, (list, tuple)):
        palette = {str(i): c for i, c in enumerate(palette)}
    h = len(rows)
    w = max(len(r) for r in rows)
    s = new_surface(w, h)
    for y, row in enumerate(rows):
        for x, ch in enumerate(row):
            c = palette.get(ch)
            if c is not None:
                s.set_at((x, y), c)
    if mirror:
        s = pygame.transform.flip(s, True, False)
        s.set_colorkey(TRANSPARENT)
    if scale != 1:
        s = pygame.transform.scale(s, (w * scale, h * scale))
        s.set_colorkey(TRANSPARENT)
    _art_cache[cache_key] = s
    return s


def png(kind, name, size=None, mirror=False):
    """Load sprites/<kind>/<name>.png if it exists (cached), else None."""
    key = (kind, name, size, mirror)
    if key in _png_cache:
        return _png_cache[key]
    path = os.path.join(SPRITE_DIR, kind, name + ".png")
    surf = None
    if os.path.exists(path):
        try:
            surf = pygame.image.load(path).convert_alpha()
            if size and surf.get_size() != (size, size):
                surf = pygame.transform.scale(surf, (size, size))
            if mirror:
                surf = pygame.transform.flip(surf, True, False)
        except Exception as e:      # a bad PNG should never crash the game
            print("could not load", path, e)
            surf = None
    _png_cache[key] = surf
    return surf


def creature_sprite(species, size=80, mirror=False):
    """The battle sprite for a species: its PNG if present, else its colored text art."""
    from data import creatures, sprites
    d = creatures.get(species)
    s = png("creatures", d.get("png", species), size, mirror)
    if s is not None:
        return s
    rows = sprites.CREATURES.get(species)
    if rows is None:
        rows = sprites.CREATURES["REFBIT"]
    scale = max(1, size // len(rows))
    pal = d.get("palette")
    inner = art(rows, palette=pal, mirror=mirror, scale=scale, key="C" + species)
    if inner.get_width() == size:
        return inner
    # center the art inside a size x size box so layout is consistent
    key = ("box", species, size, mirror)
    if key not in _art_cache:
        box_s = new_surface(size, size)
        box_s.blit(inner, ((size - inner.get_width()) // 2, size - inner.get_height()))
        _art_cache[key] = box_s
    return _art_cache[key]


def clear_art_cache():
    _art_cache.clear()
    _png_cache.clear()


# --- text -------------------------------------------------------------------

_glyph_cache = {}


def _glyph_surface(ch, color):
    k = (ch, color)
    if k not in _glyph_cache:
        rows = font.glyph(ch)
        s = new_surface(font.GLYPH_W, font.GLYPH_H)
        for y, row in enumerate(rows):
            for x, c in enumerate(row):
                if c == "#":
                    s.set_at((x, y), color)
        _glyph_cache[k] = s
    return _glyph_cache[k]


def text(surf, x, y, s, ink=3):
    """Draw a string at (x, y). ink = UI ramp index or an RGB tuple."""
    color = shade(ink)
    for ch in s:
        if ch != " ":
            surf.blit(_glyph_surface(ch, color), (x, y))
        x += font.ADVANCE
    return x


def text_right(surf, right_x, y, s, ink=3):
    text(surf, right_x - font.text_width(s), y, s, ink)


def text_center(surf, cx, y, s, ink=3):
    text(surf, cx - font.text_width(s) // 2, y, s, ink)


def wrap(s, max_chars):
    lines, cur = [], ""
    for word in s.split(" "):
        if not cur:
            cur = word
        elif len(cur) + 1 + len(word) <= max_chars:
            cur += " " + word
        else:
            lines.append(cur)
            cur = word
    if cur:
        lines.append(cur)
    return lines


# --- boxes ------------------------------------------------------------------

def box(surf, x, y, w, h, fill=True, color=None):
    """Framed panel: paper fill, dark double border (league navy)."""
    ink = UI["ink"]
    if fill:
        surf.fill(color or UI["paper"], (x, y, w, h))
    pygame.draw.rect(surf, ink, (x + 1, y + 1, w - 2, h - 2), 1)
    pygame.draw.rect(surf, UI["mid"], (x + 3, y + 3, w - 6, h - 6), 1)
    for cx, cy in ((x + 2, y + 2), (x + w - 3, y + 2), (x + 2, y + h - 3), (x + w - 3, y + h - 3)):
        surf.set_at((cx, cy), ink)


def bar(surf, x, y, w, frac, thickness=2, kind="hp"):
    """A stat bar. HP bars go green -> yellow -> red; EXP bars are cobalt."""
    frac = max(0.0, min(1.0, frac))
    surf.fill(UI["ink"], (x, y, w, thickness + 2))
    surf.fill(UI["light"], (x + 1, y + 1, w - 2, thickness))
    filled = int(round((w - 2) * frac))
    if filled > 0:
        if kind == "hp":
            color = UI["green"] if frac > 0.5 else (UI["yellow"] if frac > 0.2 else UI["red"])
        else:
            color = UI["cobalt"]
        surf.fill(color, (x + 1, y + 1, filled, thickness))


def hp_bar(surf, x, y, w, hp, max_hp):
    text(surf, x - 13, y - 1, "HP", UI["ink"])
    bar(surf, x, y, w, hp / max_hp if max_hp else 0)


def type_badge(surf, x, y, type_name, w=None):
    """Small colored tag with the short type name in white."""
    from data import types
    label = types.SHORT.get(type_name, type_name[:6])
    w = w or font.text_width(label) + 6
    surf.fill(UI["ink"], (x, y, w, 10))
    surf.fill(types.COLORS.get(type_name, UI["mid"]), (x + 1, y + 1, w - 2, 8))
    text(surf, x + 3, y + 1, label, UI["white"])
    return w


# --- transitions --------------------------------------------------------------

def fade_step(surf, step):
    if step <= 0:
        return
    overlay = pygame.Surface((W, H))
    overlay.fill(UI["navy"])
    overlay.set_alpha(min(255, step * 85))
    surf.blit(overlay, (0, 0))
