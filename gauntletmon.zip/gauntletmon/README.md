# GAUNTLET MON — Gridiron Gauntlet Edition (v0.3)

A GBA-style monster-catching RPG for your Raspberry Pi, built on the real
mythology of the Gridiron Gauntlet league. Version 0.2 — "The Gauntlet":

- Full color at Game Boy Advance resolution (240x160), league-branded UI
- The 8-type football system (O-LINE, RUSHING, PASSING, LINEBACKER, D-LINE,
  DEFENSIVE BACK, RECEIVER, SPECIALIST) with the 8x8 effectiveness chart,
  1.25x Scheme Fit and 1.5x crits — straight from the rules workbook
- All 8 type passives implemented (Pocket Wall, Momentum, Read the Defense,
  Read & React, Pocket Collapse, Coverage, Separation, Clutch Window)
- 32 subtypes as data: each sets a stat bias, a passive name and a signature move
- 25 creatures: the original 15 (re-typed) plus the 10 concept-board
  creatures as real full-color sprites (BELLCOW, WAIVERN, LOCKDOWN,
  CHAINGEIST, BOOMBUST, SACKOLITH, TOM GOAT, RICEIVER, AD18N, JOE BURROWL)
- Rarity, power tier and lore class on every creature (shown in the ROSTER)
- 76 moves, including every subtype's signature move
- TRAINER BATTLES: the 11 league owners as a gauntlet across three stadium
  maps, each with their real team name, personality, party and prize money.
  They spot you from four tiles away. Beat PETE for the trophy.
- Sprite pipeline: drop `NAME.png` into `sprites/creatures/` and the game
  uses it automatically (magenta or transparent background, any size)

v0.3 additions:
- Real art for 20 of the 25 creatures (cut from the approved boards); the
  five still hand-drawn are CLEATLE, WHISTLET, PYLONK, CHALKAT, TACKLEON
- VS screen before every owner battle with the owner's sprite, team and party
- Football-shaped CONTRACT throw animation
- 14 subtype passives live (at least one per type); MOMENTUM stacks shown
- Battle backdrops change by area (field, lot, concourse, night stadium)
- Spruced-up village, route and stadium tiles
- EasySMX X15 controller mapping (PC/Xbox mode on the 2.4GHz dongle), hot-plug

## Controls

| Game Boy | Keyboard          | USB gamepad         |
|----------|-------------------|---------------------|
| D-pad    | Arrow keys / WASD | D-pad / left stick  |
| A        | Z (or Enter/Space)| A                   |
| B        | X (or Backspace)  | B or X              |
| START    | Esc (or Tab)      | Start or Back       |

Controller: plug the X15's 2.4GHz dongle into the Pi (PC/Xbox mode - the
default). It works whether you plug it in before or after launching. If a
button is off, `python3 ~/gauntletmon/main.py --debug-pad` prints the button
numbers and `settings.py` maps them.

Hold A or B while text is printing to speed it up. Press B on a menu to back
out. START opens the menu (TEAM / BAG / ROSTER / SAVE / QUIT).

## Install on the Pi (one time)

From your Windows PC, in PowerShell, with `gauntletmon.zip` in Downloads:

```powershell
scp "$env:USERPROFILE\Downloads\gauntletmon.zip" bobbie@gauntlet-pi.local:~
ssh bobbie@gauntlet-pi.local
```

Then on the Pi:

```bash
cd ~ && unzip -o gauntletmon.zip && bash gauntletmon/install.sh
```

That installs Pygame and puts a **Gauntlet Mon** icon on the Pi desktop.
Your scoreboard kiosk is untouched — nothing about boot changes.

## Play

1. On the Pi (with a keyboard plugged in) press **Alt+F4** to leave the scoreboard.
2. Double-click **Gauntlet Mon** on the desktop. It runs full-screen on the TV.
3. To get back to the scoreboard, just reboot (or run the kiosk from the menu).

From a terminal on the Pi you can also run `~/gauntletmon/play.sh`, or
`python3 ~/gauntletmon/main.py` for a window instead of full-screen.

## Updating to a new version

Copy the new zip over the same way and re-run the `unzip` line. Your save
lives in `gauntletmon/saves/save.json` and is kept. (Delete that file to
start fresh — the title screen then only offers NEW GAME.)

## Changing things

See **CUSTOMIZING.md**. Everything — creatures, moves, maps, sprites, shop
prices, palette — is plain text in the `data/` folder and `settings.py`.
