#!/bin/bash
# GAUNTLET MON - one-time setup on the Raspberry Pi.
# Installs Pygame and puts a "Gauntlet Mon" icon on the desktop. Safe to re-run.
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"

echo "==> Installing Pygame (the graphics library the game uses)..."
sudo apt-get update -qq
sudo apt-get install -y -qq python3-pygame unzip

echo "==> Making the launcher scripts runnable..."
chmod +x "$HERE/play.sh" "$HERE/main.py"

echo "==> Creating a desktop icon..."
mkdir -p "$HOME/Desktop"
cat > "$HOME/Desktop/gauntletmon.desktop" <<DESK
[Desktop Entry]
Type=Application
Name=Gauntlet Mon
Comment=Catch 'em, sign 'em, start 'em
Exec=$HERE/play.sh
Path=$HERE
Terminal=false
Icon=input-gaming
Categories=Game;
DESK
chmod +x "$HOME/Desktop/gauntletmon.desktop"

echo
echo "All set! To play:"
echo "  - On the Pi's desktop (after Alt+F4 out of the scoreboard): double-click 'Gauntlet Mon'"
echo "  - Or from a terminal on the Pi:  $HERE/play.sh"
echo "Controls: arrows = move, Z = confirm (A), X = cancel/run (B), ESC = menu (START)."
