"""
TRAINERS - the Gridiron Gauntlet league owners as opponents.

Each trainer:
    "name":   shown in battle ("TREVOR wants to battle!")
    "team":   their real fantasy team name
    "title":  one-line role used in dialogue boxes
    "party":  [[creature, level], ...]  (up to 6)
    "intro":  what they say when the battle starts
    "win":    what they say when YOU win
    "lose":   what they say when you lose
    "after":  what they say when you talk to them after beating them
    "prize":  cash you get for winning
    "look":   overworld sprite colors {"hair": (r,g,b), "shirt": (r,g,b)}

The order in GAUNTLET is the order you face them on the Stadium path.
"""

TRAINERS = {
    "TREVOR": {
        "name": "TREVOR", "team": "Trev's Terrible Team", "title": "The Self-Aware King",
        "party": [["REFBIT", 7], ["WHISTLET", 8]], "prize": 300,
        "look": {"hair": (200, 150, 60), "shirt": (60, 170, 90)},
        "intro": "TREVOR: 2 and 12 last year! Anyway, it can't get worse. Let's go!",
        "win": "TREVOR: Called it. That's my whole brand.",
        "lose": "TREVOR: Wait... I WON? Somebody screenshot this!",
        "after": "TREVOR: I named the team TERRIBLE for a reason. Good luck up there.",
    },
    "HAMPTON": {
        "name": "HAMPTON", "team": "Don't Call it A Comeback", "title": "The Underdog",
        "party": [["CLEATLE", 10], ["KICKOON", 11]], "prize": 450,
        "look": {"hair": (60, 40, 30), "shirt": (220, 60, 50)},
        "intro": "HAMPTON: Don't call it a comeback. I've been here for... two years.",
        "win": "HAMPTON: Fine. But the comeback starts NEXT week.",
        "lose": "HAMPTON: THAT'S a comeback!",
        "after": "HAMPTON: I dropped HERBERT once. 326 points after. Don't talk to me about it.",
    },
    "BROOKS": {
        "name": "BROOKS", "team": "Your moms Favorite team", "title": "The Riverboat Gambler",
        "party": [["BOOMBUST", 13], ["CHALKAT", 12]], "prize": 600,
        "look": {"hair": (120, 70, 30), "shirt": (230, 120, 30)},
        "intro": "BROOKS: HOLD ON. CAN'T PAUSE IT, IT'S ONLINE. ...okay. Okay! Before we start - I'll give you two REFBITS for your starter. No? Fine. LET'S GO!",
        "win": "BROOKS: Ugh. LAG. That was lag. I'm calling Mom about the internet.",
        "lose": 'BROOKS: BOOM! Just like the BARKLEY trade! Which was FAIR, by the way. Dad needed a starter.',
        "after": "BROOKS: Shots at the draft. All of us. I'm not asking. ...Also, Mountain Dew's in the fridge.",
    },
    "KENNY": {
        "name": "KENNY", "team": "HurtsRentalCar", "title": "The Cursed One",
        "party": [["PYLONK", 14], ["SACKOLITH", 15]], "prize": 750,
        "look": {"hair": (40, 40, 40), "shirt": (50, 130, 70)},
        "intro": "KENNY: Oh - hey! Is the party HERE? Nobody told me. ...Anyway. Three SACKOS. The curse chose me. Let's see if it likes you.",
        "win": "KENNY: Yep. That's about how my stuff goes. Bad luck. Every time.",
        "lose": 'KENNY: WAIT. Did I just WIN? Somebody tell PENNY!',
        "after": "KENNY: My birthday's November 22nd. Nobody remembers. It's 'too close to Thanksgiving.' Twenty years of that.",
    },
    "BOB": {
        "name": "BOB", "team": "Team I drink alone", "title": "The Fallen Legend",
        "party": [["BLITZARD", 16], ["TACKLEON", 17], ["AD18N", 17]], "prize": 900,
        "look": {"hair": (110, 110, 110), "shirt": (90, 40, 130)},
        "intro": "BIG BOB: Hang on, son. How do I get the game on this TV? ...There. 367.9 points. One week. That record's MINE. Let's go.",
        "win": "BIG BOB: I'd have won if my guy hadn't got hurt. Every time. Every dang time.",
        "lose": "BIG BOB: THAT'S A STEAL! See? Told ya. Grab me a PABST.",
        "after": "BIG BOB: Your brother traded me a hurt BARKLEY for JAYLEN WARREN. 'Fair', he says. Cut the sleeves off that shirt, it looks better.",
    },
    "MARK": {
        "name": "MARK", "team": "lets drink a beer", "title": "The Dropper",
        "party": [["BELLCOW", 20], ["WHISTLET", 18]], "prize": 1000,
        "look": {"hair": (180, 130, 60), "shirt": (40, 110, 60)},
        "intro": "MARK: Bob! Yeah, I'm about to play your boy. Gators look good this year? ...Sorry. I cut JOSH ALLEN once. I'll cut you too. Let's drink a beer after.",
        "win": "MARK: Bad luck. That's all that was. Bad luck and bad refs.",
        "lose": "MARK: See? I just LIKED that one. Didn't need the rankings.",
        "after": "MARK: Allen, Tannehill, Carr. Dropped 'em all. STEVIE! Stop drinking, we're leaving.",
    },
    "JONATHAN": {
        "name": "JONATHAN", "team": "Lights KamaraAction", "title": "The Wildcard",
        "party": [["CHAINGEIST", 22], ["WAIVERN", 23], ["KICKOON", 21]], "prize": 1200,
        "look": {"hair": (30, 30, 30), "shirt": (20, 20, 20)},
        "intro": "JONATHAN: Champion in 2017. Sacko twice. Which one shows up today? Lights, camera...",
        "win": "JONATHAN: ...cut. That was the Sacko version.",
        "lose": "JONATHAN: ACTION! That's the champion version!",
        "after": "JONATHAN: Plucked HURTS off waivers for 416 points. The wire is my kingdom.",
    },
    "LOUIS": {
        "name": "LOUIS", "team": "My Dak's Bigger", "title": "The Chaotic Veteran",
        "party": [["HOGBACK", 26], ["BOOMBUST", 25], ["UPRIGHT", 24]], "prize": 1400,
        "look": {"hair": (60, 40, 30), "shirt": (30, 50, 110)},
        "intro": "LOUIS: Back-to-back champ. Also a SACKO. I've seen the top AND the bottom. Bring it!",
        "win": "LOUIS: Whatever. My Dak's still bigger.",
        "lose": "LOUIS: HA! Just like 2021 and 2022!",
        "after": "LOUIS: BAKER off waivers, 509 points. Then I named the team after DAK anyway.",
    },
    "ALAN": {
        "name": "ALAN", "team": "Almighty Shakezulas", "title": "The Tragic Tactician",
        "party": [["LOCKDOWN", 29], ["AIRHAWK", 28], ["CHALKAT", 27]], "prize": 1600,
        "look": {"hair": (80, 50, 30), "shirt": (200, 40, 40)},
        "intro": "ALAN: Best draft pick in league history. Best waiver pickup ever. Zero rings. Explain that.",
        "win": "ALAN: Perfect moves. No crown. Story of my life.",
        "lose": "ALAN: The math finally worked out!",
        "after": "ALAN: MAHOMES in round 3. Plus 283. And I still own your uncle 11-5.",
    },
    "ERIC": {
        "name": "ERIC", "team": "Team Pack Rat", "title": "The Rival",
        "party": [["WAIVERN", 31], ["SODWALL", 30], ["JOE_BURROWL", 33]], "prize": 2000,
        "look": {"hair": (200, 170, 90), "shirt": (60, 60, 70)},
        "intro": "ERIC: Three titles. Same as PETE. Same. As. PETE. Nobody talks about the hat. Let's go, McCAFFREY.",
        "win": "ERIC: Whatever. Tiebreakers. It's always TIEBREAKERS.",
        "lose": "ERIC: Dynasty. Say it. And say something about the HAT while you're at it.",
        "after": "ERIC: I've had McCAFFREY since the BEGINNING. Ask PETE who the real leader is. Actually don't.",
    },
    "PETE": {
        "name": "PETE", "team": "TEAM PETERADI", "title": "The G.O.A.T.",
        "party": [["LOCKDOWN", 34], ["BELLCOW", 35], ["RICEIVER", 36], ["TOM_GOAT", 38]], "prize": 5000,
        "look": {"hair": (30, 30, 30), "shirt": (230, 190, 40)},
        "intro": "PETE: ...Where do I put these drinks? ...Right. 13 and 1. Look, it's not FAIR you have to keep losing to me. I feel bad. Truly. Let's get it over with.",
        "win": "PETE: Huh. Well. Good for you. Really. ...Don't tell PENNY I said that.",
        "lose": "PETE: I did feel bad about that. For what it's worth. Same time next year?",
        "after": "PETE: Only YOU call me PETERADI. Everyone else says Pete. Everyone. ...Go find PENNY, she's got food.",
    },
}

# The order you face them on the Stadium path.
GAUNTLET = ["TREVOR", "HAMPTON", "BROOKS", "KENNY", "BOB", "MARK", "JONATHAN", "LOUIS", "ALAN", "ERIC", "PETE"]

# Retired legends - not yet placed in the world (next update).
LEGENDS = {
    "DONNA": {"team": "Julio Think You Are", "note": "back-to-back champ 2015-16, retired undefeated in spirit"},
    "SISTRUNK": {"team": "Teddy's Bulgewater", "note": "inaugural 2013 champion who vanished"},
    "KNAFELC": {"team": "-", "note": "drafted Mahomes round 13 in 2018 (+215), never won"},
}


def get(name):
    return TRAINERS[name]
