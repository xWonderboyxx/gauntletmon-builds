"""
Ties everything together: title screen -> overworld <-> battles / start menu.
"""
import pygame
import settings
from engine import gfx, ui, font, save
from engine.overworld import Overworld
from engine.battle import Battle
from engine.menus import StartMenu
from data import sprites, types


class Game:
    def __init__(self):
        self.canvas = pygame.Surface((gfx.W, gfx.H))
        self.state = "title"
        self.player = None
        self.world = None
        self.battle = None
        self.menu = None
        self.frame = 0
        self.fade = 0            # >0 while a screen transition plays
        self.fade_dir = 0
        self.after_fade = None
        self.title_menu = ui.Menu(["CONTINUE", "NEW GAME"] if save.save_exists() else ["NEW GAME"],
                                  76, 98, 88, cancel=False)
        self.quit = False

    # --- transitions --------------------------------------------------------
    def flash_transition(self, then=None):
        """Quick fade out/in (doors, battle start)."""
        self.fade, self.fade_dir, self.after_fade = 1, 1, then

    def _update_fade(self):
        self.fade += self.fade_dir
        if self.fade >= 6:
            self.fade_dir = -1
            if self.after_fade:
                cb, self.after_fade = self.after_fade, None
                cb()
        if self.fade <= 0:
            self.fade, self.fade_dir = 0, 0

    # --- state changes -------------------------------------------------------
    def new_game(self):
        self.player = save.Player()
        self.player.flags["last_heal"] = ["home", 4, 4]
        self.world = Overworld(self)
        self.state = "intro"
        self.intro_page = 0
        self.intro_timer = 0

    INTRO = [
        ("crest", "THE GRIDIRON GAUNTLET. Est. 2013. Twelve lifelong friends, one league, one ring - and thirteen seasons of grudges."),
        ("mons", "Here, football itself is alive. GAUNTLET MON roam the tall grass: PIGSKLETS, AERLINGS, TURFLINGS... and stranger legends."),
        ("types", "Eight types. O-LINE, RUSHING, PASSING, LINEBACKER, D-LINE, DEFENSIVE BACK, RECEIVER, SPECIALIST. Scheme beats scheme."),
        ("owners", "Eleven league owners hold GAUNTLET STADIUM. Each has a team, a title, a grudge - and a squad built to end your season."),
        ("hero", "You are {P}, GM of DAS WONDERKRIEG. Most points ever. Unluckiest ever. Never a ring. This year, that changes."),
        ("family", "COURTNEY, OLIVER and ELLOWAY believe in you. (They also know a certain secret about your nights. Keep it that way.)"),
        ("go", "Catch them in football-shaped CONTRACTS. Train them. Run the gauntlet. Bring the ring home."),
    ]

    BALL_PAL = [(245, 235, 215), (150, 90, 40), (110, 60, 25), (60, 30, 10)]

    def _end_intro(self):
        self.state = "world"
        self.world.text.say(f"COURTNEY: {self.player.name}! You're finally up. COACH DUNN wants you at the FRONT OFFICE.")
        self.world.text.say("COURTNEY: It's the building at the bottom-left of town - walk straight into the dark doorway. Go on, GM.")

    def update_intro(self, inp):
        self.intro_timer += 1
        if inp.pressed("start"):
            self.flash_transition(self._end_intro)
            return
        if inp.pressed("a") and self.intro_timer > 10:
            self.intro_page += 1
            self.intro_timer = 0
            if self.intro_page >= len(self.INTRO):
                self.flash_transition(self._end_intro)

    def draw_intro(self, c):
        c.fill(gfx.UI["navy"])
        c.fill(gfx.UI["cobalt"], (0, 0, gfx.W, 3))
        c.fill(gfx.UI["red"], (0, 3, gfx.W, 2))
        kind, text = self.INTRO[min(self.intro_page, len(self.INTRO) - 1)]
        text = text.replace("{P}", self.player.name)
        t = self.intro_timer
        if kind == "crest":
            ball = gfx.art(sprites.BALL, palette=self.BALL_PAL, scale=4, key="introball")
            c.blit(ball, ((gfx.W - ball.get_width()) // 2, 20))
            gfx.text_center(c, gfx.W // 2, 60, "GRIDIRON GAUNTLET", gfx.UI["gold"])
            gfx.text_center(c, gfx.W // 2, 72, "EST. 2013", gfx.UI["light"])
        elif kind == "mons":
            for i, n in enumerate(["PIGSKLET", "AERLING", "TURFLING", "BELLCOW"]):
                if t > i * 12:
                    c.blit(gfx.creature_sprite(n, 56), (12 + i * 58, 24))
        elif kind == "types":
            for i, tp in enumerate(types.TYPES):
                if t > i * 6:
                    gfx.type_badge(c, 24 + (i % 4) * 52, 26 + (i // 4) * 30, tp)
        elif kind == "owners":
            for i, n in enumerate(["TREVOR", "KENNY", "BOB", "PETE"]):
                pic = gfx.png("trainers", n, 64)
                if pic and t > i * 12:
                    c.blit(pic, (10 + i * 58, 20))
        elif kind == "hero":
            pic = gfx.png("people", "PLAYER", 80)
            if pic:
                c.blit(pic, (20, 8))
            gfx.text(c, 112, 24, "DAS WONDERKRIEG", gfx.UI["gold"])
            gfx.text(c, 112, 40, "MOST POINTS EVER", gfx.UI["light"])
            gfx.text(c, 112, 52, "RINGS: 0", gfx.UI["red"])
        elif kind == "family":
            for i, n in enumerate(["COURTNEY", "OLIVER", "ELLOWAY"]):
                pic = gfx.png("people", n, 72)
                if pic and t > i * 12:
                    c.blit(pic, (30 + i * 66, 12))
        else:
            ball = gfx.art(sprites.BALL, palette=self.BALL_PAL, scale=3, key="introball3")
            c.blit(ball, ((gfx.W - ball.get_width()) // 2 + (t % 40) - 20, 24))
            gfx.text_center(c, gfx.W // 2, 60, "CATCH - TRAIN - BATTLE", gfx.UI["gold"])
            gfx.text_center(c, gfx.W // 2, 72, "BUILD - BELONG", gfx.UI["gold"])
        gfx.box(c, 0, 92, gfx.W, 68)
        shown = min(len(text), t * 2)
        y = 100
        for line in gfx.wrap(text[:shown], 36)[:4]:
            gfx.text(c, 8, y, line)
            y += 12
        if shown >= len(text) and (self.frame // 20) % 2 == 0:
            gfx.text_right(c, gfx.W - 8, 148, "A: NEXT  START: SKIP", gfx.UI["mid"])

    def continue_game(self):
        self.player = save.load_game()
        self.world = Overworld(self)
        self.state = "world"

    def start_battle(self, wild, trainer=None):
        def go():
            self.battle = Battle(self, wild, trainer=trainer)
            self.state = "battle"
        self.flash_transition(go)

    def end_battle(self):
        result = self.battle.result
        self.battle = None
        self.state = "world"
        self.world.after_battle(result)
        if result == "lose":
            self.blackout()

    def blackout(self):
        p = self.player
        p.heal_all()
        m, x, y = p.flags.get("last_heal", ["home", 4, 4])
        p.x, p.y, p.facing = x, y, "down"
        self.world.load_map(m)
        self.world.text.say(f"{p.name} hurried back home and rested up... Everyone is healed.")

    def open_start_menu(self):
        self.menu = StartMenu(self)
        self.state = "menu"

    # --- main loop pieces ----------------------------------------------------
    def update(self, inp):
        self.frame += 1
        if self.fade_dir:
            self._update_fade()
            return
        if self.state == "title":
            choice = self.title_menu.update(inp)
            if choice is not None:
                if self.title_menu.items[choice] == "CONTINUE":
                    self.flash_transition(self.continue_game)
                else:
                    self.flash_transition(self.new_game)
        elif self.state == "intro":
            self.update_intro(inp)
        elif self.state == "world":
            self.world.update(inp)
        elif self.state == "battle":
            self.battle.update(inp)
            if self.battle.done:
                self.flash_transition(self.end_battle)
        elif self.state == "menu":
            self.menu.update(inp)
            if self.menu.closed:
                self.menu = None
                self.state = "world"

    def draw(self):
        c = self.canvas
        if self.state == "title":
            self.draw_title(c)
        elif self.state == "intro":
            self.draw_intro(c)
        elif self.state == "world":
            self.world.draw(c)
        elif self.state == "battle":
            self.battle.draw(c)
        elif self.state == "menu":
            self.world.draw(c)
            self.menu.draw(c)
        if self.fade:
            gfx.fade_step(c, min(3, self.fade))
        return c

    def draw_title(self, c):
        c.fill(gfx.UI["navy"])
        c.fill(gfx.UI["cobalt"], (0, 0, gfx.W, 3))
        c.fill(gfx.UI["red"], (0, 3, gfx.W, 2))
        if not hasattr(self, "_logo"):
            small = gfx.new_surface(font.text_width("GAUNTLET MON"), font.GLYPH_H)
            gfx.text(small, 0, 0, "GAUNTLET MON", gfx.UI["gold"])
            self._logo = pygame.transform.scale(small, (small.get_width() * 3, small.get_height() * 3))
            self._logo.set_colorkey(gfx.TRANSPARENT)
        c.blit(self._logo, ((gfx.W - self._logo.get_width()) // 2, 14))
        gfx.text_center(c, gfx.W // 2, 40, "GRIDIRON GAUNTLET EDITION", gfx.UI["light"])
        # parade of creatures
        names = ["BELLCOW", "LOCKDOWN", "PIGSKLET", "WAIVERN", "AERLING", "BOOMBUST", "TURFLING", "CHAINGEIST", "TOM_GOAT"]
        i = (self.frame // 100) % len(names)
        c.blit(gfx.creature_sprite(names[i], 64), (8, 52))
        c.blit(gfx.creature_sprite(names[(i + 4) % len(names)], 64, mirror=True), (gfx.W - 72, 52))
        gfx.text_center(c, gfx.W // 2, 60, "CATCH - BATTLE", gfx.UI["gold"])
        gfx.text_center(c, gfx.W // 2, 72, "BUILD - AVENGE", gfx.UI["gold"])
        self.title_menu.draw(c)
        if (self.frame // 30) % 2 == 0:
            gfx.text_center(c, gfx.W // 2, 148, "PRESS Z TO START", gfx.UI["light"])
        gfx.text(c, 4, 150, "V0.4", gfx.UI["mid"])
