"""
The player's progress (party, bag, position, flags) and saving it to
saves/save.json. Delete that file to start over.
"""
import json
import os
import settings
from engine.monsters import Monster

SAVE_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "saves")
SAVE_PATH = os.path.join(SAVE_DIR, "save.json")


class Player:
    def __init__(self, name=None):
        self.name = name or settings.PLAYER_NAME
        self.cash = settings.STARTING_CASH
        self.party = []
        self.storage = []
        self.bag = dict(settings.STARTING_ITEMS)
        self.seen = set()
        self.caught = set()
        self.map = "home"
        self.x, self.y = 4, 4
        self.facing = "down"
        self.flags = {}
        self.steps = 0

    # --- party helpers ----------------------------------------------------
    def first_healthy(self):
        for i, m in enumerate(self.party):
            if not m.fainted:
                return i
        return None

    def all_fainted(self):
        return all(m.fainted for m in self.party)

    def add_monster(self, mon):
        self.caught.add(mon.species)
        self.seen.add(mon.species)
        if len(self.party) < 6:
            self.party.append(mon)
            return "party"
        self.storage.append(mon)
        return "storage"

    def heal_all(self):
        for m in self.party:
            m.heal_full()

    def add_item(self, name, n=1):
        self.bag[name] = self.bag.get(name, 0) + n

    def use_item(self, name):
        if self.bag.get(name, 0) <= 0:
            return False
        self.bag[name] -= 1
        if self.bag[name] == 0:
            del self.bag[name]
        return True

    # --- save / load ------------------------------------------------------
    def to_dict(self):
        return {"name": self.name, "cash": self.cash,
                "party": [m.to_dict() for m in self.party],
                "storage": [m.to_dict() for m in self.storage],
                "bag": self.bag, "seen": sorted(self.seen), "caught": sorted(self.caught),
                "map": self.map, "x": self.x, "y": self.y, "facing": self.facing,
                "flags": self.flags, "steps": self.steps}

    @classmethod
    def from_dict(cls, d):
        p = cls(d.get("name"))
        p.cash = d.get("cash", p.cash)
        p.party = [Monster.from_dict(m) for m in d.get("party", [])]
        p.storage = [Monster.from_dict(m) for m in d.get("storage", [])]
        p.bag = d.get("bag", {})
        p.seen = set(d.get("seen", []))
        p.caught = set(d.get("caught", []))
        p.map, p.x, p.y = d.get("map", "home"), d.get("x", 4), d.get("y", 4)
        p.facing = d.get("facing", "down")
        p.flags = d.get("flags", {})
        p.steps = d.get("steps", 0)
        return p


def save_exists():
    return os.path.exists(SAVE_PATH)


def save_game(player):
    os.makedirs(SAVE_DIR, exist_ok=True)
    tmp = SAVE_PATH + ".tmp"
    with open(tmp, "w") as f:
        json.dump(player.to_dict(), f, indent=1)
    os.replace(tmp, SAVE_PATH)


def load_game():
    with open(SAVE_PATH) as f:
        return Player.from_dict(json.load(f))
