"""
GAUNTLET MON - settings you can safely tweak.
Every value here is plain and self-explanatory. Change a number, save, relaunch.
"""

# Window / display -----------------------------------------------------------
# The game renders at Game Boy Advance resolution (240 x 160) and scales up.
FULLSCREEN = False      # True = fill the TV. False = a window at WINDOW_SCALE size.
WINDOW_SCALE = 4        # 4 = 960 x 640 window. 3 = 720 x 480, etc.
FPS = 60

# Gameplay -------------------------------------------------------------------
ENCOUNTER_CHANCE = 10       # % chance per step in tall grass (Game Boy was about 10)
EXP_RATE = 1.5              # experience multiplier (1.0 = original Game Boy pace, 1.5 = a bit faster)
STARTING_CASH = 3000
STARTING_ITEMS = {"CONTRACT": 5, "SPORTS DRINK": 3}
TEXT_SPEED = 2              # letters revealed per frame (1 = slow, 3 = fast)
PLAYER_NAME = "BOBBIE"      # your name in the game (letters and spaces; shown in caps)

# Controls (keyboard) --------------------------------------------------------
# Game Boy layout: A = confirm, B = cancel/run, START = menu.
# Names are pygame key names; see https://www.pygame.org/docs/ref/key.html
KEYS = {
    "up":    ["up", "w"],
    "down":  ["down", "s"],
    "left":  ["left", "a"],
    "right": ["right", "d"],
    "a":     ["z", "return", "space"],
    "b":     ["x", "backspace"],
    "start": ["escape", "tab"],
}

# Controls (USB gamepad) -----------------------------------------------------
# Tuned for the EasySMX X15 on its 2.4GHz dongle in PC / Xbox mode (the mode
# the dongle uses by default). Xbox-style numbering on the Pi:
#   A=0  B=1  X=2  Y=3  LB=4  RB=5  Back/View=6  Start/Menu=7  Guide=8
#   D-pad = hat, left stick = axes 0/1 (both work for walking)
# If a button feels wrong, run  python3 main.py --debug-pad  and press it: the
# terminal prints the number. Then change it here.
PAD_BUTTONS = {
    "a": [0],            # A = confirm / talk / advance text
    "b": [1, 2],         # B (and X) = cancel / back / run
    "start": [7, 6, 9],  # Start (and Back) = open the menu
}
PAD_DEADZONE = 0.5
