"""
Input: turns keyboard + gamepad into 7 Game Boy buttons:
up / down / left / right / a / b / start.

    inp.held("up")     -> True while the button is down
    inp.pressed("a")   -> True only on the frame it went down
    inp.repeat("down") -> pressed, OR held long enough to auto-repeat (menus)
"""
import pygame
import settings

BUTTONS = ("up", "down", "left", "right", "a", "b", "start")


class Input:
    def __init__(self, debug_pad=False):
        self.debug_pad = debug_pad
        self._held = {b: False for b in BUTTONS}
        self._prev = dict(self._held)
        self._hold_frames = {b: 0 for b in BUTTONS}
        self.quit = False
        self._keymap = {}
        for action, names in settings.KEYS.items():
            for n in names:
                try:
                    self._keymap[pygame.key.key_code(n)] = action
                except Exception:
                    pass
        self._pads = []
        try:
            pygame.joystick.init()
            for i in range(pygame.joystick.get_count()):
                j = pygame.joystick.Joystick(i)
                j.init()
                self._pads.append(j)
        except Exception:
            pass

    def poll(self):
        self._prev = dict(self._held)
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                self.quit = True
            elif e.type == pygame.KEYDOWN:
                a = self._keymap.get(e.key)
                if a:
                    self._held[a] = True
            elif e.type == pygame.KEYUP:
                a = self._keymap.get(e.key)
                if a:
                    self._held[a] = False
            elif e.type == getattr(pygame, "JOYDEVICEADDED", -1):
                try:                                    # controller plugged in after launch
                    j = pygame.joystick.Joystick(e.device_index)
                    j.init()
                    self._pads.append(j)
                    print("gamepad connected:", j.get_name())
                except Exception:
                    pass
            elif e.type == pygame.JOYBUTTONDOWN or e.type == pygame.JOYBUTTONUP:
                down = e.type == pygame.JOYBUTTONDOWN
                if self.debug_pad and down:
                    print("gamepad button", e.button)
                for action, nums in settings.PAD_BUTTONS.items():
                    if e.button in nums:
                        self._held[action] = down
            elif e.type == pygame.JOYHATMOTION:
                hx, hy = e.value
                self._held["left"], self._held["right"] = hx < 0, hx > 0
                self._held["up"], self._held["down"] = hy > 0, hy < 0
            elif e.type == pygame.JOYAXISMOTION:
                dz = settings.PAD_DEADZONE
                if e.axis == 0:
                    self._held["left"], self._held["right"] = e.value < -dz, e.value > dz
                elif e.axis == 1:
                    self._held["up"], self._held["down"] = e.value < -dz, e.value > dz
        for b in BUTTONS:
            self._hold_frames[b] = self._hold_frames[b] + 1 if self._held[b] else 0

    def held(self, b):
        return self._held[b]

    def pressed(self, b):
        return self._held[b] and not self._prev[b]

    def repeat(self, b, delay=14, every=4):
        f = self._hold_frames[b]
        return f == 1 or (f > delay and (f - delay) % every == 0)

    def any_pressed(self, *buttons):
        return any(self.pressed(b) for b in buttons)
