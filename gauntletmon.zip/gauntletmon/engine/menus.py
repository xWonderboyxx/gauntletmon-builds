"""
The START menu (press ESC/TAB on keyboard): TEAM, BAG, ROSTER, SAVE, QUIT,
plus the creature summary and roster screens.
"""
from engine import gfx, ui, font, save
from engine.monsters import STATUS_NAMES
from data import creatures, sprites, items as itemdata, moves as movedata, types


def party_label(m):
    st = STATUS_NAMES.get(m.status, "")
    return f"{m.name[:11]:<11} L{m.level:>2} {m.hp:>3}/{m.max_hp:<3} {st}"


class StartMenu:
    def __init__(self, game):
        self.game = game
        self.player = game.player
        self.text = ui.TextBox()
        self.frame = 0
        self.closed = False
        self.stack = []                  # screens: ("main", menu) ...
        self.push("main", ui.Menu(["TEAM", "BAG", "ROSTER", "SAVE", "QUIT"], gfx.W - 70, 0, 70))

    # --- screen stack ------------------------------------------------------
    def push(self, kind, menu, data=None):
        self.stack.append({"kind": kind, "menu": menu, "data": data or {}})

    def pop(self):
        self.stack.pop()
        if not self.stack:
            self.closed = True

    @property
    def top(self):
        return self.stack[-1]

    def refresh_team(self):
        """Rebuild the TEAM list after the party changed."""
        scr = self.top
        if scr["kind"] == "team":
            old = scr["menu"].index
            scr["menu"] = ui.Menu([party_label(m) for m in self.player.party] + ["BENCH"], 0, 0, gfx.W, line_h=12,
                                  index=min(old, len(self.player.party)))

    # --- update --------------------------------------------------------------
    def update(self, inp):
        self.frame += 1
        if self.text.busy:
            self.text.update(inp)
            return
        scr = self.top
        kind, menu = scr["kind"], scr["menu"]
        if kind in ("summary", "roster_entry"):
            if inp.pressed("a") or inp.pressed("b"):
                self.pop()
            return
        choice = menu.update(inp)
        if menu.cancelled:
            self.pop()
            return
        if choice is None:
            return
        handler = getattr(self, "on_" + kind)
        handler(choice, scr)

    def on_main(self, choice, scr):
        p = self.player
        if choice == 0:
            if not p.party:
                self.text.say("You have no team yet!")
                return
            self.push("team", ui.Menu([party_label(m) for m in p.party] + ["BENCH"], 0, 0, gfx.W, line_h=12))
        elif choice == 1:
            names = sorted(p.bag)
            if not names:
                self.text.say("Your bag is empty.")
                return
            self.push("bag", ui.Menu([f"{n} x{p.bag[n]}" for n in names], 0, 0, gfx.W, line_h=10), {"names": names})
        elif choice == 2:
            labels = []
            for name, d in creatures.by_number():
                shown = creatures.display_name(name) if name in p.seen else "-----"
                mark = "*" if name in p.caught else " "
                labels.append(f"{d['no']:03d} {mark}{shown}")
            self.push("roster", ui.Menu(labels, 0, 0, 120, line_h=10, visible=14), {"names": [n for n, _ in creatures.by_number()]})
        elif choice == 3:
            self.push("save", ui.Menu(["YES", "NO"], gfx.W - 48, ui.BOX_Y))
        elif choice == 4:
            self.push("quit", ui.Menu(["YES", "NO"], gfx.W - 48, ui.BOX_Y, index=1))

    def on_team(self, choice, scr):
        p = self.player
        if choice == len(p.party):                    # BENCH
            if not p.storage:
                self.text.say("Nobody is on the bench.")
                return
            self.push("bench", ui.Menu([party_label(m) for m in p.storage], 0, 0, gfx.W, line_h=12, visible=10))
            return
        opts = ["SUMMARY", "SWITCH", "BENCH IT", "CANCEL"]
        self.push("team_action", ui.Menu(opts, gfx.W - 70, 90, 70, line_h=12), {"index": choice})

    def on_team_action(self, choice, scr):
        p = self.player
        i = scr["data"]["index"]
        if choice == 0:
            self.pop()
            self.push("summary", None, {"mon": p.party[i]})
        elif choice == 1:
            self.pop()
            self.push("team_swap", ui.Menu([party_label(m) for m in p.party], 0, 0, gfx.W, line_h=12, index=i), {"index": i})
        elif choice == 2:
            if len(p.party) <= 1:
                self.text.say("You need at least one player on the team!")
                return
            p.storage.append(p.party.pop(i))
            self.pop()
            self.refresh_team()
            self.text.say("Sent to the bench.")
        else:
            self.pop()

    def on_team_swap(self, choice, scr):
        p = self.player
        i = scr["data"]["index"]
        p.party[i], p.party[choice] = p.party[choice], p.party[i]
        self.pop()
        self.refresh_team()

    def on_bench(self, choice, scr):
        p = self.player
        if len(p.party) >= 6:
            self.text.say("Your team is full. BENCH IT someone first.")
            return
        p.party.append(p.storage.pop(choice))
        self.pop()
        self.refresh_team()
        self.text.say("Added to the team!")

    def on_bag(self, choice, scr):
        p = self.player
        name = scr["data"]["names"][choice]
        kind = itemdata.get(name)["kind"]
        if kind == "ball":
            self.text.say("You can only use that in a battle!")
            return
        if not p.party:
            self.text.say("You have no team yet!")
            return
        self.push("bag_target", ui.Menu([party_label(m) for m in p.party], 0, 0, gfx.W, line_h=12), {"item": name})

    def on_bag_target(self, choice, scr):
        p = self.player
        name = scr["data"]["item"]
        data = itemdata.get(name)
        mon = p.party[choice]
        kind = data["kind"]
        if kind == "heal":
            if mon.fainted or mon.hp == mon.max_hp:
                self.text.say("It won't have any effect.")
                return
            mon.hp = min(mon.max_hp, mon.hp + data["amount"])
            msg = f"{mon.name} recovered HP!"
        elif kind == "cure":
            if not mon.status:
                self.text.say("It won't have any effect.")
                return
            mon.status = None
            msg = f"{mon.name} is feeling fine!"
        elif kind == "revive":
            if not mon.fainted:
                self.text.say("It won't have any effect.")
                return
            mon.hp = mon.max_hp // 2
            msg = f"{mon.name} is back on its feet!"
        else:
            for mv in mon.moves:
                mv[1] = movedata.get(mv[0])["pp"]
            msg = f"{mon.name}'s PP was restored!"
        p.use_item(name)
        self.pop()
        self.pop()
        names = sorted(p.bag)
        if names:
            self.top["menu"] = ui.Menu([f"{n} x{p.bag[n]}" for n in names], 0, 0, gfx.W, line_h=10,
                                       index=min(self.top["menu"].index, len(names) - 1))
            self.top["data"]["names"] = names
        else:
            self.pop()
        self.text.say(msg)

    def on_roster(self, choice, scr):
        name = scr["data"]["names"][choice]
        if name in self.player.seen:
            self.push("roster_entry", None, {"name": name})

    def on_quit(self, choice, scr):
        self.pop()
        if choice == 0:
            self.game.quit = True

    def on_save(self, choice, scr):
        self.pop()
        if choice == 0:
            save.save_game(self.player)
            self.text.say(f"{self.player.name} saved the game!")

    # --- drawing -------------------------------------------------------------
    def draw(self, surf):
        scr = self.top
        kind = scr["kind"]
        if kind == "summary":
            self.draw_summary(surf, scr["data"]["mon"])
        elif kind == "roster_entry":
            self.draw_entry(surf, scr["data"]["name"])
        else:
            for s in self.stack:
                if s["menu"]:
                    s["menu"].draw(surf)
            if kind == "roster":
                name = scr["data"]["names"][scr["menu"].index]
                d = creatures.get(name)
                gfx.box(surf, 120, 0, 120, 160)
                if name in self.player.seen:
                    surf.blit(gfx.creature_sprite(name, 64), (148, 8))
                    gfx.type_badge(surf, 126, 76, d["type"])
                    gfx.text(surf, 126, 90, d["subtype"][:16], gfx.UI["mid"])
                    gfx.text(surf, 126, 102, d["tier"][:16], gfx.UI["ink"])
                    gfx.text(surf, 126, 114, d["rarity"], gfx.UI["mid"])
                else:
                    gfx.text(surf, 150, 40, "?", gfx.UI["mid"])
                gfx.text(surf, 126, 134, f"SEEN {len(self.player.seen)}")
                gfx.text(surf, 126, 146, f"OWN  {len(self.player.caught)}")
            if kind == "bag":
                name = scr["data"]["names"][scr["menu"].index]
                gfx.box(surf, 0, ui.BOX_Y + 16, gfx.W, 32)
                gfx.text(surf, 8, ui.BOX_Y + 28, itemdata.get(name)["desc"])
            if kind == "save":
                gfx.box(surf, 0, ui.BOX_Y, gfx.W - 48, 48)
                gfx.text(surf, 8, ui.BOX_Y + 12, "SAVE THE GAME?")
            if kind == "quit":
                gfx.box(surf, 0, ui.BOX_Y, gfx.W - 48, 48)
                gfx.text(surf, 8, ui.BOX_Y + 8, "QUIT TO DESKTOP?")
                gfx.text(surf, 8, ui.BOX_Y + 20, "UNSAVED PROGRESS")
                gfx.text(surf, 8, ui.BOX_Y + 30, "WILL BE LOST.")
            if kind == "main":
                gfx.box(surf, 0, gfx.H - 16, 110, 16)
                gfx.text(surf, 6, gfx.H - 12, f"CASH ${self.player.cash}")
        if self.text.busy:
            self.text.draw(surf, self.frame)

    def draw_summary(self, surf, m):
        d = creatures.get(m.species)
        surf.fill(gfx.UI["paper"])
        gfx.box(surf, 0, 0, gfx.W, gfx.H)
        surf.blit(gfx.creature_sprite(m.species, 64), (8, 8))
        gfx.text(surf, 80, 10, m.name)
        gfx.text_right(surf, 232, 10, f"L{m.level}")
        gfx.type_badge(surf, 80, 22, m.type)
        gfx.text(surf, 128, 23, d["subtype"], gfx.UI["mid"])
        gfx.text(surf, 80, 36, f"NO.{d['no']:03d}  {d['tier']}", gfx.UI["mid"])
        gfx.hp_bar(surf, 94, 50, 90, m.hp, m.max_hp)
        gfx.text(surf, 80, 58, f"{m.hp}/{m.max_hp}" + (f"  {STATUS_NAMES[m.status]}" if m.status else ""))
        y = 74
        for st in ("ATK", "DEF", "SPD"):
            gfx.text(surf, 8, y, f"{st} {m.stat(st):>3}")
            y += 9
        gfx.text(surf, 80, 74, f"EXP {m.exp}", gfx.UI["mid"])
        gfx.text(surf, 80, 83, f"NEXT {m.exp_to_next()}", gfx.UI["mid"])
        tp, sp = m.passive
        gfx.text(surf, 8, 100, f"PASSIVE {tp}", gfx.UI["cobalt"])
        gfx.text(surf, 8, 109, f"SUBTYPE {sp}", gfx.UI["cobalt"])
        surf.fill(gfx.UI["mid"], (6, 118, gfx.W - 12, 1))
        y = 122
        for name, pp in m.moves:
            mv = movedata.get(name)
            gfx.text(surf, 8, y, name)
            gfx.type_badge(surf, 132, y - 1, mv["type"], w=44)
            gfx.text_right(surf, 232, y, f"{pp}/{mv['pp']}")
            y += 8
        for _ in range(4 - len(m.moves)):
            gfx.text(surf, 8, y, "-")
            y += 8

    def draw_entry(self, surf, name):
        d = creatures.get(name)
        surf.fill(gfx.UI["paper"])
        gfx.box(surf, 0, 0, gfx.W, gfx.H)
        surf.blit(gfx.creature_sprite(name, 80), (8, 8))
        gfx.text(surf, 96, 12, f"NO.{d['no']:03d}  {creatures.display_name(name)}")
        gfx.type_badge(surf, 96, 24, d["type"])
        gfx.text(surf, 150, 25, d["subtype"], gfx.UI["mid"])
        gfx.text(surf, 96, 38, d["tier"], gfx.UI["ink"])
        gfx.text(surf, 96, 48, f"{d['rarity']}  {d['lore'] if d['lore'] != 'NORMAL' else ''}", gfx.UI["mid"])
        tp = types.PASSIVES[d["type"]]
        gfx.text(surf, 96, 62, tp["name"], gfx.UI["cobalt"])
        for i, line in enumerate(gfx.wrap(tp["desc"], 23)[:3]):
            gfx.text(surf, 96, 71 + i * 8, line, gfx.UI["mid"])
        if name in self.player.caught:
            gfx.text(surf, 8, 92, "* SIGNED", gfx.UI["gold"])
        surf.fill(gfx.UI["mid"], (6, 104, gfx.W - 12, 1))
        y = 109
        for line in gfx.wrap(d["entry"], 37)[:5]:
            gfx.text(surf, 8, y, line)
            y += 9
