"""
MAPS - drawn as text. One character = one 16x16 tile. Edit them right here.

Outdoor tiles:
    .  grass (walk)        ,  TALL GRASS (walk, wild encounters!)
    =  path (walk)         T  tree (blocked)      W  water (blocked)
    F  fence (blocked)     R  roof (blocked)      B  wall (blocked)
    D  door (walk onto it to go inside - needs a matching "warps" entry)
    S  sign (blocked, shows text from "signs")
    X  gate post (blocked)     f  flowers (walk)     t  pine tree (blocked)
    w  sidewalk (walk)         k  brick wall (blocked)   c  cone (blocked)   L  lamp post (blocked)
    Y  painted turf / yard line (walk)            Z  bleachers (blocked)
    G  stadium gate arch (walk, use with a warp)
Indoor tiles:
    _  floor (walk)        #  wall (blocked)      C  counter (blocked)
    K  locker/shelf        b  bed                 Q  rug (walk)
    P  plant               M  machine             E  exit mat (walk onto = go out)

"warps": stepping onto tile "at" moves you to map "to" at "pos", facing "face".
"npcs":  people. "text" is a list of lines. Optional "script" gives them a job:
         "starter", "heal", "shop", "gatekeeper".
         A trainer NPC has "trainer": "NAME" (from data/trainers.py), a "sight"
         (how many tiles ahead they spot you) and an optional "after_at" - where
         they stand once you've beaten them, so they stop blocking the path.
"encounters": [creature name, weight, [min level, max level]] for the tall grass.
"scene": battle backdrop - "field" (default), "lot", "concourse", "night".
"""

MAPS = {}

# ============================================================================
MAPS["village"] = {
    "name": "KICKOFF VILLAGE",
    "tiles": [
        "TTTTTTTTTT=TTTTTTTTT",
        "Tt.f.....X=X.....f.T",
        "T.....F..=..F.....tT",
        "T.RRRR...=...RRRR..T",
        "T.BDBB.L.=.L.BBDB..T",
        "T.wSww...=...wwSw..T",
        "T..f.....=......f..T",
        "T...=============..T",
        "T.f.=....=.....=.f.T",
        "T.RRRR...=...RRRR..T",
        "T.BBDB.L.=.L.BDBB..T",
        "T.wwSw...=...wSww..T",
        "T........=...WWW...T",
        "Tt...,,,.=...WWW.f.T",
        "T....,,,.=......f..T",
        "T.f......=.......t.T",
        "TTTTTTTTTTTTTTTTTTTT",
    ],
    "warps": [
        {"at": [3, 4],  "to": "home",   "pos": [4, 6], "face": "up"},
        {"at": [15, 4], "to": "locker", "pos": [4, 6], "face": "up"},
        {"at": [4, 10], "to": "lab",    "pos": [4, 6], "face": "up"},
        {"at": [14, 10], "to": "shop",  "pos": [4, 6], "face": "up"},
        {"at": [10, 0], "to": "route1", "pos": [6, 30], "face": "up"},
    ],
    "signs": {
        (3, 5):  "BOBBIE'S HOUSE",
        (14, 5): "LOCKER ROOM - rest up, get patched up, free of charge!",
        (3, 11): "FRONT OFFICE - COACH DUNN, GENERAL MANAGER",
        (14, 11): "PRO SHOP - contracts, drinks, gear.",
    },
    "npcs": [
        {"at": [7, 6], "sprite": "KID", "face": "down",
         "text": ["Tall grass hides wild players! Walk in it with a team and you'll find one.",
                  "No team yet? Talk to COACH in the FRONT OFFICE first!"]},
        {"at": [12, 13], "sprite": "KID2", "face": "left",
         "text": ["I threw a CONTRACT at a REFBIT and it just blew its whistle at me.",
                  "Weaken them first! Low HP makes them sign."]},
    ],
    "encounters": [["REFBIT", 60, [2, 3]], ["WHISTLET", 40, [2, 3]]],
}

# ============================================================================
MAPS["route1"] = {
    "name": "PRACTICE FIELD ROAD",
    "tiles": [
        "TTTTTTGTTTTT",
        "TTTT.X=X.TTT",
        "TT..f....TTT",
        "TT.,,,,..TTT",
        "TT.,,,,.tTTT",
        "TT.,,,,=.TTT",
        "TT.c...=.TTT",
        "TTT....=fTTT",
        "TTT.S..=.TTT",
        "TTT....=..TT",
        "TTT,,,.=..TT",
        "TTT,,,.=,,TT",
        "TTT,,,.=,,TT",
        "TTT....=,,TT",
        "TT.....=..TT",
        "TT.....=..TT",
        "TT.F.F.=.cTT",
        "TT..f..=..TT",
        "TT.,,,,=..TT",
        "TT.,,,,=..TT",
        "TT.,,,,=..TT",
        "TT.,,,,=..TT",
        "TT.....=..TT",
        "TTT....=.TTT",
        "TTT....=.TTT",
        "TTT,,,.=.TTT",
        "TTT,,,.=.TTT",
        "TTT,,,.=.TTT",
        "TTT....=.TTT",
        "TTT....=.TTT",
        "TTTTTT=TTTTT",
        "TTTTTT=TTTTT",
    ],
    "warps": [
        {"at": [6, 31], "to": "village", "pos": [10, 1], "face": "down"},
        {"at": [6, 0], "to": "stadium1", "pos": [6, 38], "face": "up"},
    ],
    "signs": {
        (4, 8): "NORTH: GAUNTLET STADIUM  SOUTH: KICKOFF VILLAGE",
    },
    "npcs": [
        {"at": [6, 1], "sprite": "GUARD", "face": "down", "script": "gatekeeper", "after_at": [4, 1],
         "text": ["GUARD: GAUNTLET STADIUM. Eleven league owners are waiting in there, and they don't go easy."]},
        {"at": [8, 15], "sprite": "KID", "face": "left",
         "text": ["My CLEATLE only knows CHIP BLOCK. Creatures learn new moves as they level up!"]},
        {"at": [3, 23], "sprite": "COACH", "face": "right",
         "text": ["Eight types, rookie. Learn the chart. RUSHING flattens DBs, PASSING picks apart LINEBACKERS...",
                  "...but a D-LINE eats a QB alive. Check the ROSTER and the type on each move."]},
    ],
    "encounters": [
        ["REFBIT", 30, [2, 4]], ["CLEATLE", 25, [2, 4]], ["WHISTLET", 20, [2, 4]],
        ["PYLONK", 10, [3, 5]], ["CHALKAT", 8, [3, 5]], ["KICKOON", 4, [4, 6]],
        ["TACKLEON", 2, [4, 6]], ["BLITZARD", 1, [5, 7]],
    ],
}

# ============================================================================
# THE GAUNTLET - three stadium maps, eleven owners.
# ============================================================================
MAPS["stadium1"] = {
    "name": "STADIUM LOT", "scene": "lot",
    "tiles": [
        "ZZZZZZZZZZZZ",
        "ZZZZZ.G.ZZZZ",
        "ZZ...=.=..ZZ",
        "ZZ..,,=,,.ZZ",
        "ZZ..,,=,,.ZZ",
        "ZZ...Y=Y..ZZ",
        "ZZ..F.=.F.ZZ",
        "ZZ.c..=..cZZ",
        "ZZ.,,,=,,.ZZ",
        "ZZ.,,,=,,.ZZ",
        "ZZ.,,,=,,.ZZ",
        "ZZ....=...ZZ",
        "ZZ...Y=Y..ZZ",
        "ZZ....=...ZZ",
        "ZZ.S..=...ZZ",
        "ZZ....=,,.ZZ",
        "ZZ.,,.=,,.ZZ",
        "ZZ.,,.=,,.ZZ",
        "ZZ....=...ZZ",
        "ZZ...Y=Y..ZZ",
        "ZZ....=...ZZ",
        "ZZ.F..=..FZZ",
        "ZZ....=...ZZ",
        "ZZ.,,,=...ZZ",
        "ZZ.,,,=,,.ZZ",
        "ZZ.,,,=,,.ZZ",
        "ZZ....=...ZZ",
        "ZZ...Y=Y..ZZ",
        "ZZ....=...ZZ",
        "ZZ....=...ZZ",
        "ZZ.,,.=.,,ZZ",
        "ZZ.,,.=.,,ZZ",
        "ZZ....=...ZZ",
        "ZZ....=...ZZ",
        "ZZ.RRR=RRRZZ",
        "ZZ.BDB=BDBZZ",
        "ZZ.wwwww..ZZ",
        "ZZ.L..=..LZZ",
        "ZkkkkZ=ZkkkZ",
        "ZkkkkZ=ZkkkZ",
    ],
    "warps": [
        {"at": [6, 39], "to": "route1", "pos": [6, 2], "face": "down"},
        {"at": [6, 1], "to": "stadium2", "pos": [6, 38], "face": "up"},
        {"at": [4, 35], "to": "tent", "pos": [4, 6], "face": "up"},
        {"at": [8, 35], "to": "tentshop", "pos": [4, 6], "face": "up"},
    ],
    "signs": {(3, 14): "GAUNTLET STADIUM - LOT. Eleven owners. One ring. No refunds."},
    "npcs": [
        {"at": [6, 31], "sprite": "OWNER", "trainer": "TREVOR", "face": "down", "sight": 4, "after_at": [7, 31]},
        {"at": [6, 23], "sprite": "OWNER", "trainer": "HAMPTON", "face": "down", "sight": 4, "after_at": [5, 23]},
        {"at": [6, 15], "sprite": "OWNER", "trainer": "BROOKS", "face": "down", "sight": 4, "after_at": [7, 15]},
        {"at": [6, 7], "sprite": "OWNER", "trainer": "KENNY", "face": "down", "sight": 4, "after_at": [5, 7]},
        {"at": [3, 20], "sprite": "KID", "face": "right",
         "text": ["KENNY's SACKOLITH is a wall. D-LINE types laugh at RUSHING and specialists...",
                  "...but O-LINE and PASSING hit D-LINE for double. Bring a TURFLING or a CHALKAT!"]},
        {"at": [9, 12], "sprite": "KID2", "face": "left",
         "text": ["Owners spot you from four tiles away. Walk up the middle and you're in a match, ready or not.",
                  "The tents at the entrance heal you and sell gear."]},
    ],
    "encounters": [
        ["REFBIT", 15, [6, 9]], ["CLEATLE", 20, [6, 10]], ["WHISTLET", 10, [6, 9]],
        ["PYLONK", 15, [7, 11]], ["CHALKAT", 12, [7, 11]], ["TACKLEON", 10, [8, 12]],
        ["KICKOON", 8, [8, 12]], ["BLITZARD", 6, [9, 13]], ["BOOMBUST", 4, [10, 13]],
    ],
}

MAPS["stadium2"] = {
    "name": "STADIUM CONCOURSE", "scene": "concourse",
    "tiles": [
        "ZZZZZZZZZZZZ",
        "ZZZZZ.G.ZZZZ",
        "ZZ...=.=..ZZ",
        "ZZ..,,=,,.ZZ",
        "ZZ..,,=,,.ZZ",
        "ZZ...Y=Y..ZZ",
        "ZZ..F.=.F.ZZ",
        "ZZ.c..=..cZZ",
        "ZZ.,,,=,,.ZZ",
        "ZZ.,,,=,,.ZZ",
        "ZZ.,,,=,,.ZZ",
        "ZZ....=...ZZ",
        "ZZ...Y=Y..ZZ",
        "ZZ....=...ZZ",
        "ZZ.S..=...ZZ",
        "ZZ....=,,.ZZ",
        "ZZ.,,.=,,.ZZ",
        "ZZ.,,.=,,.ZZ",
        "ZZ....=...ZZ",
        "ZZ...Y=Y..ZZ",
        "ZZ....=...ZZ",
        "ZZ.F..=..FZZ",
        "ZZ....=...ZZ",
        "ZZ.,,,=...ZZ",
        "ZZ.,,,=,,.ZZ",
        "ZZ.,,,=,,.ZZ",
        "ZZ....=...ZZ",
        "ZZ...Y=Y..ZZ",
        "ZZ....=...ZZ",
        "ZZ....=...ZZ",
        "ZZ.,,.=.,,ZZ",
        "ZZ.,,.=.,,ZZ",
        "ZZ....=...ZZ",
        "ZZ....=...ZZ",
        "ZZ.RRR=RRRZZ",
        "ZZ.BDB=BDBZZ",
        "ZZ.wwwww..ZZ",
        "ZZ.L..=..LZZ",
        "ZkkkkZ=ZkkkZ",
        "ZkkkkZ=ZkkkZ",
    ],
    "warps": [
        {"at": [6, 39], "to": "stadium1", "pos": [6, 2], "face": "down"},
        {"at": [6, 1], "to": "stadium3", "pos": [6, 38], "face": "up"},
        {"at": [4, 35], "to": "tent", "pos": [4, 6], "face": "up"},
        {"at": [8, 35], "to": "tentshop", "pos": [4, 6], "face": "up"},
    ],
    "signs": {(3, 14): "CONCOURSE. Record book: 367.9 - BOB HILL, 2019 playoffs. Still standing."},
    "npcs": [
        {"at": [6, 31], "sprite": "OWNER", "trainer": "BOB", "face": "down", "sight": 4, "after_at": [7, 31]},
        {"at": [6, 23], "sprite": "OWNER", "trainer": "MARK", "face": "down", "sight": 4, "after_at": [5, 23]},
        {"at": [6, 15], "sprite": "OWNER", "trainer": "JONATHAN", "face": "down", "sight": 4, "after_at": [7, 15]},
        {"at": [6, 7], "sprite": "OWNER", "trainer": "LOUIS", "face": "down", "sight": 4, "after_at": [5, 7]},
        {"at": [3, 20], "sprite": "KID", "face": "right",
         "text": ["BOB's AD18N just keeps running. RUSHING gets stuffed by D-LINE and LINEBACKERS.",
                  "A BLITZARD or a TACKLEON will make him remember the SACKO."]},
    ],
    "encounters": [
        ["BELLCOW", 18, [14, 19]], ["CHAINGEIST", 15, [14, 19]], ["BOOMBUST", 15, [14, 19]],
        ["TACKLEON", 14, [14, 18]], ["BLITZARD", 12, [15, 20]], ["KICKOON", 10, [14, 18]],
        ["PYLONK", 8, [15, 20]], ["WAIVERN", 5, [17, 21]], ["LOCKDOWN", 3, [17, 21]],
    ],
}

MAPS["stadium3"] = {
    "name": "GAUNTLET FIELD", "scene": "night",
    "tiles": [
        "ZZZZZZZZZZZZ",
        "ZZZZZ...ZZZZ",
        "ZZ..YY=YY.ZZ",
        "ZZ..,,=,,.ZZ",
        "ZZ..,,=,,.ZZ",
        "ZZ...Y=Y..ZZ",
        "ZZ..F.=.F.ZZ",
        "ZZ.c..=..cZZ",
        "ZZ.,,,=,,.ZZ",
        "ZZ.,,,=,,.ZZ",
        "ZZ.,,,=,,.ZZ",
        "ZZ....=...ZZ",
        "ZZ...Y=Y..ZZ",
        "ZZ....=...ZZ",
        "ZZ.S..=...ZZ",
        "ZZ....=,,.ZZ",
        "ZZ.,,.=,,.ZZ",
        "ZZ.,,.=,,.ZZ",
        "ZZ....=...ZZ",
        "ZZ...Y=Y..ZZ",
        "ZZ....=...ZZ",
        "ZZ.F..=..FZZ",
        "ZZ....=...ZZ",
        "ZZ.,,,=...ZZ",
        "ZZ.,,,=,,.ZZ",
        "ZZ.,,,=,,.ZZ",
        "ZZ....=...ZZ",
        "ZZ...Y=Y..ZZ",
        "ZZ....=...ZZ",
        "ZZ....=...ZZ",
        "ZZ.,,.=.,,ZZ",
        "ZZ.,,.=.,,ZZ",
        "ZZ....=...ZZ",
        "ZZ....=...ZZ",
        "ZZ.RRR=RRRZZ",
        "ZZ.BDB=BDBZZ",
        "ZZ.wwwww..ZZ",
        "ZZ.L..=..LZZ",
        "ZkkkkZ=ZkkkZ",
        "ZkkkkZ=ZkkkZ",
    ],
    "warps": [
        {"at": [6, 39], "to": "stadium2", "pos": [6, 2], "face": "down"},
        {"at": [4, 35], "to": "tent", "pos": [4, 6], "face": "up"},
        {"at": [8, 35], "to": "tentshop", "pos": [4, 6], "face": "up"},
    ],
    "signs": {(3, 14): "GAUNTLET FIELD. The last three. ALAN. ERIC. PETE."},
    "npcs": [
        {"at": [6, 27], "sprite": "OWNER", "trainer": "ALAN", "face": "down", "sight": 4, "after_at": [7, 27]},
        {"at": [6, 15], "sprite": "OWNER", "trainer": "ERIC", "face": "down", "sight": 4, "after_at": [5, 15]},
        {"at": [6, 5], "sprite": "OWNER", "trainer": "PETE", "face": "down", "sight": 4, "after_at": [7, 5]},
        {"at": [6, 2], "sprite": "COACH", "face": "down", "script": "champion",
         "text": ["COACH DUNN: Beat PETE and this trophy's yours, rookie. THE FIRST ONE."]},
    ],
    "encounters": [
        ["BELLCOW", 18, [24, 30]], ["WAIVERN", 12, [25, 31]], ["LOCKDOWN", 12, [25, 31]],
        ["CHAINGEIST", 14, [24, 30]], ["BLITZARD", 14, [24, 30]], ["BOOMBUST", 12, [24, 30]],
        ["TACKLEON", 10, [24, 29]], ["UPRIGHT", 5, [26, 32]], ["JOE_BURROWL", 2, [30, 34]],
    ],
}

# ============================================================================
MAPS["home"] = {
    "name": "HOME",
    "tiles": [
        "##########",
        "#K__bb_K_#",
        "#________#",
        "#___QQ___#",
        "#___QQ___#",
        "#________#",
        "#___E____#",
        "##########",
    ],
    "warps": [{"at": [4, 6], "to": "village", "pos": [3, 5], "face": "down"}],
    "signs": {},
    "npcs": [
        {"at": [6, 2], "sprite": "MOM", "face": "left",
         "text": ["MOM: Off to the FRONT OFFICE? COACH DUNN has been asking about you all morning.",
                  "Take a nap in your bed any time you need to rest up, sweetie."]},
    ],
    "heal_tiles": [[4, 1], [5, 1]],
    "encounters": [],
}

MAPS["lab"] = {
    "name": "FRONT OFFICE",
    "tiles": [
        "##########",
        "#KKKK_MMM#",
        "#________#",
        "#_CCCCCC_#",
        "#________#",
        "#P______P#",
        "#___E____#",
        "##########",
    ],
    "warps": [{"at": [4, 6], "to": "village", "pos": [4, 11], "face": "down"}],
    "signs": {},
    "npcs": [
        {"at": [4, 2], "sprite": "COACH", "face": "down", "script": "starter",
         "text": ["COACH DUNN: There you are, rookie! Every GM needs a first-round pick."]},
    ],
    "encounters": [],
}

MAPS["locker"] = {
    "name": "LOCKER ROOM",
    "tiles": [
        "##########",
        "#KKK_M_KK#",
        "#________#",
        "#__CCCC__#",
        "#________#",
        "#P______P#",
        "#___E____#",
        "##########",
    ],
    "warps": [{"at": [4, 6], "to": "village", "pos": [15, 5], "face": "down"}],
    "signs": {},
    "npcs": [
        {"at": [4, 2], "sprite": "TRAINER", "face": "down", "script": "heal",
         "text": ["TRAINER: Welcome to the LOCKER ROOM!"]},
    ],
    "encounters": [],
}

MAPS["shop"] = {
    "name": "PRO SHOP",
    "tiles": [
        "##########",
        "#KKKKKKKK#",
        "#________#",
        "#CCCCC___#",
        "#_____K__#",
        "#P____K_P#",
        "#___E____#",
        "##########",
    ],
    "warps": [{"at": [4, 6], "to": "village", "pos": [14, 11], "face": "down"}],
    "signs": {},
    "npcs": [
        {"at": [3, 2], "sprite": "CLERK", "face": "down", "script": "shop",
         "text": ["CLERK: Welcome to the PRO SHOP!"]},
    ],
    "encounters": [],
}

# Stadium medical tent + merch tent. The exit warp is filled in at load time
# (return_to) so one tent map serves every stadium section.
MAPS["tent"] = {
    "name": "MEDICAL TENT",
    "tiles": [
        "##########",
        "#K_M__M_K#",
        "#________#",
        "#__CCCC__#",
        "#________#",
        "#P______P#",
        "#___E____#",
        "##########",
    ],
    "warps": [{"at": [4, 6], "to": "RETURN", "pos": [4, 36], "face": "down"}],
    "signs": {},
    "npcs": [
        {"at": [4, 2], "sprite": "TRAINER", "face": "down", "script": "heal",
         "text": ["MEDIC: Rough out there? Hop up on the table."]},
    ],
    "encounters": [],
}
MAPS["tentshop"] = {
    "name": "MERCH TENT",
    "tiles": [
        "##########",
        "#KKKKKKKK#",
        "#________#",
        "#CCCCC___#",
        "#_____K__#",
        "#P____K_P#",
        "#___E____#",
        "##########",
    ],
    "warps": [{"at": [4, 6], "to": "RETURN", "pos": [8, 36], "face": "down"}],
    "signs": {},
    "npcs": [
        {"at": [3, 2], "sprite": "CLERK", "face": "down", "script": "shop",
         "text": ["VENDOR: Contracts, drinks, gels. Stadium prices, sorry."]},
    ],
    "encounters": [],
}

SOLID_TILES = set("TWFRBSXZ#CKbPMtkcL")
GRASS_TILES = set(",")
WALK_TILES = set(".,=DYG_QEfw")


def get(name):
    return MAPS[name]
