# Customizing GAUNTLET MON

You never need to touch the `engine/` folder. Everything you'd want to change
is in `settings.py` and the `data/` folder, and each file has a comment at
the top explaining its fields. Edit with any text editor (on the Pi: right
click → Text Editor, or Notepad on Windows and re-copy the file).

If the game refuses to start after an edit, you'll see the error in a terminal
if you run `python3 ~/gauntletmon/main.py` — it names the file and line.

## settings.py — the knobs

| Setting            | What it does                                            |
|--------------------|---------------------------------------------------------|
| `EXP_RATE`         | experience multiplier (1.0 = Game Boy pace, 1.5 = default) |
| `FULLSCREEN`       | `True` fills the TV, `False` opens a window            |
| `ENCOUNTER_CHANCE` | % chance of a wild creature per step in tall grass      |
| `STARTING_CASH`, `STARTING_ITEMS` | what a new game begins with            |
| `PLAYER_NAME`      | your name in the game                                   |
| `KEYS`, `PAD_BUTTONS` | control mapping                                      |

## Swapping in real art (the easy win)

Put a PNG named after the creature's `png` id (or its name) into
`sprites/creatures/` — e.g. `sprites/creatures/PIGSKLET.png` — and relaunch.
Any size works; a flat magenta (#FF00FF) or transparent background is cut out
for you. Delete the file to go back to the hand-drawn version. The ten
concept-board creatures already ship this way (see `tools/cut_boards.py`
for how they were cut out of the boards).

## data/trainers.py — the league owners

Each owner has a `party` (`[[creature, level], ...]`), an `intro`, `win`,
`lose` and `after` line, a `prize`, and a `look` (hair and shirt colors for
their overworld sprite). Change a party, change the trash talk, change the
prize — nothing else needs touching. Where they stand is in `data/maps.py`
(`"trainer": "NAME"` on an NPC, with `"sight"` and `"after_at"`).

## data/creatures.py — the roster

Each creature is one block:

```python
_c("REFBIT", no=7, type="O-LINE", subtype="LEAD BLOCK", base=[35, 38, 40, 60], catch=255, exp=40,
   moves={1: "CHIP BLOCK", 6: "AUDIBLE", 11: "PULLING GUARD", 17: "BRACE", 23: "LEAD THROUGH"},
   tier="PRACTICE SQUAD",
   palette=[(250, 250, 250), (170, 170, 170), (70, 70, 70), (20, 20, 20)],
   entry="A striped rabbit that blows a whistle when startled...")
```

- `type` is one of the 8 types; `subtype` must be one of that type's four
  subtypes (see `data/types.py`). The subtype nudges stats and names the
  passive and signature move.
- `tier`, `rarity`, `lore` are labels shown in the ROSTER (see the file header).
- `palette` colors the hand-drawn text art; `png="NAME"` points at a PNG instead.

- `base` is `[HP, ATK, DEF, SPD]`. 30 = weak, 50 = average, 80+ = great.
- `catch`: 255 = signs on the first try at low HP, 45 = a starter, 3 = legendary.
- `moves`: `{level: "MOVE"}`. Level 1 moves are known from the start.
- Add `"evolve": {"level": 16, "into": "HOGBACK"}` to make it evolve.

To **add a creature**: copy a block, give it a new name and the next `no`,
draw its sprite in `data/sprites.py` under the same name, and add it to a
map's `encounters` list so it shows up in the grass. That's all three places.

To **change the starters**: search `engine/overworld.py` for
`["PIGSKLET", "AERLING", "TURFLING"]` — that's the only engine edit you'd
ever make, and it's just a list of names.

## data/moves.py — the moves

```python
_m("STUNT", "D-LINE", 45, 100, 20, "Often dazes.", status="DAZED", chance=40)
```

`power` 0 means a status move. The `effect` options are listed at the top of
the file (raise/lower stats, inflict a status, heal, priority, high crit,
drain, recoil, multi-hit). Mix and match.

## data/types.py — the type chart, passives and subtypes

Eight types. `_ROWS` is the effectiveness matrix (attacker row vs defender
column), `PASSIVES` names each type's core passive (the engine implements all
eight), and `SUBTYPES` lists the 32 archetypes with their stat bias (HP, ATK,
DEF, SPD multipliers), passive name and signature move. `SCHEME_FIT` (1.25)
and `CRIT_MULT` (1.5) are the global combat numbers.

## data/maps.py — the world

Maps are literally drawn with characters:

```
"T.,,,,=.TTT",     T = tree   . = grass   , = TALL GRASS   = = path
```

The legend is at the top of the file. Doors need a matching `warps` entry
(`{"at": [x, y], "to": "map name", "pos": [x, y], "face": "up"}`), where
x counts from the left and y from the top, both starting at 0.

People are in `npcs`: position, sprite, facing, and the lines they say.
Give one a `"script"` of `"heal"`, `"shop"`, `"starter"` or `"gatekeeper"` and it
does that job; give one `"trainer": "NAME"` and it becomes a league owner who
challenges you on sight.

`encounters` is `[name, weight, [min level, max level]]` — weight is
relative, so `30` shows up three times as often as `10`.

Ideas that need no engine changes: a second route, a bigger town, a "gym"
building whose NPC just talks (for now), rare creatures at weight 1.

## data/sprites.py — the art

All pixel art is text. `.` transparent, `0` lightest through `3` darkest:

```
"........................",
".....33............33...",
"....3223..........3223..",
```

- Tiles are 16x16, creatures 24x24, people 16x16 with 2 walking frames.
- `TILE_PALETTES` gives each tile its four colors; `PEOPLE_PALETTES` gives
  each person skin / hair / shirt colors (owners get theirs from trainers.py).
- Every row of a picture must be the same length.
- Creatures are shown at double size in battle, so blocky is fine — that's
  the look.

Tip: draw new creatures in a monospace editor with a wide window. Copy an
existing creature that has a similar body and reshape it.

## data/items.py — shop and bag

Add an item with a `kind` of `ball`, `heal`, `cure`, `revive` or `pp`, give it
a `price`, and list it in `SHOP_STOCK` to sell it at the Pro Shop.

## Things that need a bigger engine change (ask for them)

Third-stage evolutions and football-flavored evolution triggers, League
Breaker rule-breaks, the retired legends as hidden trainers, portraits in the
dialogue box, music and sound, a naming screen, a second save slot, trading
between Pis, two-player battles over the league's network.
