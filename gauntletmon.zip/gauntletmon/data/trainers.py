"""
TRAINERS - the Gridiron Gauntlet league owners as opponents.

Each trainer:
    "name":   shown in battle ("TREVOR wants to battle!")
    "team":   their real fantasy team name
    "title":  one-line role used in dialogue boxes
    "party":  [[creature, level], ...]  (up to 6)
    "intro":  what they say when the battle starts
    "win":    what they say when YOU win
    "lose":   what they say when you lose
    "after":  what they say when you talk to them after beating them
    "prize":  cash you get for winning
    "look":   overworld sprite colors {"hair": (r,g,b), "shirt": (r,g,b)}

The order in GAUNTLET is the order you face them on the Stadium path.
"""

TRAINERS = {
    "TREVOR": {
        "name": "TREVOR", "team": "Trev's Terrible Team", "title": "The Self-Aware King",
        "party": [["REFBIT", 7], ["WHISTLET", 8]], "prize": 300,
        "look": {"hair": (200, 150, 60), "shirt": (60, 170, 90)},
        "intro": "TREVOR: 2 and 12 last year! Anyway, it can't get worse. Let's go!",
        "win": "TREVOR: Called it. That's my whole brand.",
        "lose": "TREVOR: Wait... I WON? Somebody screenshot this!",
        "after": "TREVOR: I named the team TERRIBLE for a reason. Good luck up there.",
    },
    "HAMPTON": {
        "name": "HAMPTON", "team": "Don't Call it A Comeback", "title": "The Underdog",
        "party": [["CLEATLE", 10], ["KICKOON", 11]], "prize": 450,
        "look": {"hair": (60, 40, 30), "shirt": (220, 60, 50)},
        "intro": "HAMPTON: Don't call it a comeback. I've been here for... two years.",
        "win": "HAMPTON: Fine. But the comeback starts NEXT week.",
        "lose": "HAMPTON: THAT'S a comeback!",
        "after": "HAMPTON: I dropped HERBERT once. 326 points after. Don't talk to me about it.",
    },
    "BROOKS": {
        "name": "BROOKS", "team": "Your moms Favorite team", "title": "The Riverboat Gambler",
        "party": [["BOOMBUST", 13], ["CHALKAT", 12]], "prize": 600,
        "look": {"hair": (120, 70, 30), "shirt": (230, 120, 30)},
        "intro": "BROOKS: First overall pick on a bust, TWICE. You think I'm scared of you?",
        "win": "BROOKS: Ugh. Same feeling as draft night 2019.",
        "lose": "BROOKS: Boom! That's why you gamble!",
        "after": "BROOKS: I took JAYDEN DANIELS round 1. Minus 213. Worth it? Don't answer.",
    },
    "KENNY": {
        "name": "KENNY", "team": "HurtsRentalCar", "title": "The Cursed One",
        "party": [["PYLONK", 14], ["SACKOLITH", 15]], "prize": 750,
        "look": {"hair": (40, 40, 40), "shirt": (50, 130, 70)},
        "intro": "KENNY: Three SACKOS in a row. The curse chose me. Now it chooses YOU.",
        "win": "KENNY: ...it's still mine, isn't it. The SACKO is still mine.",
        "lose": "KENNY: FINALLY! The curse passes! Wait... no. It's still here.",
        "after": "KENNY: 2014, 2015, 2016. Three straight. Pete owns me 14-3. Just... go.",
    },
    "BOB": {
        "name": "BOB", "team": "Team I drink alone", "title": "The Fallen Legend",
        "party": [["BLITZARD", 16], ["TACKLEON", 17], ["AD18N", 17]], "prize": 900,
        "look": {"hair": (110, 110, 110), "shirt": (90, 40, 130)},
        "intro": "BOB: 367.9 points. One week. Nobody has touched it. Then... the SACKO. Let's see what you've got.",
        "win": "BOB: From the mountaintop to the basement. And now this.",
        "lose": "BOB: 367.9. Never forget it.",
        "after": "BOB: I took LAMAR in round 16. Round SIXTEEN. Records are all I have left.",
    },
    "MARK": {
        "name": "MARK", "team": "lets drink a beer", "title": "The Dropper",
        "party": [["BELLCOW", 20], ["WHISTLET", 18]], "prize": 1000,
        "look": {"hair": (180, 130, 60), "shirt": (40, 110, 60)},
        "intro": "MARK: I cut JOSH ALLEN once. Don't worry, I won't cut you. Yet. Let's drink a beer after.",
        "win": "MARK: Guess I'll drop this battle too.",
        "lose": "MARK: See? Sometimes the drops work out.",
        "after": "MARK: Allen, Tannehill, Carr. I dropped them all. The scoreboard STILL roasts me.",
    },
    "JONATHAN": {
        "name": "JONATHAN", "team": "Lights KamaraAction", "title": "The Wildcard",
        "party": [["CHAINGEIST", 22], ["WAIVERN", 23], ["KICKOON", 21]], "prize": 1200,
        "look": {"hair": (30, 30, 30), "shirt": (20, 20, 20)},
        "intro": "JONATHAN: Champion in 2017. Sacko twice. Which one shows up today? Lights, camera...",
        "win": "JONATHAN: ...cut. That was the Sacko version.",
        "lose": "JONATHAN: ACTION! That's the champion version!",
        "after": "JONATHAN: Plucked HURTS off waivers for 416 points. The wire is my kingdom.",
    },
    "LOUIS": {
        "name": "LOUIS", "team": "My Dak's Bigger", "title": "The Chaotic Veteran",
        "party": [["HOGBACK", 26], ["BOOMBUST", 25], ["UPRIGHT", 24]], "prize": 1400,
        "look": {"hair": (60, 40, 30), "shirt": (30, 50, 110)},
        "intro": "LOUIS: Back-to-back champ. Also a SACKO. I've seen the top AND the bottom. Bring it!",
        "win": "LOUIS: Whatever. My Dak's still bigger.",
        "lose": "LOUIS: HA! Just like 2021 and 2022!",
        "after": "LOUIS: BAKER off waivers, 509 points. Then I named the team after DAK anyway.",
    },
    "ALAN": {
        "name": "ALAN", "team": "Almighty Shakezulas", "title": "The Tragic Tactician",
        "party": [["LOCKDOWN", 29], ["AIRHAWK", 28], ["CHALKAT", 27]], "prize": 1600,
        "look": {"hair": (80, 50, 30), "shirt": (200, 40, 40)},
        "intro": "ALAN: Best draft pick in league history. Best waiver pickup ever. Zero rings. Explain that.",
        "win": "ALAN: Perfect moves. No crown. Story of my life.",
        "lose": "ALAN: The math finally worked out!",
        "after": "ALAN: MAHOMES in round 3. Plus 283. And I still own your uncle 11-5.",
    },
    "ERIC": {
        "name": "ERIC", "team": "Team Pack Rat", "title": "The Rival",
        "party": [["WAIVERN", 31], ["SODWALL", 30], ["JOE_BURROWL", 33]], "prize": 2000,
        "look": {"hair": (200, 170, 90), "shirt": (60, 60, 70)},
        "intro": "ERIC: Defending champ. Three titles. Sure, I dropped GOFF and HERBERT. Doesn't matter. Watch this.",
        "win": "ERIC: Brilliant and careless. Today was the careless day.",
        "lose": "ERIC: Dynasty. Say it with me.",
        "after": "ERIC: JORDAN LOVE off the wire, 453 points. That's the kind of thing I do.",
    },
    "PETE": {
        "name": "PETE", "team": "TEAM PETERADI", "title": "The G.O.A.T.",
        "party": [["LOCKDOWN", 34], ["BELLCOW", 35], ["RICEIVER", 36], ["TOM_GOAT", 38]], "prize": 5000,
        "look": {"hair": (30, 30, 30), "shirt": (230, 190, 40)},
        "intro": "PETE: 13 and 1. Three titles. The logo isn't ironic. This is the GAUNTLET, kid.",
        "win": "PETE: ...Huh. Enjoy it. I'll be back next season.",
        "lose": "PETE: That's why it's on the logo.",
        "after": "PETE: Most wins ever. I own KENNY 14-3. You? You're getting there.",
    },
}

# The order you face them on the Stadium path.
GAUNTLET = ["TREVOR", "HAMPTON", "BROOKS", "KENNY", "BOB", "MARK", "JONATHAN", "LOUIS", "ALAN", "ERIC", "PETE"]

# Retired legends - not yet placed in the world (next update).
LEGENDS = {
    "DONNA": {"team": "Julio Think You Are", "note": "back-to-back champ 2015-16, retired undefeated in spirit"},
    "SISTRUNK": {"team": "Teddy's Bulgewater", "note": "inaugural 2013 champion who vanished"},
    "KNAFELC": {"team": "-", "note": "drafted Mahomes round 13 in 2018 (+215), never won"},
}


def get(name):
    return TRAINERS[name]
