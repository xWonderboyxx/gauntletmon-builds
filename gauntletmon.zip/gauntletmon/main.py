#!/usr/bin/env python3
"""
GAUNTLET MON - run this file to play.

    python3 main.py                 # window (size from settings.WINDOW_SCALE)
    python3 main.py --fullscreen    # fill the TV
    python3 main.py --scale 3       # smaller window
    python3 main.py --debug-pad     # print gamepad button numbers to the terminal
"""
import os
import sys

# Make sure imports work no matter which folder you launch from.
os.chdir(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.getcwd())

import pygame
import settings
from engine import gfx
from engine.input import Input
from engine.game import Game


def main():
    args = sys.argv[1:]
    fullscreen = settings.FULLSCREEN or "--fullscreen" in args
    if "--windowed" in args:
        fullscreen = False
    scale = settings.WINDOW_SCALE
    if "--scale" in args:
        scale = int(args[args.index("--scale") + 1])

    pygame.init()
    pygame.display.set_caption("GAUNTLET MON")
    if fullscreen:
        screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
    else:
        screen = pygame.display.set_mode((gfx.W * scale, gfx.H * scale))
    pygame.mouse.set_visible(False)

    # integer scaling with letterbox so pixels stay crisp on any TV
    sw, sh = screen.get_size()
    k = max(1, min(sw // gfx.W, sh // gfx.H))
    out_w, out_h = gfx.W * k, gfx.H * k
    ox, oy = (sw - out_w) // 2, (sh - out_h) // 2

    game = Game()
    inp = Input(debug_pad="--debug-pad" in args)
    clock = pygame.time.Clock()

    while not inp.quit and not game.quit:
        inp.poll()
        game.update(inp)
        canvas = game.draw()
        screen.fill((0, 0, 0))
        screen.blit(pygame.transform.scale(canvas, (out_w, out_h)), (ox, oy))
        pygame.display.flip()
        clock.tick(settings.FPS)

    pygame.quit()


if __name__ == "__main__":
    main()
