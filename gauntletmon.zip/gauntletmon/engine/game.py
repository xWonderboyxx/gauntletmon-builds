"""
Ties everything together: title screen -> overworld <-> battles / start menu.
"""
import pygame
import os
import settings
from engine import gfx, ui, font, save
from engine.overworld import Overworld
from engine.battle import Battle
from engine.menus import StartMenu
from data import sprites, types


class Game:
    def __init__(self):
        self.canvas = pygame.Surface((gfx.W, gfx.H))
        self.state = "title"
        self.player = None
        self.world = None
        self.battle = None
        self.menu = None
        self.frame = 0
        self.fade = 0            # >0 while a screen transition plays
        self.fade_dir = 0
        self.after_fade = None
        self.title_menu = ui.Menu((["CONTINUE", "NEW GAME"] if save.save_exists() else ["NEW GAME"]) + ["LORE"],
                                  (gfx.W - 88) // 2, 104, 88, cancel=False)
        self.intro_return_title = False
        self.quit = False

    # --- transitions --------------------------------------------------------
    def flash_transition(self, then=None):
        """Quick fade out/in (doors, battle start)."""
        self.fade, self.fade_dir, self.after_fade = 1, 1, then

    def _update_fade(self):
        self.fade += self.fade_dir
        if self.fade >= 6:
            self.fade_dir = -1
            if self.after_fade:
                cb, self.after_fade = self.after_fade, None
                cb()
        if self.fade <= 0:
            self.fade, self.fade_dir = 0, 0

    # --- state changes -------------------------------------------------------
    def new_game(self):
        self.player = save.Player()
        self.player.flags["last_heal"] = ["home", 4, 4]
        self.world = Overworld(self)
        self.state = "intro"
        self.intro_page = 0
        self.intro_timer = 0

    # The opening "lore drop": each page = (kind, subject, text). Pages auto-advance
    # like a trailer; A skips a page, START skips the whole thing.
    INTRO = [
        ("crest", None, "THE GRIDIRON GAUNTLET. Est. 2013. Twelve lifelong friends. One league. One ring. Thirteen seasons of grudges."),
        ("crest", None, "It started at NANA's house - every holiday, every party, the whole family under one roof. The league is just the family with a scoreboard."),
        ("mons", None, "In this world, football itself is alive. GAUNTLET MON roam the tall grass: PIGSKLETS, AERLINGS, TURFLINGS... and stranger legends."),
        ("types", None, "Eight types. O-LINE, RUSHING, PASSING, LINEBACKER, D-LINE, DEFENSIVE BACK, RECEIVER, SPECIALIST. Scheme beats scheme."),
        ("shot", "village", "You are {P} - GM of DAS WONDERKRIEG. Most points in league history. Unluckiest schedule ever. Zero rings."),
        ("family", None, "COURTNEY, OLIVER and ELLOWAY believe in you. They also know where you go at night. Keep it that way."),
        ("shot", "home", "Home is KICKOFF VILLAGE. Coffee's on the table. Somebody was on the roof until 3 AM again."),
        ("shot", "battle", "Catch players in football-shaped CONTRACTS. Train them. Learn the type chart or get flattened."),
        ("shot", "throw", "Every hit shakes the field. Every catch is a shot at the roster. Weaken them first - low HP makes them sign."),
        ("shot", "vs", "Then run the GAUNTLET: eleven league owners. Each has a team, a title, a grudge, and a squad built to end your season."),
        ("owner", "TREVOR", "TREV'S TERRIBLE TEAM - The Self-Aware King. Went 2 and 12 and named the team himself. Your first stop."),
        ("owner", "HAMPTON", "DON'T CALL IT A COMEBACK - The Underdog. Bobbie's college roommate. Dropped HERBERT. 326 points after."),
        ("owner", "BROOKS", "YOUR MOMS FAVORITE TEAM - Little brother. Can't whisper. Can't pause it, it's online. Traded Pop a hurt BARKLEY and still calls it fair."),
        ("owner", "KENNY", "HURTSRENTALCAR - The Cursed One. Three straight SACKOS. Shows up at the wrong house every Thanksgiving. Birthday's the 22nd. Nobody remembers."),
        ("owner", "BOB", "TEAM I DRINK ALONE - BIG BOB. Pop. 367.9 points in one week, the all-time record. Sleeveless. PABST. Cannot find the game on the TV."),
        ("owner", "MARK", "LETS DRINK A BEER - The Dropper. Uncle Mark. Cut JOSH ALLEN. Talks GATORS with Big Bob every night. Named the team AT Bob."),
        ("owner", "JONATHAN", "LIGHTS KAMARAACTION - The Wildcard. Jonboy, co-best man. Champion once, SACKO twice. Has never accepted a trade. Ever."),
        ("owner", "LOUIS", "MY DAK'S BIGGER - The Chaotic Veteran. Lo. Back-to-back champ AND a SACKO. Named the team after his worst pick."),
        ("owner", "ALAN", "ALMIGHTY SHAKEZULAS - The Tragic Tactician. Bird, co-best man. Best pick ever. Best pickup ever. Zero rings. Sound familiar?"),
        ("owner", "ERIC", "TEAM PACK RAT - The Rival. Three titles, same as Pete. SAME AS PETE. Has had McCAFFREY since the beginning. Nobody mentions the hat."),
        ("owner", "PETE", "TEAM PETERADI - The G.O.A.T. Captain of the flagship. 13 and 1. Three titles. Feels bad you keep losing to him. Truly. Everyone loves PENNY more."),
        ("hero", None, "Most points ever. Unluckiest ever. Never a ring. This year, that changes."),
        ("go", None, "CATCH. TRAIN. BATTLE. BUILD. BELONG. Bring the ring home."),
    ]
    INTRO_HOLD = 140      # frames to linger after the text finishes
    BALL_PAL = [(245, 235, 215), (150, 90, 40), (110, 60, 25), (60, 30, 10)]

    def _end_intro(self):
        if self.intro_return_title:
            self.intro_return_title = False
            self.state = "title"
            return
        self.state = "world"
        self.world.text.say(f"COURTNEY: {self.player.name}! You're finally up. COACH DUNN wants you at the FRONT OFFICE.")
        self.world.text.say("COURTNEY: It's the building at the bottom-left of town - walk straight into the dark doorway. Go on, GM.")

    def update_intro(self, inp):
        self.intro_timer += 1
        kind, subj, text = self.INTRO[min(self.intro_page, len(self.INTRO) - 1)]
        full = len(text) // 2 + self.INTRO_HOLD
        if inp.pressed("start"):
            self.flash_transition(self._end_intro)
            return
        if (inp.pressed("a") and self.intro_timer > 10) or self.intro_timer > full:
            self.intro_page += 1
            self.intro_timer = 0
            if self.intro_page >= len(self.INTRO):
                self.flash_transition(self._end_intro)

    def _intro_shot(self, name):
        key = "shot_" + name
        if not hasattr(self, key):
            try:
                img = pygame.image.load(os.path.join(gfx.SPRITE_DIR, "intro", name + ".png")).convert()
                setattr(self, key, pygame.transform.scale(img, (176, 99)))
            except Exception:
                setattr(self, key, None)
        return getattr(self, key)

    def draw_intro(self, c):
        c.fill(gfx.UI["navy"])
        c.fill(gfx.UI["cobalt"], (0, 0, gfx.W, 3))
        c.fill(gfx.UI["red"], (0, 3, gfx.W, 2))
        kind, subj, text = self.INTRO[min(self.intro_page, len(self.INTRO) - 1)]
        text = text.replace("{P}", self.player.name if self.player else "BOBBIE")
        t = self.intro_timer
        top = gfx.H - 68
        if kind == "crest":
            ball = gfx.art(sprites.BALL, palette=self.BALL_PAL, scale=4, key="introball")
            c.blit(ball, ((gfx.W - ball.get_width()) // 2, 22))
            gfx.text_center(c, gfx.W // 2, 66, "GRIDIRON GAUNTLET", gfx.UI["gold"])
            gfx.text_center(c, gfx.W // 2, 80, "EST. 2013", gfx.UI["light"])
        elif kind == "mons":
            for i, n in enumerate(["PIGSKLET", "AERLING", "TURFLING", "BELLCOW"]):
                if t > i * 12:
                    c.blit(gfx.creature_sprite(n, 72), (12 + i * 76, 28))
        elif kind == "types":
            for i, tp in enumerate(types.TYPES):
                if t > i * 6:
                    gfx.type_badge(c, 40 + (i % 4) * 64, 34 + (i // 4) * 34, tp)
        elif kind == "shot":
            img = self._intro_shot(subj)
            if img:
                x = (gfx.W - img.get_width()) // 2
                c.fill(gfx.UI["gold"], (x - 2, 7, img.get_width() + 4, img.get_height() + 4))
                c.blit(img, (x, 9))
        elif kind == "owner":
            pic = gfx.png("trainers", subj, 96)
            slide = max(0, 24 - t * 3)
            if pic:
                c.blit(pic, (gfx.W - 116 + slide, 12))
            gfx.text(c, 16, 22, "OWNER", gfx.UI["mid"])
            big = gfx.new_surface(font.text_width(subj), font.GLYPH_H)
            gfx.text(big, 0, 0, subj, gfx.UI["gold"])
            big2 = pygame.transform.scale(big, (big.get_width() * 2, big.get_height() * 2))
            big2.set_colorkey(gfx.TRANSPARENT)
            c.blit(big2, (16, 34))
            for j, mon in enumerate([m[0] for m in __import__("data.trainers", fromlist=["TRAINERS"]).TRAINERS[subj]["party"]]):
                if t > 20 + j * 8:
                    c.blit(gfx.creature_sprite(mon, 32), (16 + j * 36, 62))
        elif kind == "hero":
            pic = gfx.png("people", "PLAYER", 80)
            if pic:
                c.blit(pic, (40, 14))
            gfx.text(c, 140, 30, "DAS WONDERKRIEG", gfx.UI["gold"])
            gfx.text(c, 140, 46, "MOST POINTS EVER", gfx.UI["light"])
            gfx.text(c, 140, 58, "RINGS: 0", gfx.UI["red"])
        elif kind == "family":
            for i, n in enumerate(["COURTNEY", "OLIVER", "ELLOWAY"]):
                pic = gfx.png("people", n, 72)
                if pic and t > i * 12:
                    c.blit(pic, (48 + i * 80, 16))
        else:
            ball = gfx.art(sprites.BALL, palette=self.BALL_PAL, scale=3, key="introball3")
            c.blit(ball, ((gfx.W - ball.get_width()) // 2 + (t % 40) - 20, 24))
            gfx.text_center(c, gfx.W // 2, 60, "CATCH - TRAIN - BATTLE", gfx.UI["gold"])
            gfx.text_center(c, gfx.W // 2, 72, "BUILD - BELONG", gfx.UI["gold"])
        gfx.box(c, 0, top, gfx.W, 68)
        shown = min(len(text), t * 2)
        y = top + 8
        for line in gfx.wrap(text[:shown], ui.CHARS_PER_LINE)[:4]:
            gfx.text(c, 8, y, line)
            y += 12
        gfx.text_right(c, gfx.W - 8, gfx.H - 12, f"{self.intro_page + 1}/{len(self.INTRO)}   A: NEXT  START: SKIP", gfx.UI["mid"])

    def continue_game(self):
        self.player = save.load_game()
        self.world = Overworld(self)
        self.state = "world"

    def start_battle(self, wild, trainer=None):
        def go():
            self.battle = Battle(self, wild, trainer=trainer)
            self.state = "battle"
        self.flash_transition(go)

    def end_battle(self):
        result = self.battle.result
        self.battle = None
        self.state = "world"
        self.world.after_battle(result)
        if result == "lose":
            self.blackout()

    def blackout(self):
        p = self.player
        p.heal_all()
        m, x, y = p.flags.get("last_heal", ["home", 4, 4])
        p.x, p.y, p.facing = x, y, "down"
        self.world.load_map(m)
        self.world.text.say(f"{p.name} hurried back home and rested up... Everyone is healed.")

    def open_start_menu(self):
        self.menu = StartMenu(self)
        self.state = "menu"

    # --- main loop pieces ----------------------------------------------------
    def update(self, inp):
        self.frame += 1
        if self.fade_dir:
            self._update_fade()
            return
        if self.state == "title":
            choice = self.title_menu.update(inp)
            if choice is not None:
                pick = self.title_menu.items[choice]
                if pick == "CONTINUE":
                    self.flash_transition(self.continue_game)
                elif pick == "LORE":
                    def lore():
                        self.state, self.intro_page, self.intro_timer = "intro", 0, 0
                        self.intro_return_title = True
                    self.flash_transition(lore)
                else:
                    self.flash_transition(self.new_game)
        elif self.state == "intro":
            self.update_intro(inp)
        elif self.state == "world":
            self.world.update(inp)
        elif self.state == "battle":
            self.battle.update(inp)
            if self.battle.done:
                self.flash_transition(self.end_battle)
        elif self.state == "menu":
            self.menu.update(inp)
            if self.menu.closed:
                self.menu = None
                self.state = "world"

    def draw(self):
        c = self.canvas
        if self.state == "title":
            self.draw_title(c)
        elif self.state == "intro":
            self.draw_intro(c)
        elif self.state == "world":
            self.world.draw(c)
        elif self.state == "battle":
            self.battle.draw(c)
        elif self.state == "menu":
            self.world.draw(c)
            self.menu.draw(c)
        if self.fade:
            gfx.fade_step(c, min(3, self.fade))
        return c

    def draw_title(self, c):
        c.fill(gfx.UI["navy"])
        c.fill(gfx.UI["cobalt"], (0, 0, gfx.W, 3))
        c.fill(gfx.UI["red"], (0, 3, gfx.W, 2))
        if not hasattr(self, "_logo"):
            small = gfx.new_surface(font.text_width("GAUNTLET MON"), font.GLYPH_H)
            gfx.text(small, 0, 0, "GAUNTLET MON", gfx.UI["gold"])
            self._logo = pygame.transform.scale(small, (small.get_width() * 3, small.get_height() * 3))
            self._logo.set_colorkey(gfx.TRANSPARENT)
        c.blit(self._logo, ((gfx.W - self._logo.get_width()) // 2, 14))
        gfx.text_center(c, gfx.W // 2, 40, "GRIDIRON GAUNTLET EDITION", gfx.UI["light"])
        # parade of creatures
        names = ["BELLCOW", "LOCKDOWN", "PIGSKLET", "WAIVERN", "AERLING", "BOOMBUST", "TURFLING", "CHAINGEIST", "TOM_GOAT"]
        i = (self.frame // 100) % len(names)
        c.blit(gfx.creature_sprite(names[i], 80), (16, 60))
        c.blit(gfx.creature_sprite(names[(i + 4) % len(names)], 80, mirror=True), (gfx.W - 96, 60))
        gfx.text_center(c, gfx.W // 2, 64, "CATCH - BATTLE", gfx.UI["gold"])
        gfx.text_center(c, gfx.W // 2, 78, "BUILD - AVENGE", gfx.UI["gold"])
        self.title_menu.draw(c)
        if (self.frame // 30) % 2 == 0:
            gfx.text_center(c, gfx.W // 2, gfx.H - 14, "PRESS Z TO START", gfx.UI["light"])
        gfx.text(c, 4, gfx.H - 10, "V0.6", gfx.UI["mid"])
