"""
Reusable UI pieces: the bottom text box (typewriter text, paged) and a
vertical cursor menu drawn inside a frame.
"""
import settings
from engine import gfx, font

BOX_H = 48
BOX_Y = gfx.H - BOX_H
CHARS_PER_LINE = (gfx.W - 16) // font.ADVANCE - 1


class TextBox:
    """
    Queue messages with say(). Each frame call update(inp) then draw(surf).
    `busy` is True while there is text left to show / waiting for A.
    """

    def __init__(self):
        self.pages = []       # list of [line1, line2]
        self.page = 0
        self.shown = 0        # characters revealed on the current page
        self.waiting = False  # finished revealing, waiting for A
        self.auto = False     # advance without a button press (for battle flow)
        self.after = None     # callback when everything is finished
        self.portrait = None  # name of a sprites/people PNG to show beside the text

    @property
    def busy(self):
        return bool(self.pages)

    def say(self, message, auto=False, after=None):
        """Add a message. Long messages become multiple 2-line pages."""
        lines = gfx.wrap(message, CHARS_PER_LINE)
        for i in range(0, len(lines), 2):
            self.pages.append(lines[i:i + 2])
        self.auto = auto
        if after:
            self.after = after

    def clear(self):
        self.pages, self.page, self.shown, self.waiting = [], 0, 0, False
        self.portrait = None

    def update(self, inp):
        if not self.pages:
            return
        total = sum(len(l) for l in self.pages[self.page])
        if self.shown < total:
            speed = settings.TEXT_SPEED * (3 if inp.held("a") or inp.held("b") else 1)
            self.shown = min(total, self.shown + speed)
            if self.shown >= total:
                self.waiting = True
                self._wait_frames = 0
            return
        self._wait_frames = getattr(self, "_wait_frames", 0) + 1
        advance = inp.pressed("a") or inp.pressed("b") or (self.auto and self._wait_frames > 40)
        if advance:
            self.page += 1
            self.shown = 0
            self.waiting = False
            if self.page >= len(self.pages):
                self.clear()
                cb, self.after = self.after, None
                if cb:
                    cb()

    def draw(self, surf, frame=0):
        gfx.box(surf, 0, BOX_Y, gfx.W, BOX_H)
        if not self.pages:
            return
        if self.portrait:
            pic = gfx.png("people", self.portrait, 64)
            if pic:
                gfx.box(surf, gfx.W - 74, BOX_Y - 74, 74, 76)
                surf.blit(pic, (gfx.W - 69, BOX_Y - 68))
        lines = self.pages[self.page]
        left = self.shown
        y = BOX_Y + 12
        for line in lines:
            part = line[:left]
            left -= len(part)
            gfx.text(surf, 8, y, part)
            y += 16
        if self.waiting and not self.auto and (frame // 20) % 2 == 0:
            gfx.text(surf, gfx.W - 14, BOX_Y + BOX_H - 12, font.MORE)


class Menu:
    """A framed vertical menu. Returns the chosen index from update(), or None."""

    def __init__(self, items, x, y, w=None, cancel=True, cols=1, index=0, line_h=16, pad=7, h=None, visible=None):
        self.items = list(items)
        self.x, self.y = x, y
        self.cols = cols
        self.line_h = line_h
        rows = (len(self.items) + cols - 1) // cols
        self.visible = min(visible or rows, rows) or 1   # rows shown at once (scrolls if fewer than rows)
        self.scroll = 0
        rows = self.visible
        longest = max(len(i) for i in self.items) if self.items else 4
        self.col_w = longest * font.ADVANCE + 12
        self.w = w or (self.col_w * cols + 8)
        self.h = h or (rows * line_h + 12)
        self.pad = pad
        self.index = index
        self.cancel = cancel
        self.cancelled = False

    def update(self, inp):
        n = len(self.items)
        if n == 0:
            return None
        if self.cols == 1:
            if inp.repeat("up"):
                self.index = (self.index - 1) % n
            if inp.repeat("down"):
                self.index = (self.index + 1) % n
        else:
            r, c = divmod(self.index, self.cols)
            rows = (n + self.cols - 1) // self.cols
            if inp.repeat("up"):
                r = (r - 1) % rows
            if inp.repeat("down"):
                r = (r + 1) % rows
            if inp.repeat("left"):
                c = (c - 1) % self.cols
            if inp.repeat("right"):
                c = (c + 1) % self.cols
            self.index = min(n - 1, r * self.cols + c)
        r = self.index // self.cols
        if r < self.scroll:
            self.scroll = r
        elif r >= self.scroll + self.visible:
            self.scroll = r - self.visible + 1
        if inp.pressed("a"):
            return self.index
        if self.cancel and inp.pressed("b"):
            self.cancelled = True
        return None

    def draw(self, surf, disabled=()):
        gfx.box(surf, self.x, self.y, self.w, self.h)
        for i, item in enumerate(self.items):
            r, c = divmod(i, self.cols)
            r -= self.scroll
            if r < 0 or r >= self.visible:
                continue
            px = self.x + 6 + c * self.col_w
            py = self.y + self.pad + r * self.line_h
            ink = 1 if i in disabled else 3
            gfx.text(surf, px + 8, py, item, ink)
            if i == self.index:
                gfx.text(surf, px, py, font.CURSOR)
