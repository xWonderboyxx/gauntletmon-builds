"""
ITEMS. "kind" decides what the item does:
    "ball":   throw at a wild creature to sign it. "rate" multiplies the catch chance.
    "heal":   restore "amount" HP to one creature
    "cure":   remove a status condition
    "revive": bring back a fainted creature with half HP
    "pp":     restore all PP to one creature's moves
"price" is what the PRO SHOP charges (0 = not for sale).
"""

ITEMS = {
    "CONTRACT":     {"kind": "ball", "rate": 1.0, "price": 200,
                     "desc": "Sign a wild player."},
    "PRO CONTRACT": {"kind": "ball", "rate": 1.5, "price": 600,
                     "desc": "A better offer."},
    "SPORTS DRINK": {"kind": "heal", "amount": 20, "price": 300,
                     "desc": "Restores 20 HP."},
    "ENERGY GEL":   {"kind": "heal", "amount": 50, "price": 700,
                     "desc": "Restores 50 HP."},
    "ICE PACK":     {"kind": "cure", "price": 250,
                     "desc": "Cures any status."},
    "SMELLING SALTS": {"kind": "revive", "price": 1500,
                     "desc": "Revives a fainted pal."},
    "GATOR JUICE":  {"kind": "pp", "price": 900,
                     "desc": "Restores all PP."},
}

SHOP_STOCK = ["CONTRACT", "SPORTS DRINK", "ICE PACK", "ENERGY GEL", "PRO CONTRACT"]


def get(name):
    return ITEMS[name]
