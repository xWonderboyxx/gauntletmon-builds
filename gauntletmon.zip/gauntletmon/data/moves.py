"""
MOVES. Each move:
    "type":  one of the 8 TYPES (same-type users get the 1.25x Scheme Fit bonus)
    "power": 0 for a non-damaging move
    "acc":   accuracy in percent
    "pp":    uses before resting at the Locker Room
    "desc":  short text for menus (about 22 letters)
    "effect": optional extras -
        {"status": "DAZED", "chance": 30}          -> chance to inflict a status
        {"stat": "ATK", "stages": 1}               -> raise the USER's stat
        {"stat": "DEF", "stages": -1, "target": "foe"} -> lower the FOE's stat
        {"heal": 0.5}                              -> heal 50% of max HP
        {"priority": 1}                            -> goes first
        {"crit": "high"}                           -> high critical-hit ratio
        {"drain": 0.5}                             -> heal half the damage dealt
        {"recoil": 0.25}                           -> take a quarter of damage dealt
        {"multi": [2, 5]}                          -> hit 2-5 times
        {"gamble": 0.5}                            -> 50%: double power, else it misses
        {"guard": true}                            -> halve the next hit taken
        {"walkoff": true}                          -> power rises as the user's HP falls

Statuses: DAZED (may lose a turn, slower), CRAMP (hurts each turn),
          GASSED (asleep 1-3 turns), TURFBURN (hurts each turn, weaker attacks)
"""

MOVES = {}


def _m(name, type_, power, acc, pp, desc, **effect):
    MOVES[name] = {"type": type_, "power": power, "acc": acc, "pp": pp, "desc": desc}
    if effect:
        MOVES[name]["effect"] = effect


# --- O-LINE --------------------------------------------------------------
_m("CHIP BLOCK", "O-LINE", 35, 100, 35, "A quick shove.")
_m("DOUBLE TEAM", "O-LINE", 50, 100, 25, "Two-man push.")
_m("PANCAKE", "O-LINE", 75, 95, 15, "Flatten them.")
_m("HOLD THE POCKET", "O-LINE", 0, 100, 20, "Raises DEF.", stat="DEF", stages=1)
_m("PULLING GUARD", "O-LINE", 60, 100, 20, "Raises SPD after.", stat="SPD", stages=1)
_m("BRACE", "O-LINE", 0, 100, 10, "Halves next hit.", guard=True)
_m("NO PRESSURE", "O-LINE", 0, 100, 10, "DEF up, heals some.", stat="DEF", stages=1, heal=0.25)     # BRICK WALL sig
_m("SET THE POCKET", "O-LINE", 55, 100, 15, "Hit and brace.", guard=True)                        # ANCHOR sig
_m("LEAD THROUGH", "O-LINE", 65, 100, 15, "Priority push.", priority=1)                          # LEAD BLOCK sig
_m("FINISH THE BLOCK", "O-LINE", 90, 90, 10, "Recoil hit.", recoil=0.2)                          # MAULER sig
# --- RUSHING -------------------------------------------------------------
_m("CARRY", "RUSHING", 40, 100, 35, "Basic run.")
_m("STIFF ARM", "RUSHING", 60, 100, 25, "Shove them off.")
_m("CUTBACK", "RUSHING", 50, 100, 20, "Often a crit.", crit="high")
_m("GOAL-LINE DIVE", "RUSHING", 100, 85, 10, "All or nothing.")
_m("SPIN MOVE", "RUSHING", 45, 100, 25, "Raises SPD.", stat="SPD", stages=1)
_m("TRUCK STICK", "RUSHING", 85, 95, 15, "Run right through.", recoil=0.25)                      # BRUISER sig
_m("FEED ME", "RUSHING", 70, 100, 15, "Heals half dealt.", drain=0.5)                            # BELL-COW sig
_m("BREAKAWAY", "RUSHING", 80, 90, 10, "Always first.", priority=1)                              # SPEEDSTER sig
_m("ANGLE ROUTE", "RUSHING", 60, 100, 15, "Lowers foe DEF.", stat="DEF", stages=-1, target="foe")  # SCATBACK sig
# --- PASSING -------------------------------------------------------------
_m("SCREEN PASS", "PASSING", 40, 100, 30, "Quick and safe.")
_m("SLANT", "PASSING", 55, 100, 25, "Sharp cut inside.")
_m("DEEP BALL", "PASSING", 90, 80, 10, "Go long!")
_m("HAIL MARY", "PASSING", 120, 60, 5, "Pray it lands.")
_m("PLAY ACTION", "PASSING", 60, 100, 15, "May daze the foe.", status="DAZED", chance=30)
_m("AUDIBLE", "PASSING", 0, 100, 20, "Lowers foe ATK.", stat="ATK", stages=-1, target="foe")
_m("BACK-SHOULDER DART", "PASSING", 70, 100, 15, "Never misses. Crits.", crit="high")            # SNIPER sig
_m("HERO BALL", "PASSING", 80, 100, 10, "Double or nothing.", gamble=0.5)                        # GUNSLINGER sig
_m("READ OPTION", "PASSING", 65, 100, 15, "Raises SPD.", stat="SPD", stages=1)                   # DUAL THREAT sig
_m("CHECK WITH ME", "PASSING", 50, 100, 20, "Lowers foe SPD.", stat="SPD", stages=-1, target="foe")  # FIELD GENERAL sig
# --- LINEBACKER ----------------------------------------------------------
_m("RUN FIT", "LINEBACKER", 45, 100, 30, "Fill the hole.")
_m("SPY", "LINEBACKER", 0, 100, 20, "Raises SPD.", stat="SPD", stages=1)
_m("A-GAP BLITZ", "LINEBACKER", 70, 95, 15, "Through the middle.")
_m("GREEN DOT", "LINEBACKER", 0, 100, 15, "Raises ATK.", stat="ATK", stages=1)
_m("WRAP UP", "LINEBACKER", 55, 100, 20, "May cramp the foe.", status="CRAMP", chance=30)
_m("SHOOT THE GAP", "LINEBACKER", 85, 90, 10, "Priority strike.", priority=1)                    # BLITZ sig
_m("CARRY THE SEAM", "LINEBACKER", 60, 100, 15, "Hits and gets faster.", stat="SPD", stages=1)   # COVERAGE sig
_m("STONE THE BACK", "LINEBACKER", 80, 100, 10, "DEF up after.", stat="DEF", stages=1)            # RUN STUFFER sig
_m("CHECK THE FRONT", "LINEBACKER", 0, 100, 10, "Foe ATK down.", stat="ATK", stages=-1, target="foe")  # MIKE sig
# --- D-LINE --------------------------------------------------------------
_m("BULL RUSH", "D-LINE", 55, 100, 25, "Straight ahead.")
_m("SWIM MOVE", "D-LINE", 50, 100, 20, "Often a crit.", crit="high")
_m("SACK", "D-LINE", 80, 95, 15, "Big loss of yards.")
_m("TWO-GAP", "D-LINE", 0, 100, 15, "Raises DEF.", stat="DEF", stages=1)
_m("STUNT", "D-LINE", 45, 100, 20, "Often dazes.", status="DAZED", chance=40)
_m("STRIP SACK", "D-LINE", 90, 90, 10, "Foe ATK down.", stat="ATK", stages=-1, target="foe")    # SACK ARTIST sig
_m("COLLAPSE POCKET", "D-LINE", 65, 100, 15, "Foe SPD down.", stat="SPD", stages=-1, target="foe")  # DISRUPTER sig
_m("NOT AN INCH", "D-LINE", 60, 100, 15, "Hit and brace.", guard=True)                            # IMMOVABLE OBJECT sig
_m("EAT THE DOUBLE", "D-LINE", 0, 100, 10, "DEF up, heals some.", stat="DEF", stages=1, heal=0.25)  # NOSE TACKLE sig
# --- DEFENSIVE BACK ------------------------------------------------------
_m("JAM", "DEFENSIVE BACK", 40, 100, 30, "Press at the line.")
_m("PRESS MAN", "DEFENSIVE BACK", 55, 100, 20, "Foe SPD down.", stat="SPD", stages=-1, target="foe")
_m("BALL HAWK", "DEFENSIVE BACK", 65, 95, 15, "Often a crit.", crit="high")
_m("CENTER FIELD", "DEFENSIVE BACK", 0, 100, 20, "Raises SPD.", stat="SPD", stages=1)
_m("STRIP", "DEFENSIVE BACK", 50, 100, 20, "May cramp the foe.", status="CRAMP", chance=30)
_m("PICK SIX", "DEFENSIVE BACK", 95, 85, 10, "Heals half dealt.", drain=0.5)                     # BALL HAWK sig
_m("ERASE", "DEFENSIVE BACK", 70, 100, 15, "Foe ATK down.", stat="ATK", stages=-1, target="foe")  # SHUT DOWN sig
_m("BIG HIT", "DEFENSIVE BACK", 85, 90, 10, "May daze.", status="DAZED", chance=30)               # ENFORCER sig
_m("OVER THE TOP", "DEFENSIVE BACK", 60, 100, 15, "Always first.", priority=1)                   # ROAMING sig
# --- RECEIVER ------------------------------------------------------------
_m("RELEASE", "RECEIVER", 40, 100, 35, "Off the line.")
_m("CROSSER", "RECEIVER", 55, 100, 25, "Across the middle.")
_m("TAKE THE TOP OFF", "RECEIVER", 90, 85, 10, "Burn them deep.")
_m("STUTTER STEP", "RECEIVER", 0, 100, 20, "Raises SPD.", stat="SPD", stages=1)
_m("TOE TAP", "RECEIVER", 50, 100, 20, "Often a crit.", crit="high")
_m("MOSSED", "RECEIVER", 95, 90, 10, "Foe DEF down.", stat="DEF", stages=-1, target="foe")       # ALPHA sig
_m("CATCH & RUN", "RECEIVER", 60, 100, 15, "SPD up after.", stat="SPD", stages=1)                # YAC sig
_m("GO ROUTE", "RECEIVER", 85, 90, 10, "Priority deep shot.", priority=1)                         # DEEP THREAT sig
_m("SEAM SPLITTER", "RECEIVER", 70, 100, 15, "Heals some dealt.", drain=0.3)                     # TIGHT END sig
# --- SPECIALIST ----------------------------------------------------------
_m("PUNT", "SPECIALIST", 45, 100, 25, "Boot it away.")
_m("FIELD GOAL", "SPECIALIST", 65, 95, 15, "Split the uprights.")
_m("ONSIDE KICK", "SPECIALIST", 35, 100, 20, "Always first.", priority=1)
_m("SQUIB KICK", "SPECIALIST", 50, 100, 15, "May cramp the foe.", status="CRAMP", chance=30)
_m("FAIR CATCH", "SPECIALIST", 0, 100, 10, "Heals half HP.", heal=0.5)
_m("WHISTLE", "SPECIALIST", 0, 100, 20, "Lowers foe ATK.", stat="ATK", stages=-1, target="foe")
_m("WALK-OFF", "SPECIALIST", 60, 100, 10, "Stronger when hurt.", walkoff=True)                           # KICKER sig
_m("COFFIN CORNER", "SPECIALIST", 55, 100, 15, "Foe SPD down.", stat="SPD", stages=-1, target="foe")  # PUNTER sig
_m("HOUSE CALL", "SPECIALIST", 90, 85, 10, "Priority return.", priority=1)                        # KICK RETURNER sig
_m("SNAP HOLD KICK", "SPECIALIST", 20, 90, 15, "Hits 3 times.", multi=[3, 3])                     # LONG SNAPPER sig
_m("FAKE INJURY", "SPECIALIST", 0, 75, 10, "Puts foe to sleep.", status="GASSED", chance=100)


def get(name):
    return MOVES[name]
