"""
Cut a subject out of a magenta panel given a rough grid cell around it.
The cell may include panel borders: we shrink to the magenta panel's extent,
then key the magenta out. Usage in code: cut_cell(board, (x0,y0,x1,y1), out, size)
"""
import numpy as np
from PIL import Image


def cut_cell(board, cell, out_path, size=80, bottom_align=True, strip_labels=True):
    im = np.array(Image.open(board).convert("RGB")).astype(int)
    x0, y0, x1, y1 = cell
    sub = im[y0:y1, x0:x1]
    r, g, b = sub[..., 0], sub[..., 1], sub[..., 2]
    mag = (r > 150) & (b > 150) & (g < 130) & (abs(r - b) < 90)
    ys, xs = np.where(mag)
    # the magenta panel's extent inside the cell
    px0, py0, px1, py1 = xs.min(), ys.min(), xs.max() + 1, ys.max() + 1
    sub = sub[py0:py1, px0:px1]
    mag = mag[py0:py1, px0:px1]
    keep = ~mag
    keep[:2, :] = keep[-2:, :] = False
    keep[:, :2] = keep[:, -2:] = False
    # a dark name label overlaid on the bottom of the panel: wide dark runs of non-magenta rows
    bright = sub.sum(axis=2)
    H, W = keep.shape
    dark = keep & (bright < 190)
    for y in (range(H - 1, int(H * 0.62), -1) if strip_labels else []):
        if dark[y].sum() > 0.38 * W:
            xs_d = np.where(dark[y])[0]
            keep[max(0, y - 3):y + 2, max(0, xs_d.min() - 2):xs_d.max() + 3] = False
    # keep the main subject: largest blob plus anything near it (drops panel-border slivers)
    from scipy import ndimage
    lab, n = ndimage.label(keep, structure=np.ones((3, 3)))
    if n > 1:
        sizes = ndimage.sum(keep, lab, range(1, n + 1))
        big = int(np.argmax(sizes)) + 1
        ys, xs = np.where(lab == big)
        bx0, by0, bx1, by1 = xs.min() - 8, ys.min() - 8, xs.max() + 8, ys.max() + 8
        for i in range(1, n + 1):
            if i == big:
                continue
            cy, cx = np.where(lab == i)
            if cx.min() > bx1 or cx.max() < bx0 or cy.min() > by1 or cy.max() < by0 or sizes[i - 1] < 30:
                keep[lab == i] = False
    ys, xs = np.where(keep)
    bx0, by0, bx1, by1 = xs.min(), ys.min(), xs.max() + 1, ys.max() + 1
    crop = sub[by0:by1, bx0:bx1]
    alpha = keep[by0:by1, bx0:bx1]
    rgba = np.dstack([crop, alpha * 255]).astype(np.uint8)
    img = Image.fromarray(rgba, "RGBA")
    w, h = img.size
    s = size / max(w, h)
    img = img.resize((max(1, round(w * s)), max(1, round(h * s))), Image.BOX)
    canvas = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    y = size - img.height if bottom_align else (size - img.height) // 2
    canvas.paste(img, ((size - img.width) // 2, y))
    a = np.array(canvas)
    a[..., 3] = np.where(a[..., 3] > 110, 255, 0)
    Image.fromarray(a, "RGBA").save(out_path)
    return (w, h)
