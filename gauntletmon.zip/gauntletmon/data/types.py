"""
TYPES - the eight football positions every creature and move belongs to,
plus the 32 SUBTYPES (archetypes) that flavor a creature's stats and passive.

Source of truth: GAUNTLET_MON_RULES_SOURCE_OF_TRUTH.xlsx (v10).
2.0 = super effective, 0.5 = not very effective, 1.0 = normal. No immunities.
PASSING vs D-LINE is 2x BOTH ways on purpose (pressure vs. quick passing).
"""

TYPES = ["O-LINE", "RUSHING", "PASSING", "LINEBACKER", "D-LINE", "DEFENSIVE BACK", "RECEIVER", "SPECIALIST"]

ABBR = {"O-LINE": "OL", "RUSHING": "RB", "PASSING": "QB", "LINEBACKER": "LB",
        "D-LINE": "DL", "DEFENSIVE BACK": "DB", "RECEIVER": "WR", "SPECIALIST": "ST"}

# short labels for tight UI spots (max 6 letters)
SHORT = {"O-LINE": "O-LINE", "RUSHING": "RUSH", "PASSING": "PASS", "LINEBACKER": "LB",
         "D-LINE": "D-LINE", "DEFENSIVE BACK": "DB", "RECEIVER": "WR", "SPECIALIST": "SPEC"}

# CHART[attacking][defending]  (rows = attacker, in TYPES order)
_ROWS = {
    "O-LINE":         [1, 1, 1, 1, 2, 2, 0.5, 0.5],
    "RUSHING":        [1, 1, 1, 0.5, 0.5, 2, 1, 2],
    "PASSING":        [1, 1, 1, 2, 2, 0.5, 1, 1],
    "LINEBACKER":     [1, 2, 0.5, 1, 1, 1, 0.5, 2],
    "D-LINE":         [0.5, 2, 2, 1, 1, 1, 1, 1],
    "DEFENSIVE BACK": [0.5, 0.5, 2, 1, 1, 1, 2, 1],
    "RECEIVER":       [2, 1, 1, 2, 1, 0.5, 1, 0.5],
    "SPECIALIST":     [2, 0.5, 1, 0.5, 1, 1, 2, 1],
}
CHART = {a: {d: float(v) for d, v in zip(TYPES, row)} for a, row in _ROWS.items()}

# UI color per type (RGB) - used for type badges
COLORS = {
    "O-LINE": (120, 130, 145), "RUSHING": (200, 60, 50), "PASSING": (60, 110, 220),
    "LINEBACKER": (80, 70, 110), "D-LINE": (90, 90, 90), "DEFENSIVE BACK": (30, 40, 90),
    "RECEIVER": (230, 150, 40), "SPECIALIST": (240, 200, 40),
}

# Core passive of each type. "impl" says how the battle engine applies it.
PASSIVES = {
    "O-LINE":         {"name": "POCKET WALL", "desc": "First hit taken each battle is 30% weaker.",
                       "impl": "first_hit_reduce"},
    "RUSHING":        {"name": "MOMENTUM", "desc": "Each straight hit adds +10% power (max +30%).",
                       "impl": "momentum"},
    "PASSING":        {"name": "READ THE DEFENSE", "desc": "After a miss or resisted hit, next move +20% acc, +15% power.",
                       "impl": "read_defense"},
    "LINEBACKER":     {"name": "READ & REACT", "desc": "After the foe's status move, next hit +15% power and speed up.",
                       "impl": "read_react"},
    "D-LINE":         {"name": "POCKET COLLAPSE", "desc": "Hits have a 25% chance to lower foe SPD (40% vs PASSING).",
                       "impl": "pocket_collapse"},
    "DEFENSIVE BACK": {"name": "COVERAGE", "desc": "First attack aimed at it each battle is 20% less accurate.",
                       "impl": "coverage"},
    "RECEIVER":       {"name": "SEPARATION", "desc": "Moving first gives +15% power; a super hit gives +1 SPD.",
                       "impl": "separation"},
    "SPECIALIST":     {"name": "CLUTCH WINDOW", "desc": "Below 1/3 HP its moves gain priority and crit more.",
                       "impl": "clutch"},
}

# Subtypes: stat bias is applied to base stats (multiplier on HP/ATK/DEF/SPD),
# 'sig' is the signature move (must exist in data/moves.py).
SUBTYPES = {
    # PASSING
    "SNIPER":        {"type": "PASSING", "role": "precision", "bias": [1.0, 1.1, 1.0, 1.0], "passive": "WINDOW THROW", "sig": "BACK-SHOULDER DART"},
    "GUNSLINGER":    {"type": "PASSING", "role": "hero ball", "bias": [0.95, 1.15, 0.9, 1.05], "passive": "NO FEAR", "sig": "HERO BALL"},
    "DUAL THREAT":   {"type": "PASSING", "role": "mobility", "bias": [1.0, 1.0, 1.0, 1.15], "passive": "SCRAMBLE", "sig": "READ OPTION"},
    "FIELD GENERAL": {"type": "PASSING", "role": "control", "bias": [1.1, 1.0, 1.05, 1.0], "passive": "AUDIBLE", "sig": "CHECK WITH ME"},
    # RUSHING
    "BELL-COW":      {"type": "RUSHING", "role": "volume", "bias": [1.15, 1.05, 1.0, 0.95], "passive": "WORKLOAD", "sig": "FEED ME"},
    "SPEEDSTER":     {"type": "RUSHING", "role": "home-run speed", "bias": [0.9, 1.0, 0.9, 1.25], "passive": "OPEN FIELD", "sig": "BREAKAWAY"},
    "SCATBACK":      {"type": "RUSHING", "role": "mismatch", "bias": [0.95, 1.0, 0.95, 1.15], "passive": "MISMATCH", "sig": "ANGLE ROUTE"},
    "BRUISER":       {"type": "RUSHING", "role": "contact", "bias": [1.05, 1.15, 1.05, 0.9], "passive": "YARDS AFTER CONTACT", "sig": "TRUCK STICK"},
    # RECEIVER
    "ALPHA":         {"type": "RECEIVER", "role": "WR1", "bias": [1.0, 1.15, 1.0, 1.05], "passive": "TARGET SHARE", "sig": "MOSSED"},
    "YAC":           {"type": "RECEIVER", "role": "catch and run", "bias": [1.0, 1.05, 0.95, 1.15], "passive": "YAC", "sig": "CATCH & RUN"},
    "DEEP THREAT":   {"type": "RECEIVER", "role": "vertical", "bias": [0.9, 1.1, 0.9, 1.25], "passive": "TAKE THE TOP OFF", "sig": "GO ROUTE"},
    "TIGHT END":     {"type": "RECEIVER", "role": "big body", "bias": [1.15, 1.05, 1.1, 0.85], "passive": "CHIP RELEASE", "sig": "SEAM SPLITTER"},
    # O-LINE
    "MAULER":        {"type": "O-LINE", "role": "aggressive", "bias": [1.05, 1.15, 1.05, 0.9], "passive": "FINISH THE BLOCK", "sig": "PANCAKE"},
    "BRICK WALL":    {"type": "O-LINE", "role": "pass pro", "bias": [1.15, 0.9, 1.25, 0.8], "passive": "STONEWALL", "sig": "NO PRESSURE"},
    "ANCHOR":        {"type": "O-LINE", "role": "center", "bias": [1.1, 1.0, 1.1, 0.9], "passive": "ANCHOR THE POCKET", "sig": "SET THE POCKET"},
    "LEAD BLOCK":    {"type": "O-LINE", "role": "mobile", "bias": [1.0, 1.05, 1.0, 1.1], "passive": "PULL", "sig": "LEAD THROUGH"},
    # LINEBACKER
    "MIKE":          {"type": "LINEBACKER", "role": "defensive QB", "bias": [1.1, 1.0, 1.1, 0.95], "passive": "GREEN DOT", "sig": "CHECK THE FRONT"},
    "COVERAGE":      {"type": "LINEBACKER", "role": "space", "bias": [1.0, 0.95, 1.05, 1.15], "passive": "HOOK ZONE", "sig": "CARRY THE SEAM"},
    "BLITZ":         {"type": "LINEBACKER", "role": "pressure", "bias": [0.95, 1.2, 0.9, 1.1], "passive": "TIMED UP", "sig": "SHOOT THE GAP"},
    "RUN STUFFER":   {"type": "LINEBACKER", "role": "downhill", "bias": [1.1, 1.1, 1.1, 0.85], "passive": "FIT THE GAP", "sig": "STONE THE BACK"},
    # D-LINE
    "NOSE TACKLE":   {"type": "D-LINE", "role": "interior anchor", "bias": [1.2, 1.0, 1.2, 0.75], "passive": "TWO-GAP", "sig": "EAT THE DOUBLE"},
    "IMMOVABLE OBJECT": {"type": "D-LINE", "role": "goal line", "bias": [1.25, 0.95, 1.3, 0.7], "passive": "GOAL-LINE STAND", "sig": "NOT AN INCH"},
    "SACK ARTIST":   {"type": "D-LINE", "role": "QB hunter", "bias": [0.95, 1.2, 0.95, 1.1], "passive": "GET-OFF", "sig": "STRIP SACK"},
    "DISRUPTER":     {"type": "D-LINE", "role": "havoc", "bias": [1.0, 1.05, 1.0, 1.1], "passive": "HAVOC", "sig": "COLLAPSE POCKET"},
    # DEFENSIVE BACK
    "SHUT DOWN":     {"type": "DEFENSIVE BACK", "role": "eraser", "bias": [1.0, 1.0, 1.15, 1.1], "passive": "ISLAND", "sig": "ERASE"},
    "BALL HAWK":     {"type": "DEFENSIVE BACK", "role": "turnovers", "bias": [0.95, 1.1, 0.95, 1.2], "passive": "JUMP THE ROUTE", "sig": "PICK SIX"},
    "ENFORCER":      {"type": "DEFENSIVE BACK", "role": "physical", "bias": [1.1, 1.15, 1.0, 0.95], "passive": "TONE SETTER", "sig": "BIG HIT"},
    "ROAMING":       {"type": "DEFENSIVE BACK", "role": "free safety", "bias": [1.0, 1.0, 1.0, 1.2], "passive": "CENTER FIELD", "sig": "OVER THE TOP"},
    # SPECIALIST
    "KICKER":        {"type": "SPECIALIST", "role": "clutch scorer", "bias": [0.95, 1.1, 0.95, 1.0], "passive": "ICE IN THE VEINS", "sig": "WALK-OFF"},
    "PUNTER":        {"type": "SPECIALIST", "role": "field position", "bias": [1.05, 0.95, 1.1, 1.0], "passive": "HANG TIME", "sig": "COFFIN CORNER"},
    "KICK RETURNER": {"type": "SPECIALIST", "role": "open field", "bias": [0.9, 1.05, 0.9, 1.3], "passive": "RETURN LANE", "sig": "HOUSE CALL"},
    "LONG SNAPPER":  {"type": "SPECIALIST", "role": "deadpan support", "bias": [1.1, 0.9, 1.1, 1.0], "passive": "PERFECT SNAP", "sig": "SNAP HOLD KICK"},
}

# Subtype passives the battle engine currently implements (the rest are shown as "planned").
SUBTYPE_IMPL = {
    "GUNSLINGER": "After a miss or resisted hit, next attack +25% power.",
    "FIELD GENERAL": "Once per battle, a resisted hit becomes neutral.",
    "BELL-COW": "Each attack in a row adds 5% damage resistance (max 20%).",
    "BRUISER": "First time below 20% HP: ATK and DEF up.",
    "ALPHA": "First RECEIVER move after entering: +20% power.",
    "DEEP THREAT": "Acting first: +10% crit chance.",
    "BRICK WALL": "DEF can never be lowered below normal.",
    "COVERAGE": "RECEIVER hits do 1.5x instead of 2x.",
    "SACK ARTIST": "+15% crit chance vs PASSING.",
    "IMMOVABLE OBJECT": "Below 35% HP, takes 15% less damage.",
    "SHUT DOWN": "First RECEIVER move against it: -30% damage.",
    "BALL HAWK": "After the foe misses, next attack +20% power.",
    "KICKER": "WALK-OFF hits harder the lower its HP; priority below 25%.",
    "PUNTER": "After a control move, foe's next SPD boost fails.",
}

# Rarity / tier vocabulary (see data/creatures.py)
POWER_TIERS = ["PRACTICE SQUAD", "WAIVER WIRE", "FLEX", "STARTER", "FIRST-ROUNDER",
               "ALL-PRO", "FRANCHISE PLAYER", "HALL OF FAMER", "LEAGUE BREAKER"]

SCHEME_FIT = 1.25       # same-type move bonus (the old "STAB")
CRIT_MULT = 1.5


def effectiveness(attack_type, defend_type):
    return CHART.get(attack_type, {}).get(defend_type, 1.0)
