"""
Cut creature sprites out of the concept boards (magenta panels) into
sprites/creatures/NAME.png at SPRITE px. Run once; PNGs are shipped with the game.
    python3 tools/cut_boards.py board.png "NAME:x0,y0,x1,y1" ...
"""
import sys
import numpy as np
from PIL import Image

SPRITE = 80


def cut(board, name, box, out_dir):
    im = np.array(Image.open(board).convert("RGB")).astype(int)
    x0, y0, x1, y1 = box
    p = im[y0 + 4:y1 - 4, x0 + 4:x1 - 4]      # inset past the panel's border line
    r, g, b = p[..., 0], p[..., 1], p[..., 2]
    mag = (r > 150) & (b > 150) & (g < 130) & (abs(r - b) < 90)
    keep = ~mag
    ys, xs = np.where(keep)
    # trim stray specks near the panel border
    bx0, by0, bx1, by1 = xs.min(), ys.min(), xs.max() + 1, ys.max() + 1
    crop = p[by0:by1, bx0:bx1]
    alpha = keep[by0:by1, bx0:bx1]
    rgba = np.dstack([crop, alpha * 255]).astype(np.uint8)
    img = Image.fromarray(rgba, "RGBA")
    w, h = img.size
    s = SPRITE / max(w, h)
    img = img.resize((max(1, round(w * s)), max(1, round(h * s))), Image.BOX)
    canvas = Image.new("RGBA", (SPRITE, SPRITE), (0, 0, 0, 0))
    canvas.paste(img, ((SPRITE - img.width) // 2, SPRITE - img.height))   # bottom-aligned
    # harden alpha (no soft fringe) so it reads as pixel art
    a = np.array(canvas)
    a[..., 3] = np.where(a[..., 3] > 110, 255, 0)
    Image.fromarray(a, "RGBA").save(f"{out_dir}/{name}.png")
    print(name, (w, h), "->", canvas.size)


if __name__ == "__main__":
    board, out_dir = sys.argv[1], sys.argv[2]
    for spec in sys.argv[3:]:
        name, coords = spec.split(":")
        cut(board, name, tuple(int(v) for v in coords.split(",")), out_dir)
