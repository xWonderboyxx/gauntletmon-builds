#!/bin/bash
# Launches the game full-screen on the TV. Edit settings.py to change that.
cd "$(dirname "$0")"
exec python3 main.py --fullscreen "$@"
