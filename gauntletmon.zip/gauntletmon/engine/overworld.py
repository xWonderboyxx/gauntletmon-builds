"""
The overworld: walking around maps, talking to people, reading signs,
going through doors, stumbling into wild creatures in tall grass, and
getting spotted by league owners who want to battle.
"""
import random
import settings
from engine import gfx, ui
from engine.monsters import Monster
from data import maps as mapdata, sprites, creatures, items as itemdata, trainers as trainerdata, types

TILE = 16
VIEW_W, VIEW_H = gfx.W // TILE, gfx.H // TILE        # 15 x 10 tiles
DIRS = {"up": (0, -1), "down": (0, 1), "left": (-1, 0), "right": (1, 0)}
OPPOSITE = {"up": "down", "down": "up", "left": "right", "right": "left"}
WALK_SPEED = 2          # pixels per frame (16 px per tile -> 8 frames per step)
STARTERS = ["PIGSKLET", "AERLING", "TURFLING"]


class NPC:
    def __init__(self, d, flags):
        self.x, self.y = d["at"]
        self.sprite = d["sprite"]
        self.facing = d.get("face", "down")
        self.text = d.get("text", [])
        self.random = d.get("random")          # list of alternative line-lists, one picked per chat
        self.portrait = d.get("portrait")      # sprites/people/NAME.png shown while talking
        self.idle = d.get("idle", not d.get("trainer") and not d.get("sight"))   # looks around now and then
        self.home_face = self.facing
        self.script = d.get("script")
        self.trainer = d.get("trainer")
        self.sight = d.get("sight", 0)
        self.after_at = d.get("after_at")
        done = (self.trainer and flags.get("beat_" + self.trainer)) or \
               (self.script == "gatekeeper" and flags.get("gate_open"))
        if done and self.after_at:
            self.x, self.y = self.after_at
            self.facing = "down" if self.trainer else "down"
        self.done = bool(done)
        if self.trainer:
            look = trainerdata.get(self.trainer)["look"]
            self.palette = dict(sprites.PEOPLE_PALETTES["OWNER"])
            self.palette["4"], self.palette["5"] = look["hair"], look["shirt"]
        else:
            self.palette = sprites.PEOPLE_PALETTES.get(self.sprite, sprites.PEOPLE_PALETTES["KID"])


class Overworld:
    def __init__(self, game):
        self.game = game
        self.player = game.player
        self.text = ui.TextBox()
        self.frame = 0
        self.moving = 0
        self.anim = 0
        self.menu = None
        self.menu_kind = None
        self.pending_trainer = None
        self.return_map = None          # for the shared stadium tents
        self.load_map(self.player.map)

    # --- map loading ------------------------------------------------------
    def load_map(self, name):
        self.map = mapdata.get(name)
        self.player.map = name
        self.tiles = self.map["tiles"]
        self.h = len(self.tiles)
        self.w = max(len(r) for r in self.tiles)
        self.npcs = [NPC(d, self.player.flags) for d in self.map["npcs"]]
        self.warps = {}
        for w in self.map["warps"]:
            w = dict(w)
            if w["to"] == "RETURN":
                w["to"] = self.player.flags.get("return_map", "stadium1")
            self.warps[tuple(w["at"])] = w
        self.scene = self.map.get("scene", "field")        # battle backdrop for this map
        self.border = "#" if self.tiles[0][0] == "#" else self.tiles[0][0]
        if self.border not in sprites.TILES:
            self.border = "T"

    def tile(self, x, y):
        if 0 <= y < self.h and 0 <= x < len(self.tiles[y]):
            return self.tiles[y][x]
        return self.border

    def blocked(self, x, y):
        if self.tile(x, y) in mapdata.SOLID_TILES:
            return True
        return any(n.x == x and n.y == y for n in self.npcs)

    def npc_at(self, x, y):
        for n in self.npcs:
            if n.x == x and n.y == y:
                return n
        return None

    # --- update -----------------------------------------------------------
    @property
    def busy(self):
        return self.text.busy or self.menu is not None

    def update(self, inp):
        self.frame += 1
        was_busy = self.text.busy
        self.text.update(inp)
        if was_busy:
            return
        if self.menu is not None:
            self._update_menu(inp)
            return
        p = self.player
        if self.frame % 90 == 0:
            for n in self.npcs:
                if n.idle and random.random() < 0.35:
                    n.facing = random.choice([n.home_face, n.home_face, "left", "right", "down"])
        if self.moving:
            step = min(WALK_SPEED, self.moving)
            self.moving -= step
            self.anim += step
            if self.moving == 0:
                self.arrived()
            return
        if inp.pressed("start"):
            self.game.open_start_menu()
            return
        if inp.pressed("a"):
            self.interact()
            return
        for d, (dx, dy) in DIRS.items():
            if inp.held(d):
                p.facing = d
                nx, ny = p.x + dx, p.y + dy
                if not self.blocked(nx, ny):
                    p.x, p.y = nx, ny
                    self.moving = TILE
                    p.steps += 1
                break

    def arrived(self):
        p = self.player
        warp = self.warps.get((p.x, p.y))
        if warp:
            if self.map["name"] not in ("MEDICAL TENT", "MERCH TENT") and warp["to"] in ("tent", "tentshop"):
                p.flags["return_map"] = p.map
            self.load_map(warp["to"])
            p.x, p.y = warp["pos"]
            p.facing = warp["face"]
            self.game.flash_transition()
            return
        # a league owner spots you
        for n in self.npcs:
            if n.trainer and not n.done and self.in_sight(n):
                n_facing = n.facing
                p.facing = OPPOSITE[n_facing]
                self.challenge(n)
                return
        if self.tile(p.x, p.y) in mapdata.GRASS_TILES and p.party and not p.all_fainted():
            if random.randint(1, 100) <= settings.ENCOUNTER_CHANCE and self.map["encounters"]:
                self.start_encounter()

    def in_sight(self, n):
        dx, dy = DIRS[n.facing]
        x, y = n.x, n.y
        for _ in range(n.sight):
            x, y = x + dx, y + dy
            if (x, y) == (self.player.x, self.player.y):
                return True
            if self.tile(x, y) in mapdata.SOLID_TILES:
                return False
        return False

    def start_encounter(self):
        table = self.map["encounters"]
        total = sum(w for _, w, _ in table)
        r = random.uniform(0, total)
        for name, weight, (lo, hi) in table:
            r -= weight
            if r <= 0:
                break
        wild = Monster(name, random.randint(lo, hi), wild=True)
        self.game.start_battle(wild)

    # --- interaction --------------------------------------------------------
    def facing_tile(self):
        dx, dy = DIRS[self.player.facing]
        return self.player.x + dx, self.player.y + dy

    def interact(self):
        p = self.player
        fx, fy = self.facing_tile()
        if self.tile(fx, fy) == "C":
            dx, dy = DIRS[p.facing]
            fx, fy = fx + dx, fy + dy
        npc = self.npc_at(fx, fy)
        if npc:
            npc.facing = OPPOSITE[p.facing]
            self.talk(npc)
            return
        sign = self.map["signs"].get((fx, fy))
        if sign:
            self.text.say(sign)
            return
        if [fx, fy] in self.map.get("heal_tiles", []):
            self.text.say("You take a quick nap... Your whole team feels refreshed!")
            p.heal_all()
            p.flags["last_heal"] = [self.player.map, p.x, p.y]

    def talk(self, npc):
        p = self.player
        if npc.trainer:
            t = trainerdata.get(npc.trainer)
            if npc.done:
                self.text.say(t["after"])
            else:
                self.challenge(npc)
            return
        self.text.portrait = npc.portrait
        lines = list(npc.text)
        if npc.random:
            lines += random.choice(npc.random)
        for line in lines:
            self.text.say(line.replace("{P}", p.name))
        if npc.script == "starter":
            if not p.party and not p.flags.get("starter"):
                self.text.say("Pick your FIRST-ROUNDER! Choose carefully, rookie.",
                              after=lambda: self.open_menu("starter", ui.Menu(STARTERS, 0, 0, 100)))
            else:
                self.text.say("COACH DUNN: Go fill that roster. The STADIUM is waiting!")
        elif npc.script == "heal":
            self.text.say("Let me patch up your team. This will only take a second!", after=self.do_heal)
        elif npc.script == "shop":
            self.text.say("What can I get you?", after=lambda: self.open_menu(
                "shop", ui.Menu([f"{n:<13}${itemdata.get(n)['price']}" for n in itemdata.SHOP_STOCK] + ["CANCEL"], 0, 0, 160, line_h=12)))
        elif npc.script == "gatekeeper":
            if npc.done:
                self.text.say("GUARD: Go get 'em.")
            elif len(p.party) + len(p.storage) >= 2:
                self.text.say("GUARD: Two players on the roster... fine, that's a team. The gate's open. Good luck, kid.")
                p.flags["gate_open"] = True
                npc.done = True
                if npc.after_at:
                    npc.x, npc.y = npc.after_at
            else:
                self.text.say("GUARD: One player isn't a team. Sign at least TWO before you go in there.")
        elif npc.script == "champion":
            if p.flags.get("beat_PETE"):
                if not p.flags.get("champion"):
                    p.flags["champion"] = True
                    p.cash += 10000
                    self.text.say("COACH DUNN: You did it. Eleven owners. The whole GAUNTLET.")
                    self.text.say(f"{p.name} received the GRIDIRON GAUNTLET TROPHY!")
                    self.text.say("COACH DUNN: Most points ever, unluckiest ever... and now, finally, a RING.")
                    self.text.say("(That's the end of this version. More owners, legends and League Breakers next update!)")
                else:
                    self.text.say("COACH DUNN: Champion. Say it again. CHAMPION.")
            else:
                self.text.say("COACH DUNN: PETE's still standing. Go finish it.")

    def challenge(self, npc):
        t = trainerdata.get(npc.trainer)
        if not self.player.party or self.player.all_fainted():
            self.text.say(f"{t['name']}: Come back when you've got a team that can stand up.")
            return
        self.pending_trainer = npc
        self.text.say(f"{t['name']} - {t['title']} - wants to battle!", after=self._start_trainer_battle)

    def _start_trainer_battle(self):
        npc = self.pending_trainer
        self.pending_trainer = None
        t = trainerdata.get(npc.trainer)
        self.game.start_battle(None, trainer=t)

    def after_battle(self, result):
        """Called by the game when a battle ends, to move beaten trainers aside."""
        for n in self.npcs:
            if n.trainer and self.player.flags.get("beat_" + n.trainer) and not n.done:
                n.done = True
                if n.after_at:
                    n.x, n.y = n.after_at

    def do_heal(self):
        self.player.heal_all()
        self.player.flags["last_heal"] = [self.player.map, self.player.x, self.player.y]
        self.text.say("Your team is in top shape! Go get 'em!")

    def open_menu(self, kind, menu):
        self.menu_kind, self.menu = kind, menu

    def _update_menu(self, inp):
        if self.text.busy:
            return
        choice = self.menu.update(inp)
        kind = self.menu_kind
        if kind == "starter":
            if choice is not None:
                name = self.menu.items[choice]
                self.menu = None
                self.text.say(f"So you'll go with {name}? Let's make it official!",
                              after=lambda: self.open_menu("confirm_starter", ui.Menu(["YES", "NO"], 180, 64)))
                self._pending_starter = name
            elif self.menu.cancelled:
                self.menu = None
        elif kind == "confirm_starter":
            if choice == 0:
                mon = Monster(self._pending_starter, 5)
                self.player.add_monster(mon)
                self.player.flags["starter"] = True
                self.menu = None
                self.text.say(f"{self.player.name} received {mon.name}!")
                self.text.say("COACH DUNN: Here, take these too. 5 CONTRACTS. Sign every wild player you can.")
                self.player.add_item("CONTRACT", 5)
                self.text.say("Wild players hide in TALL GRASS north of town. The GUARD won't let a one-man team into the STADIUM, so sign a second player first!")
            elif choice == 1 or self.menu.cancelled:
                self.menu = None
                self.text.say("COACH DUNN: Take your time. Come back when you've decided.")
        elif kind == "shop":
            if self.menu.cancelled or choice == len(itemdata.SHOP_STOCK):
                self.menu = None
                self.text.say("Come again!")
            elif choice is not None:
                name = itemdata.SHOP_STOCK[choice]
                price = itemdata.get(name)["price"]
                if self.player.cash < price:
                    self.text.say("You don't have enough cash!")
                else:
                    self.player.cash -= price
                    self.player.add_item(name)
                    self.text.say(f"Bought a {name}. Cash left: ${self.player.cash}")

    # --- drawing ------------------------------------------------------------
    def draw(self, surf):
        p = self.player
        dx, dy = DIRS[p.facing]
        px = p.x * TILE - dx * self.moving
        py = p.y * TILE - dy * self.moving
        cam_x = px - (gfx.W - TILE) // 2
        cam_y = py - (gfx.H - TILE) // 2 + 4
        x0, y0 = cam_x // TILE - 1, cam_y // TILE - 1
        for ty in range(y0, y0 + VIEW_H + 3):
            for tx in range(x0, x0 + VIEW_W + 3):
                ch = self.tile(tx, ty)
                rows = sprites.TILES.get(ch)
                if rows:
                    alt = sprites.TILES_ALT.get(ch)
                    if alt and (self.frame // 30) % 2:
                        rows, k = alt, "TA" + ch
                    else:
                        k = "T" + ch
                    surf.blit(gfx.art(rows, palette=sprites.TILE_PALETTES[ch], key=k),
                              (tx * TILE - cam_x, ty * TILE - cam_y))
        # soft shadows under everyone, then the people (sorted by row so nobody overlaps wrongly)
        people = [(n.y, n.x * TILE - cam_x, n.y * TILE - cam_y, n) for n in self.npcs]
        people.append((p.y + 0.5, px - cam_x, py - cam_y, None))
        for _, sx, sy, n in people:
            surf.fill((70, 110, 60) if self.map["name"] not in ("HOME", "FRONT OFFICE", "LOCKER ROOM", "PRO SHOP") else (150, 130, 110),
                      (sx + 3, sy + 12, 10, 3))
        for _, sx, sy, n in sorted(people, key=lambda t: t[0]):
            if n is None:
                frame = [0, 1, 0, 2][(self.anim // 8) % 4] if self.moving else 0
                bob = -1 if self.moving and (self.anim // 8) % 2 else 0
                self._draw_person(surf, "PLAYER", sprites.PEOPLE_PALETTES["PLAYER"], p.facing, frame, sx, sy - 4 + bob)
            else:
                self._draw_person(surf, n.sprite, n.palette, n.facing, 0, sx, sy - 4, key=n.trainer or n.sprite)
                if n.trainer and not n.done:
                    gfx.text(surf, sx + 5, sy - 14 - ((self.frame // 20) % 2), "!", gfx.UI["red"])
        if self.text.busy:
            self.text.draw(surf, self.frame)
        if self.menu is not None:
            if self.menu_kind == "shop":
                gfx.box(surf, 0, ui.BOX_Y, gfx.W, 48)
                gfx.text(surf, 8, ui.BOX_Y + 12, f"CASH ${p.cash}")
                if self.menu.index < len(itemdata.SHOP_STOCK):
                    gfx.text(surf, 8, ui.BOX_Y + 28, itemdata.get(itemdata.SHOP_STOCK[self.menu.index])["desc"])
            if self.menu_kind == "starter":
                name = self.menu.items[self.menu.index]
                d = creatures.get(name)
                bx = gfx.W - 150
                gfx.box(surf, bx, 0, 150, 88)
                surf.blit(gfx.creature_sprite(name, 72), (bx + 6, 8))
                gfx.type_badge(surf, bx + 84, 12, d["type"])
                gfx.text(surf, bx + 84, 28, d["subtype"][:11], gfx.UI["mid"])
                gfx.text(surf, bx + 84, 44, "FIRST-", gfx.UI["mid"])
                gfx.text(surf, bx + 84, 54, "ROUNDER", gfx.UI["mid"])
            self.menu.draw(surf)

    def _draw_person(self, surf, name, palette, facing, frame, x, y, key=None):
        person = sprites.PEOPLE[name]
        mirror = facing == "left"
        rows = person["right" if mirror else facing][frame]
        k = "P" + (key or name) + ("right" if mirror else facing) + str(frame)
        surf.blit(gfx.art(rows, palette=palette, mirror=mirror, key=k), (x, y))
