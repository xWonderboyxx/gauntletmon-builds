"""
A Monster = one creature you own or fight. Stats follow the original
Game Boy formulas (with a small random "IV" so two of the same species differ).
"""
import random
from data import creatures, moves as movedata, types

STATS = ("HP", "ATK", "DEF", "SPD")
MAX_MOVES = 4
STATUS_NAMES = {"DAZED": "DZD", "CRAMP": "CRP", "GASSED": "GSD", "TURFBURN": "BRN"}


def exp_for_level(level):
    """Medium-fast curve: total EXP needed to be this level."""
    return level ** 3


class Monster:
    def __init__(self, species, level, nickname=None, ivs=None, wild=False):
        self.species = species
        self.level = level
        self.nickname = nickname
        self.ivs = ivs or [random.randint(0, 15) for _ in range(4)]
        self.exp = exp_for_level(level)
        self.status = None
        self.sleep_turns = 0
        self.moves = []           # list of [name, pp_left]
        self.wild = wild
        for lvl in sorted(self.data["moves"]):
            if lvl <= level:
                self._add_move(self.data["moves"][lvl])
        self.hp = self.max_hp

    # --- basics -----------------------------------------------------------
    @property
    def data(self):
        return creatures.get(self.species)

    @property
    def name(self):
        return self.nickname or creatures.display_name(self.species)

    @property
    def subtype(self):
        return self.data.get("subtype")

    @property
    def passive(self):
        """(type passive name, subtype passive name)"""
        tp = types.PASSIVES.get(self.type, {}).get("name", "")
        sp = types.SUBTYPES.get(self.subtype, {}).get("passive", "")
        return tp, sp

    @property
    def type(self):
        return self.data["type"]

    def stat(self, name):
        i = STATS.index(name)
        bias = types.SUBTYPES.get(self.subtype, {}).get("bias", [1, 1, 1, 1])[i]
        base = int(self.data["base"][i] * bias) + self.ivs[i]
        if name == "HP":
            return (base * 2 * self.level) // 100 + self.level + 10
        return (base * 2 * self.level) // 100 + 5

    @property
    def max_hp(self):
        return self.stat("HP")

    @property
    def fainted(self):
        return self.hp <= 0

    def heal_full(self):
        self.hp = self.max_hp
        self.status = None
        self.sleep_turns = 0
        for m in self.moves:
            m[1] = movedata.get(m[0])["pp"]

    # --- moves ------------------------------------------------------------
    def _add_move(self, name):
        if any(m[0] == name for m in self.moves):
            return True
        if len(self.moves) >= MAX_MOVES:
            return False
        self.moves.append([name, movedata.get(name)["pp"]])
        return True

    def replace_move(self, index, name):
        self.moves[index] = [name, movedata.get(name)["pp"]]

    def moves_at_level(self, level):
        return [m for l, m in self.data["moves"].items() if l == level]

    # --- experience -------------------------------------------------------
    def exp_to_next(self):
        return exp_for_level(self.level + 1) - self.exp

    def exp_progress(self):
        lo, hi = exp_for_level(self.level), exp_for_level(self.level + 1)
        return (self.exp - lo) / (hi - lo)

    def gain_exp(self, amount):
        """Add EXP. Returns list of levels gained (usually 0 or 1)."""
        self.exp += amount
        gained = []
        while self.level < 100 and self.exp >= exp_for_level(self.level + 1):
            old_max = self.max_hp
            self.level += 1
            self.hp += self.max_hp - old_max
            gained.append(self.level)
        return gained

    def evolution_due(self):
        evo = self.data.get("evolve")
        if evo and self.level >= evo["level"]:
            return evo["into"]
        return None

    def evolve(self):
        hp_frac = self.hp / self.max_hp
        keep_nick = self.nickname if self.nickname != self.species else None
        self.species = self.evolution_due() or self.species
        self.nickname = keep_nick
        self.hp = max(1, int(self.max_hp * hp_frac))

    # --- save / load ------------------------------------------------------
    def to_dict(self):
        return {"species": self.species, "level": self.level, "nickname": self.nickname,
                "ivs": self.ivs, "exp": self.exp, "hp": self.hp, "status": self.status,
                "moves": self.moves}

    @classmethod
    def from_dict(cls, d):
        m = cls(d["species"], d["level"], d.get("nickname"), d.get("ivs"))
        m.exp = d.get("exp", m.exp)
        m.moves = [list(x) for x in d.get("moves", m.moves)]
        m.hp = min(d.get("hp", m.max_hp), m.max_hp)
        m.status = d.get("status")
        return m
