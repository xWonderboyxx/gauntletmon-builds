"""
Ties everything together: title screen -> overworld <-> battles / start menu.
"""
import pygame
import settings
from engine import gfx, ui, font, save
from engine.overworld import Overworld
from engine.battle import Battle
from engine.menus import StartMenu
from data import sprites


class Game:
    def __init__(self):
        self.canvas = pygame.Surface((gfx.W, gfx.H))
        self.state = "title"
        self.player = None
        self.world = None
        self.battle = None
        self.menu = None
        self.frame = 0
        self.fade = 0            # >0 while a screen transition plays
        self.fade_dir = 0
        self.after_fade = None
        self.title_menu = ui.Menu(["CONTINUE", "NEW GAME"] if save.save_exists() else ["NEW GAME"],
                                  76, 98, 88, cancel=False)
        self.quit = False

    # --- transitions --------------------------------------------------------
    def flash_transition(self, then=None):
        """Quick fade out/in (doors, battle start)."""
        self.fade, self.fade_dir, self.after_fade = 1, 1, then

    def _update_fade(self):
        self.fade += self.fade_dir
        if self.fade >= 6:
            self.fade_dir = -1
            if self.after_fade:
                cb, self.after_fade = self.after_fade, None
                cb()
        if self.fade <= 0:
            self.fade, self.fade_dir = 0, 0

    # --- state changes -------------------------------------------------------
    def new_game(self):
        self.player = save.Player()
        self.player.flags["last_heal"] = ["home", 4, 4]
        self.world = Overworld(self)
        self.state = "world"
        self.world.text.say(f"MOM: {self.player.name}! You're finally awake. COACH DUNN wants you at the FRONT OFFICE.")
        self.world.text.say("It's the building at the bottom-left of town. Go on, get moving!")

    def continue_game(self):
        self.player = save.load_game()
        self.world = Overworld(self)
        self.state = "world"

    def start_battle(self, wild, trainer=None):
        def go():
            self.battle = Battle(self, wild, trainer=trainer)
            self.state = "battle"
        self.flash_transition(go)

    def end_battle(self):
        result = self.battle.result
        self.battle = None
        self.state = "world"
        self.world.after_battle(result)
        if result == "lose":
            self.blackout()

    def blackout(self):
        p = self.player
        p.heal_all()
        m, x, y = p.flags.get("last_heal", ["home", 4, 4])
        p.x, p.y, p.facing = x, y, "down"
        self.world.load_map(m)
        self.world.text.say(f"{p.name} hurried back home and rested up... Everyone is healed.")

    def open_start_menu(self):
        self.menu = StartMenu(self)
        self.state = "menu"

    # --- main loop pieces ----------------------------------------------------
    def update(self, inp):
        self.frame += 1
        if self.fade_dir:
            self._update_fade()
            return
        if self.state == "title":
            choice = self.title_menu.update(inp)
            if choice is not None:
                if self.title_menu.items[choice] == "CONTINUE":
                    self.flash_transition(self.continue_game)
                else:
                    self.flash_transition(self.new_game)
        elif self.state == "world":
            self.world.update(inp)
        elif self.state == "battle":
            self.battle.update(inp)
            if self.battle.done:
                self.flash_transition(self.end_battle)
        elif self.state == "menu":
            self.menu.update(inp)
            if self.menu.closed:
                self.menu = None
                self.state = "world"

    def draw(self):
        c = self.canvas
        if self.state == "title":
            self.draw_title(c)
        elif self.state == "world":
            self.world.draw(c)
        elif self.state == "battle":
            self.battle.draw(c)
        elif self.state == "menu":
            self.world.draw(c)
            self.menu.draw(c)
        if self.fade:
            gfx.fade_step(c, min(3, self.fade))
        return c

    def draw_title(self, c):
        c.fill(gfx.UI["navy"])
        c.fill(gfx.UI["cobalt"], (0, 0, gfx.W, 3))
        c.fill(gfx.UI["red"], (0, 3, gfx.W, 2))
        if not hasattr(self, "_logo"):
            small = gfx.new_surface(font.text_width("GAUNTLET MON"), font.GLYPH_H)
            gfx.text(small, 0, 0, "GAUNTLET MON", gfx.UI["gold"])
            self._logo = pygame.transform.scale(small, (small.get_width() * 3, small.get_height() * 3))
            self._logo.set_colorkey(gfx.TRANSPARENT)
        c.blit(self._logo, ((gfx.W - self._logo.get_width()) // 2, 14))
        gfx.text_center(c, gfx.W // 2, 40, "GRIDIRON GAUNTLET EDITION", gfx.UI["light"])
        # parade of creatures
        names = ["BELLCOW", "LOCKDOWN", "PIGSKLET", "WAIVERN", "AERLING", "BOOMBUST", "TURFLING", "CHAINGEIST", "TOM_GOAT"]
        i = (self.frame // 100) % len(names)
        c.blit(gfx.creature_sprite(names[i], 64), (8, 52))
        c.blit(gfx.creature_sprite(names[(i + 4) % len(names)], 64, mirror=True), (gfx.W - 72, 52))
        gfx.text_center(c, gfx.W // 2, 60, "CATCH - BATTLE", gfx.UI["gold"])
        gfx.text_center(c, gfx.W // 2, 72, "BUILD - AVENGE", gfx.UI["gold"])
        self.title_menu.draw(c)
        if (self.frame // 30) % 2 == 0:
            gfx.text_center(c, gfx.W // 2, 148, "PRESS Z TO START", gfx.UI["light"])
        gfx.text(c, 4, 150, "V0.3", gfx.UI["mid"])
