"""
The battle screen. Turn-based, Game Boy rules with the GAUNTLET MON layer:
  - faster creature goes first (priority moves jump the queue)
  - damage = classic formula, then Scheme Fit 1.25x (same-type), the 8-type
    chart (2x / 1x / 0.5x), and crits at 1.5x
  - every TYPE has a core passive (see data/types.py PASSIVES) - all eight
    are implemented here
  - statuses, stat stages, catching with the 3-shake animation, EXP, level ups,
    learning moves (with the "forget a move?" prompt) and evolution
  - trainer battles: no catching, no running, the trainer sends out its next
    creature, you get cash for winning

Everything that happens in a turn is a Python generator that yields small
commands ("say this", "drain HP to N", "shake the ball"), and Battle.update()
plays them back one frame at a time. The rules live in run_turn() / use_move().
"""
import random
import math
import settings
from engine import gfx, font, ui
from engine.monsters import Monster, STATUS_NAMES
from data import moves as movedata, types, items as itemdata, creatures, sprites

STAGE_MULT = {-6: 0.25, -5: 0.28, -4: 0.33, -3: 0.4, -2: 0.5, -1: 0.66,
              0: 1.0, 1: 1.5, 2: 2.0, 3: 2.5, 4: 3.0, 5: 3.5, 6: 4.0}
SPRITE = 80
ENEMY_POS = (gfx.W - SPRITE - 14, 6)
ALLY_POS = (14, ui.BOX_Y - SPRITE - 8)
HORIZON = ALLY_POS[1] + 46
PANEL_W = 124


class Side:
    """Per-battle state for one creature (stat stages reset when it switches)."""

    def __init__(self, mon):
        self.mon = mon
        self.stages = {"ATK": 0, "DEF": 0, "SPD": 0}
        self.shown_hp = mon.hp
        self.shown_exp = mon.exp
        self.visible = True
        self.flash = 0
        self.offset = 0
        self.shake = 0           # frames of hit-jitter left
        self.drop = 0            # faint animation: pixels fallen
        self.pop = 0             # entry animation frames left
        # passive bookkeeping
        self.momentum = 0            # RUSHING
        self.read_defense = False    # PASSING: boosted next move
        self.read_react = False      # LINEBACKER: boosted next hit
        self.first_hit_taken = False  # O-LINE: pocket wall used
        self.coverage_used = False   # DEFENSIVE BACK
        self.guard = False           # halve the next hit (BRACE etc.)
        # subtype bookkeeping
        self.no_fear = False         # GUNSLINGER
        self.audible = True          # FIELD GENERAL: one resisted hit -> neutral
        self.workload = 0            # BELL-COW
        self.yac_used = False        # BRUISER: yards after contact
        self.first_move = True       # ALPHA: first move after entering
        self.island = True           # SHUT DOWN: first receiver hit reduced
        self.jump_route = False      # BALL HAWK
        self.no_spd_boost = False    # PUNTER hang time (set on the FOE)

    @property
    def sub(self):
        return self.mon.subtype

    def eff_stat(self, name):
        v = self.mon.stat(name) * STAGE_MULT[self.stages[name]]
        if name == "SPD" and self.mon.status == "DAZED":
            v *= 0.25
        if name == "ATK" and self.mon.status == "TURFBURN":
            v *= 0.5
        return max(1, int(v))

    def clutch(self):
        return self.mon.type == "SPECIALIST" and self.mon.hp * 3 <= self.mon.max_hp


class Battle:
    def __init__(self, game, wild=None, trainer=None):
        self.game = game
        self.player = game.player
        self.trainer = trainer
        if trainer:
            self.enemy_party = [Monster(sp, lv) for sp, lv in trainer["party"]]
            self.enemy_index = 0
            wild = self.enemy_party[0]
        self.wild = wild
        self.player.seen.add(wild.species)
        self.enemy = Side(wild)
        self.enemy.visible = False
        self.ally = Side(self.player.party[self.player.first_healthy()])
        self.ally.visible = False
        self.text = ui.TextBox()
        self.phase = "script"
        self.script = None
        self.pending = None
        self.timer = 0
        self.frame = 0
        self.menu = None
        self.submenu = None
        self.result = None            # "win", "lose", "run", "caught"
        self.done = False
        self.ball_anim = None
        self.particles = []      # [x, y, vx, vy, life, color]
        self.screen_shake = 0
        self.run_attempts = 0
        self.first_mover = None       # which Side acted first this turn
        self.enemy_status_uses = 0
        self.start_script(self.intro())

    # ------------------------------------------------------------------
    # script playback
    # ------------------------------------------------------------------
    def start_script(self, gen):
        self.script = gen
        self.phase = "script"
        self.pending = None
        self.send_value = None

    def step_script(self):
        try:
            cmd = self.script.send(self.send_value)
        except StopIteration:
            self.script = None
            self.pending = None
            if self.result:
                self.done = True
            else:
                self.open_main_menu()
            return
        self.send_value = None
        self.pending = cmd
        self.timer = 0
        kind = cmd[0]
        if kind == "say":
            self.text.say(cmd[1], auto=True)
        elif kind == "learn":
            mon, new = cmd[1], cmd[2]
            self.submenu = ("learn", mon, new,
                            ui.Menu([m[0] for m in mon.moves] + ["DON'T LEARN"], 0, 40, gfx.W))
        elif kind == "throw":
            self.ball_anim = {"t": 0, "shakes": cmd[1], "caught": cmd[2]}
            self.enemy.visible = True
        elif kind == "force_switch":
            self.script = None
            self.pending = None
            self.phase = "team"
            self.menu = self._team_menu(cancel=False)

    def command_finished(self, inp):
        cmd = self.pending
        kind = cmd[0]
        self.timer += 1
        if kind == "say":
            return not self.text.busy
        if kind == "wait":
            return self.timer >= cmd[1]
        if kind == "hp":
            side, target = cmd[1], cmd[2]
            if side.shown_hp == target:
                return self.timer > 8
            step = max(1, abs(side.shown_hp - target) // 12)
            side.shown_hp += step if target > side.shown_hp else -step
            if (side.shown_hp - target) * (1 if target > side.shown_hp else -1) > 0:
                side.shown_hp = target
            return False
        if kind == "exp":
            side, target = cmd[1], cmd[2]
            if side.shown_exp >= target:
                side.shown_exp = target
                return self.timer > 6
            side.shown_exp += max(1, (target - side.shown_exp) // 10)
            return False
        if kind == "flash":
            cmd[1].flash = 24
            return True
        if kind == "hit":
            side, mtype, mult, crit = cmd[1], cmd[2], cmd[3], cmd[4]
            if self.timer == 1:
                side.flash = 18
                side.shake = 14
                strength = 14 + (10 if mult > 1 else 0) + (10 if crit else 0)
                if mult > 1 or crit:
                    self.screen_shake = 10
                pos = ENEMY_POS if side is self.enemy else ALLY_POS
                cx, cy = pos[0] + SPRITE // 2, pos[1] + SPRITE // 2
                col = types.COLORS.get(mtype, gfx.UI["gold"])
                for i in range(strength):
                    ang = random.random() * 6.283
                    spd = 1.2 + random.random() * 2.2
                    self.particles.append([cx, cy, math.cos(ang) * spd, math.sin(ang) * spd - 0.6,
                                           10 + random.randint(0, 8), col if i % 3 else gfx.UI["white"]])
            return self.timer >= 14
        if kind == "faint":
            side = cmd[1]
            side.drop = min(SPRITE, self.timer * 7)
            if self.timer >= 14:
                side.visible = False
                side.drop = 0
                return True
            return False
        if kind == "lunge":
            side = cmd[1]
            side.offset = [0, 2, 4, 6, 4, 2, 0, 0][min(7, self.timer)] * (1 if side is self.ally else -1)
            return self.timer >= 8
        if kind == "show":
            cmd[1].visible = True
            cmd[1].pop = 12
            return True
        if kind == "hide":
            cmd[1].visible = False
            return True
        if kind == "learn":
            return self.submenu is None
        if kind == "throw":
            return self.ball_anim is None
        if kind == "vs":
            self.vs_timer = self.timer
            return self.timer > 150 or (self.timer > 20 and (inp.pressed("a") or inp.pressed("b")))
        return True

    # ------------------------------------------------------------------
    # menus
    # ------------------------------------------------------------------
    def notice(self, msg):
        self.phase = "notice"
        self.text.say(msg, auto=True)

    def open_main_menu(self):
        self.phase = "menu"
        self.menu = ui.Menu(["FIGHT", "BAG", "TEAM", "RUN"], gfx.W - 120, ui.BOX_Y, 120, cancel=False, cols=2)
        self.text.clear()
        self.submenu = None

    def _team_menu(self, cancel=True):
        return ui.Menu([self._party_label(m) for m in self.player.party], 0, 0, gfx.W, line_h=12, cancel=cancel)

    def update(self, inp):
        self.frame += 1
        for side in (self.ally, self.enemy):
            if side.shake:
                side.shake -= 1
            if side.pop:
                side.pop -= 1
        if self.screen_shake:
            self.screen_shake -= 1
        for pt in self.particles:
            pt[0] += pt[2]; pt[1] += pt[3]; pt[3] += 0.15; pt[4] -= 1
        self.particles = [pt for pt in self.particles if pt[4] > 0]
        for s in (self.ally, self.enemy):
            if s.flash > 0:
                s.flash -= 1
        if self.ball_anim:
            self._update_ball()
        self.text.update(inp)

        if self.phase == "script":
            if self.pending is None:
                self.step_script()
            if self.pending is not None:
                if self.pending[0] == "learn" and self.submenu:
                    self._update_learn_menu(inp)
                if self.command_finished(inp):
                    self.pending = None
            return

        if self.phase == "notice":
            if not self.text.busy:
                if self.ally.mon.fainted:
                    self.phase = "team"
                else:
                    self.open_main_menu()
            return

        if self.phase == "menu":
            choice = self.menu.update(inp)
            if choice == 0:
                self.phase = "fight"
                self.menu = ui.Menu([m[0] for m in self.ally.mon.moves], 0, ui.BOX_Y, gfx.W - 100, line_h=10, pad=5, h=48)
            elif choice == 1:
                self.phase = "bag"
                names = sorted(self.player.bag)
                self.bag_names = names
                self.menu = ui.Menu([f"{n} x{self.player.bag[n]}" for n in names] or ["(EMPTY)"], 0, 0, gfx.W, line_h=10)
            elif choice == 2:
                self.phase = "team"
                self.menu = self._team_menu()
            elif choice == 3:
                if self.trainer:
                    self.notice("No running from a league match!")
                else:
                    self.start_script(self.run_turn(("run",)))
            return

        if self.phase == "fight":
            choice = self.menu.update(inp)
            if self.menu.cancelled:
                self.open_main_menu()
            elif choice is not None:
                if self.ally.mon.moves[choice][1] <= 0:
                    self.notice("No PP left for this move!")
                else:
                    self.start_script(self.run_turn(("move", choice)))
            return

        if self.phase == "bag":
            choice = self.menu.update(inp)
            if self.menu.cancelled or not self.bag_names:
                if self.menu.cancelled or inp.pressed("a"):
                    self.open_main_menu()
            elif choice is not None:
                item = self.bag_names[choice]
                kind = itemdata.get(item)["kind"]
                if kind == "ball":
                    if self.trainer:
                        self.notice("The other GM blocks the CONTRACT! No signing during a match.")
                    else:
                        self.start_script(self.run_turn(("item", item, None)))
                else:
                    self.phase = "bag_target"
                    self.bag_item = item
                    self.menu = self._team_menu()
            return

        if self.phase == "bag_target":
            choice = self.menu.update(inp)
            if self.menu.cancelled:
                self.open_main_menu()
            elif choice is not None:
                self.start_script(self.run_turn(("item", self.bag_item, choice)))
            return

        if self.phase == "team":
            choice = self.menu.update(inp)
            if self.menu.cancelled:
                if not self.ally.mon.fainted:
                    self.open_main_menu()
            elif choice is not None:
                target = self.player.party[choice]
                if target.fainted:
                    self.notice(f"{target.name} has no energy left to play!")
                elif target is self.ally.mon:
                    self.notice(f"{target.name} is already in the game!")
                elif self.ally.mon.fainted:
                    self.start_script(self.switch_in(choice))
                else:
                    self.start_script(self.run_turn(("switch", choice)))
            return

    def _party_label(self, m):
        st = STATUS_NAMES.get(m.status, "")
        return f"{m.name[:11]:<11} L{m.level:>2} {m.hp:>3}/{m.max_hp:<3} {st}"

    def _update_learn_menu(self, inp):
        kind, mon, new, menu = self.submenu
        choice = menu.update(inp)
        if choice is not None:
            if choice < len(mon.moves):
                old = mon.moves[choice][0]
                mon.replace_move(choice, new)
                self.send_value = ("replaced", old)
            else:
                self.send_value = ("skipped", None)
            self.submenu = None

    def _update_ball(self):
        b = self.ball_anim
        b["t"] += 1
        t = b["t"]
        if t == 20:
            self.enemy.visible = False
        if t >= 40 + 30 * b["shakes"] + 10:
            if not b["caught"]:
                self.enemy.visible = True
            self.ball_anim = None

    # ------------------------------------------------------------------
    # the rules
    # ------------------------------------------------------------------
    def intro(self):
        yield ("wait", 10)
        if self.trainer:
            self.vs_timer = 0
            yield ("vs",)
            yield ("say", f"{self.trainer['name']} wants to battle!")
            yield ("say", self.trainer["intro"])
            yield ("say", f"{self.trainer['name']} sent out {self.wild.name}!")
            yield ("show", self.enemy)
        else:
            yield ("show", self.enemy)
            yield ("say", f"A wild {self.wild.name} appeared!")
        yield ("say", f"Go! {self.ally.mon.name}!")
        yield ("show", self.ally)
        yield ("wait", 10)

    def switch_in(self, index):
        self.ally = Side(self.player.party[index])
        self.ally.visible = False
        yield ("say", f"Go! {self.ally.mon.name}!")
        yield ("show", self.ally)

    def enemy_choice(self):
        m = self.wild
        usable = [i for i, mv in enumerate(m.moves) if mv[1] > 0]
        if not usable:
            return ("struggle",)
        if self.trainer and random.random() < 0.65:
            def score(i):
                mv = movedata.get(m.moves[i][0])
                if mv["power"] == 0:
                    eff = mv.get("effect", {})
                    st = eff.get("stat")
                    if st and eff.get("target") != "foe" and self.enemy.stages.get(st, 0) >= 2:
                        return 0                                 # don't stack buffs forever
                    if st and eff.get("target") == "foe" and self.ally.stages.get(st, 0) <= -2:
                        return 0
                    return 30 * (0.5 ** self.enemy_status_uses)
                return mv["power"] * types.effectiveness(mv["type"], self.ally.mon.type) * (1.25 if mv["type"] == m.type else 1)
            usable.sort(key=score, reverse=True)
            if movedata.get(m.moves[usable[0]][0])["power"] == 0:
                self.enemy_status_uses += 1
            return ("move", usable[0])
        return ("move", random.choice(usable))

    def priority(self, side, action):
        if action[0] in ("run", "item", "switch"):
            return 6
        if action[0] == "move":
            eff = movedata.get(side.mon.moves[action[1]][0]).get("effect", {})
            p = eff.get("priority", 0)
            if side.clutch():
                p += 1                          # CLUTCH WINDOW
            if eff.get("walkoff") and side.mon.hp * 4 <= side.mon.max_hp:
                p += 1                          # KICKER: WALK-OFF
            return p
        return 0

    def run_turn(self, player_action):
        enemy_action = self.enemy_choice()
        order = [(True, player_action), (False, enemy_action)]

        def key(pair):
            is_player, action = pair
            side = self.ally if is_player else self.enemy
            return (self.priority(side, action), side.eff_stat("SPD"), random.random())
        order.sort(key=key, reverse=True)
        self.first_mover = self.ally if order[0][0] else self.enemy

        for is_player, action in order:
            if self.result:
                return
            user = self.ally if is_player else self.enemy
            other = self.enemy if is_player else self.ally
            if user.mon.fainted:
                continue
            if action[0] == "run":
                yield from self.try_run()
                if self.result:
                    return
            elif action[0] == "item":
                yield from self.use_item(action[1], action[2])
                if self.result:
                    return
            elif action[0] == "switch":
                yield ("say", f"{self.ally.mon.name}, take a breather!")
                yield ("hide", self.ally)
                yield from self.switch_in(action[1])
            elif action[0] == "struggle":
                yield ("say", f"{user.mon.name} has no moves left!")
            elif action[0] == "move":
                yield from self.use_move(user, other, action[1])
                if other.mon.fainted:
                    yield from self.handle_faint(other)
                    return
                if user.mon.fainted:
                    yield from self.handle_faint(user)
                    return
        for side in (self.ally, self.enemy):
            if self.result:
                return
            m = side.mon
            if m.status in ("CRAMP", "TURFBURN") and not m.fainted:
                dmg = max(1, m.max_hp // 16)
                m.hp = max(0, m.hp - dmg)
                word = "cramp" if m.status == "CRAMP" else "turf burn"
                yield ("say", f"{m.name} is hurt by its {word}!")
                yield ("hp", side, m.hp)
                if m.fainted:
                    yield from self.handle_faint(side)
                    return

    # --- actions ------------------------------------------------------
    def try_run(self):
        self.run_attempts += 1
        a, b = self.ally.eff_stat("SPD"), max(1, self.enemy.eff_stat("SPD"))
        if a >= b or random.randint(0, 255) < min(255, (a * 128 // b) + 30 * self.run_attempts):
            yield ("say", "Got away safely!")
            self.result = "run"
        else:
            yield ("say", "Can't escape!")

    def use_item(self, item, target_index):
        data = itemdata.get(item)
        self.player.use_item(item)
        yield ("say", f"{self.player.name} used {item}!")
        kind = data["kind"]
        if kind == "ball":
            yield from self.try_catch(data)
            return
        mon = self.player.party[target_index]
        side = self.ally if mon is self.ally.mon else None
        if kind == "heal":
            if mon.fainted:
                yield ("say", "It won't have any effect.")
                return
            mon.hp = min(mon.max_hp, mon.hp + data["amount"])
            if side:
                yield ("hp", side, mon.hp)
            yield ("say", f"{mon.name} recovered HP!")
        elif kind == "cure":
            mon.status = None
            yield ("say", f"{mon.name} is feeling fine!")
        elif kind == "revive":
            if not mon.fainted:
                yield ("say", "It won't have any effect.")
                return
            mon.hp = mon.max_hp // 2
            yield ("say", f"{mon.name} is back on its feet!")
        elif kind == "pp":
            for mv in mon.moves:
                mv[1] = movedata.get(mv[0])["pp"]
            yield ("say", f"{mon.name}'s PP was restored!")

    def try_catch(self, ball):
        m = self.wild
        rate = creatures.get(m.species)["catch"]
        value = (3 * m.max_hp - 2 * m.hp) * rate * ball["rate"] / (3 * m.max_hp)
        if m.status == "GASSED":
            value *= 2
        elif m.status:
            value *= 1.5
        caught = random.randint(0, 255) < value
        shakes = 3 if caught else min(2, int(value / 85))
        yield ("throw", shakes, caught)
        if caught:
            yield ("say", f"All right! {m.name} signed the CONTRACT!")
            where = self.player.add_monster(m)
            if where == "storage":
                yield ("say", f"Your team is full. {m.name} was sent to the BENCH.")
            self.result = "caught"
        else:
            yield ("say", ["Oh no! It broke free!", "Argh! Almost had it!", "Shoot! It was so close!"][shakes])

    def use_move(self, user, target, index):
        m = user.mon
        if m.status == "GASSED":
            m.sleep_turns -= 1
            if m.sleep_turns > 0:
                yield ("say", f"{m.name} is gassed out!")
                return
            m.status = None
            yield ("say", f"{m.name} caught its breath!")
        if m.status == "DAZED" and random.random() < 0.25:
            yield ("say", f"{m.name} is dazed! It can't move!")
            return
        name, pp = m.moves[index]
        m.moves[index][1] = max(0, pp - 1)
        mv = movedata.get(name)
        eff = mv.get("effect", {})
        yield ("say", f"{m.name} used {name}!")

        # accuracy, with PASSING's READ THE DEFENSE and DB's COVERAGE
        acc = mv["acc"]
        if m.type == "PASSING" and user.read_defense:
            acc += 20
        if mv["power"] > 0 and target.mon.type == "DEFENSIVE BACK" and not target.coverage_used:
            acc -= 20
            target.coverage_used = True
        if "gamble" in eff and random.random() >= eff["gamble"]:
            acc = 0
        if random.randint(1, 100) > acc:
            yield ("say", f"{m.name}'s attack missed!")
            if m.type == "PASSING":
                user.read_defense = True
            if user.sub == "GUNSLINGER":
                user.no_fear = True
            if target.sub == "BALL HAWK":
                target.jump_route = True
            user.momentum = 0
            user.first_move = False
            return

        if mv["power"] > 0:
            hits = random.randint(*eff["multi"]) if "multi" in eff else 1
            total = 0
            mult = 1.0
            for h in range(hits):
                dmg, crit, mult = self.damage(user, target, mv)
                if "gamble" in eff:
                    dmg *= 2
                if mult == 0:
                    yield ("say", f"It doesn't affect {target.mon.name}...")
                    return
                # subtype defenses
                if target.sub == "BELL-COW" and target.workload:
                    dmg = max(1, int(dmg * (1 - 0.05 * target.workload)))        # WORKLOAD
                if target.sub == "IMMOVABLE OBJECT" and target.mon.hp * 100 <= target.mon.max_hp * 35:
                    dmg = max(1, int(dmg * 0.85))                                # GOAL-LINE STAND
                if target.sub == "SHUT DOWN" and mv["type"] == "RECEIVER" and target.island:
                    dmg = max(1, int(dmg * 0.7))                                 # ISLAND
                    target.island = False
                # O-LINE POCKET WALL: first hit taken is 30% weaker
                if target.mon.type == "O-LINE" and not target.first_hit_taken:
                    dmg = max(1, int(dmg * 0.7))
                    target.first_hit_taken = True
                if target.guard:
                    dmg = max(1, dmg // 2)
                    target.guard = False
                yield ("lunge", user)
                yield ("hit", target, mv["type"], mult, crit)
                target.mon.hp = max(0, target.mon.hp - dmg)
                total += dmg
                yield ("hp", target, target.mon.hp)
                if crit:
                    yield ("say", "Critical hit!")
                if target.mon.fainted:
                    break
            if hits > 1:
                yield ("say", f"Hit {min(hits, h + 1)} time(s)!")
            if mult > 1:
                yield ("say", "It's super effective!")
                if m.type == "RECEIVER" and user.stages["SPD"] < 6:
                    user.stages["SPD"] += 1
                    yield ("say", f"{m.name} pulled away! SPD rose!")
            elif mult < 1:
                yield ("say", "It's not very effective...")
                if m.type == "PASSING":
                    user.read_defense = True
                if user.sub == "GUNSLINGER":
                    user.no_fear = True
            # passives that fire after a hit
            if m.type == "RUSHING":
                user.momentum = min(3, user.momentum + 1)
            if user.sub == "BELL-COW":
                user.workload = min(4, user.workload + 1)
            user.first_move = False
            # BRUISER: YARDS AFTER CONTACT (checked on the defender)
            if target.sub == "BRUISER" and not target.yac_used and not target.mon.fainted \
                    and target.mon.hp * 5 <= target.mon.max_hp:
                target.yac_used = True
                target.stages["ATK"] = min(6, target.stages["ATK"] + 1)
                target.stages["DEF"] = min(6, target.stages["DEF"] + 1)
                yield ("say", f"{target.mon.name} keeps its legs moving! ATK and DEF rose!")
            if m.type == "D-LINE" and not target.mon.fainted:
                chance = 0.4 if target.mon.type == "PASSING" else 0.25
                if random.random() < chance and target.stages["SPD"] > -6:
                    target.stages["SPD"] -= 1
                    yield ("say", f"The pocket collapses! {target.mon.name}'s SPD fell!")
            if "drain" in eff and total:
                m.hp = min(m.max_hp, m.hp + max(1, int(total * eff["drain"])))
                yield ("hp", user, m.hp)
                yield ("say", f"{m.name} recovered some HP!")
            if "recoil" in eff and total:
                m.hp = max(0, m.hp - max(1, int(total * eff["recoil"])))
                yield ("hp", user, m.hp)
                yield ("say", f"{m.name} is hit with recoil!")
            if "status" in eff and not target.mon.fainted and target.mon.status is None:
                if random.randint(1, 100) <= eff["chance"]:
                    yield from self.apply_status(target, eff["status"])
            if "stat" in eff:
                yield from self.apply_stat(user, target, eff)
            if eff.get("guard"):
                user.guard = True
        else:
            # non-damaging: the LINEBACKER on the other side reads it
            if target.mon.type == "LINEBACKER":
                target.read_react = True
            if user.sub == "PUNTER":
                target.no_spd_boost = True                                       # HANG TIME
            user.first_move = False
            if "heal" in eff:
                if m.hp == m.max_hp and "stat" not in eff:
                    yield ("say", "Its HP is already full!")
                else:
                    m.hp = min(m.max_hp, m.hp + int(m.max_hp * eff["heal"]))
                    yield ("hp", user, m.hp)
                    yield ("say", f"{m.name} regained health!")
            if "stat" in eff:
                yield from self.apply_stat(user, target, eff)
            if "status" in eff:
                if target.mon.status:
                    yield ("say", "But it failed!")
                else:
                    yield from self.apply_status(target, eff["status"])
            if eff.get("guard"):
                user.guard = True
                yield ("say", f"{m.name} braced for impact!")

    def apply_stat(self, user, target, eff):
        who = target if eff.get("target") == "foe" else user
        if who.mon.fainted:
            return
        st, stages = eff["stat"], eff["stages"]
        cur = who.stages[st]
        if st == "DEF" and stages < 0 and who.sub == "BRICK WALL" and cur <= 0:
            yield ("say", f"{who.mon.name} stonewalls it! DEF holds.")
            return
        if st == "SPD" and stages > 0 and who.no_spd_boost:
            who.no_spd_boost = False
            yield ("say", "Hang time! The speed boost fails.")
            return
        if (stages > 0 and cur >= 6) or (stages < 0 and cur <= -6):
            yield ("say", "Nothing happened!")
        else:
            who.stages[st] = max(-6, min(6, cur + stages))
            word = "rose" if stages > 0 else "fell"
            yield ("say", f"{who.mon.name}'s {st} {word}!")

    def apply_status(self, side, status):
        side.mon.status = status
        if status == "GASSED":
            side.mon.sleep_turns = random.randint(1, 3)
        words = {"DAZED": "is dazed!", "CRAMP": "got a cramp!",
                 "GASSED": "is gassed out!", "TURFBURN": "got turf burn!"}
        yield ("say", f"{side.mon.name} {words[status]}")

    def damage(self, user, target, mv):
        L = user.mon.level
        A, D = user.eff_stat("ATK"), target.eff_stat("DEF")
        power = mv["power"]
        # passives that boost power
        if user.mon.type == "RUSHING":
            power *= 1 + 0.1 * user.momentum                          # MOMENTUM
        if user.mon.type == "PASSING" and user.read_defense:
            power *= 1.15                                             # READ THE DEFENSE
            user.read_defense = False
        if user.mon.type == "LINEBACKER" and user.read_react:
            power *= 1.15                                             # READ & REACT
            user.read_react = False
            if user.stages["SPD"] < 6:
                user.stages["SPD"] += 1
        if user.mon.type == "RECEIVER" and self.first_mover is user:
            power *= 1.15                                             # SEPARATION
        eff = mv.get("effect", {})
        # subtype power mods
        if user.sub == "GUNSLINGER" and user.no_fear:
            power *= 1.25; user.no_fear = False                       # NO FEAR
        if user.sub == "ALPHA" and user.first_move and mv["type"] == "RECEIVER":
            power *= 1.2                                              # TARGET SHARE
        if user.sub == "BALL HAWK" and user.jump_route:
            power *= 1.2; user.jump_route = False                     # JUMP THE ROUTE
        if eff.get("walkoff"):
            power *= 1 + (1 - user.mon.hp / user.mon.max_hp)          # WALK-OFF
        crit_chance = 0.25 if eff.get("crit") == "high" else 1 / 16
        if user.clutch():
            crit_chance += 0.10                                       # CLUTCH WINDOW
        if user.sub == "SACK ARTIST" and target.mon.type == "PASSING":
            crit_chance += 0.15                                       # GET-OFF
        if user.sub == "DEEP THREAT" and self.first_mover is user:
            crit_chance += 0.10                                       # TAKE THE TOP OFF (approx.)
        crit = random.random() < min(0.35, crit_chance)
        if crit:
            A, D = user.mon.stat("ATK"), target.mon.stat("DEF")       # crits ignore stages
        base = ((2 * L // 5 + 2) * int(power) * A // D) // 50 + 2
        if mv["type"] == user.mon.type:
            base = int(base * types.SCHEME_FIT)
        mult = types.effectiveness(mv["type"], target.mon.type)
        if mult == 2.0 and mv["type"] == "RECEIVER" and target.sub == "COVERAGE":
            mult = 1.5                                                # HOOK ZONE
        if mult < 1 and user.sub == "FIELD GENERAL" and user.audible:
            mult = 1.0; user.audible = False                          # AUDIBLE
        dmg = base * mult * random.randint(217, 255) / 255
        if crit:
            dmg *= types.CRIT_MULT
        return max(1 if mult else 0, int(dmg)), crit, mult

    # --- fainting, EXP, level ups, evolution ----------------------------
    def handle_faint(self, side):
        m = side.mon
        yield ("faint", side)
        if side is self.enemy:
            who = f"{self.trainer['name']}'s" if self.trainer else "Wild"
            yield ("say", f"{who} {m.name} fainted!")
            yield from self.give_exp()
            if self.trainer:
                yield from self.next_enemy()
            else:
                self.result = "win"
        else:
            yield ("say", f"{m.name} fainted!")
            if self.player.all_fainted():
                if self.trainer:
                    yield ("say", self.trainer["lose"])
                yield ("say", f"{self.player.name} is out of players!")
                yield ("say", f"{self.player.name} blacked out!")
                self.result = "lose"
            else:
                yield ("force_switch",)

    def next_enemy(self):
        t = self.trainer
        self.enemy_index += 1
        if self.enemy_index >= len(self.enemy_party):
            yield ("say", f"{self.player.name} beat {t['name']}!")
            yield ("say", t["win"])
            self.player.cash += t["prize"]
            yield ("say", f"{self.player.name} got ${t['prize']} for winning!")
            self.player.flags["beat_" + t["name"]] = True
            self.result = "win"
            return
        self.wild = self.enemy_party[self.enemy_index]
        self.player.seen.add(self.wild.species)
        self.enemy = Side(self.wild)
        self.enemy.visible = False
        self.ally.momentum = 0
        self.enemy_status_uses = 0
        yield ("say", f"{t['name']} sent out {self.wild.name}!")
        yield ("show", self.enemy)

    def give_exp(self):
        m = self.ally.mon
        amount = creatures.get(self.wild.species)["exp"] * self.wild.level / 7 * settings.EXP_RATE
        if self.trainer:
            amount *= 1.5
        amount = max(1, int(amount))
        yield ("say", f"{m.name} gained {amount} EXP. points!")
        levels = m.gain_exp(amount)
        yield ("exp", self.ally, m.exp)
        for lvl in levels:
            self.ally.shown_hp = m.hp
            yield ("say", f"{m.name} grew to level {lvl}!")
            for new in m.moves_at_level(lvl):
                yield from self.learn_move(m, new)
        evo = m.evolution_due()
        if evo:
            yield ("say", f"What? {m.name} is changing!")
            yield ("hide", self.ally)
            yield ("wait", 30)
            old = m.name
            m.evolve()
            self.player.caught.add(m.species)
            self.player.seen.add(m.species)
            yield ("show", self.ally)
            yield ("say", f"{old} evolved into {m.name}!")
            for new in m.moves_at_level(m.level):
                yield from self.learn_move(m, new)

    def learn_move(self, m, new):
        if any(mv[0] == new for mv in m.moves):
            return
        if m._add_move(new):
            yield ("say", f"{m.name} learned {new}!")
            return
        yield ("say", f"{m.name} wants to learn {new}, but it already knows 4 moves.")
        yield ("say", f"Forget a move to make room for {new}?")
        answer = yield ("learn", m, new)
        if answer and answer[0] == "replaced":
            yield ("say", f"1, 2, and... poof! {m.name} forgot {answer[1]} and learned {new}!")
        else:
            yield ("say", f"{m.name} did not learn {new}.")

    # ------------------------------------------------------------------
    # drawing
    # ------------------------------------------------------------------
    def draw_vs(self, surf):
        t = self.trainer
        surf.fill(gfx.UI["navy"])
        for i in range(0, gfx.W, 8):
            surf.fill(gfx.UI["cobalt"] if (i // 8) % 2 else gfx.UI["red"], (i, 0, 8, 3))
            surf.fill(gfx.UI["cobalt"] if (i // 8) % 2 else gfx.UI["red"], (i, gfx.H - 3, 8, 3))
        slide = max(0, 30 - self.vs_timer * 3)
        spr = gfx.png("trainers", t["name"], 120)
        if spr is not None:
            surf.blit(spr, (gfx.W - 140 + slide, 24))
        else:
            gfx.text_center(surf, gfx.W - 60 + slide, 60, t["name"], gfx.UI["gold"])
        gfx.text(surf, 14, 28, "VS", gfx.UI["gold"])
        gfx.text(surf, 14, 50, t["name"], gfx.UI["white"])
        gfx.text(surf, 14, 62, t["title"][:28], gfx.UI["light"])
        gfx.text(surf, 14, 80, t["team"][:28].upper(), gfx.UI["gold"])
        for i, (sp, lv) in enumerate(t["party"]):
            surf.blit(gfx.creature_sprite(sp, 32), (14 + i * 36, 100))
        gfx.text(surf, 14, 140, f"{len(t['party'])} PLAYERS   PRIZE ${t['prize']}", gfx.UI["light"])
        if (self.frame // 20) % 2 == 0:
            gfx.text(surf, 14, gfx.H - 16, "PRESS Z", gfx.UI["mid"])

    def draw(self, surf):
        if self.pending and self.pending[0] == "vs":
            self.draw_vs(surf)
            return
        scene = getattr(self.game.world, "scene", "field")
        sky, ground = {"field": (gfx.UI["sky"], gfx.UI["field"]),
                       "lot": ((206, 214, 230), (120, 150, 90)),
                       "concourse": ((150, 160, 185), (110, 118, 140)),
                       "night": ((22, 28, 60), (60, 120, 70))}.get(scene, (gfx.UI["sky"], gfx.UI["field"]))
        surf.fill(sky)
        surf.fill(ground, (0, HORIZON, gfx.W, ui.BOX_Y - HORIZON))
        if scene == "night":
            for x in range(20, gfx.W, 60):
                surf.fill((250, 240, 200), (x, 8, 3, 3))
        if scene in ("field", "night"):
            for x in range(0, gfx.W, 40):
                surf.fill((235, 235, 235), (x, HORIZON + 8, 2, ui.BOX_Y - HORIZON - 8))
        # platforms
        surf.fill((80, 150, 60), (ENEMY_POS[0] - 6, ENEMY_POS[1] + SPRITE - 6, SPRITE + 12, 5))
        surf.fill((80, 150, 60), (ALLY_POS[0] - 2, ALLY_POS[1] + SPRITE - 6, SPRITE + 12, 5))
        e = self.enemy
        if e.visible and not (e.flash and (self.frame // 3) % 2):
            surf.blit(gfx.creature_sprite(e.mon.species, SPRITE), self._sprite_pos(e, ENEMY_POS))
        # enemy info panel
        gfx.box(surf, 6, 6, PANEL_W, 32)
        gfx.text(surf, 12, 11, e.mon.name[:12])
        gfx.text_right(surf, PANEL_W, 11, f"L{e.mon.level}")
        gfx.hp_bar(surf, 32, 22, PANEL_W - 40, e.shown_hp, e.mon.max_hp)
        if e.mon.status:
            gfx.text(surf, 12, 29, STATUS_NAMES[e.mon.status], gfx.UI["red"])
        elif e.mon.species in self.player.caught and not self.trainer:
            gfx.text(surf, 12, 29, "*", gfx.UI["gold"])
        if e.momentum:
            gfx.text_right(surf, PANEL_W, 29, f"MOM x{e.momentum}", gfx.UI["cobalt"])
        if self.trainer:
            # remaining balls
            for i, mon in enumerate(self.enemy_party):
                col = gfx.UI["mid"] if mon.fainted else gfx.UI["cobalt"]
                surf.fill(col, (38 + i * 8, 30, 5, 5))
        # ally
        a = self.ally
        if a.visible and not (a.flash and (self.frame // 3) % 2):
            surf.blit(gfx.creature_sprite(a.mon.species, SPRITE, mirror=True), self._sprite_pos(a, ALLY_POS))
        if self.ball_anim:
            self._draw_ball(surf)
        for x, y, _, _, life, col in self.particles:
            sz = 3 if life > 8 else 2
            surf.fill(col, (int(x), int(y), sz, sz))
        px, py = gfx.W - PANEL_W - 6, ui.BOX_Y - 42
        gfx.box(surf, px, py, PANEL_W, 38)
        gfx.text(surf, px + 6, py + 5, a.mon.name[:12])
        gfx.text_right(surf, px + PANEL_W - 6, py + 5, f"L{a.mon.level}")
        gfx.hp_bar(surf, px + 26, py + 16, PANEL_W - 40, a.shown_hp, a.mon.max_hp)
        gfx.text_right(surf, px + PANEL_W - 6, py + 23, f"{max(0, a.shown_hp)}/{a.mon.max_hp}")
        if a.mon.status:
            gfx.text(surf, px + 6, py + 23, STATUS_NAMES[a.mon.status], gfx.UI["red"])
        if a.momentum:
            gfx.text(surf, px + 6, py + 23, f"MOM x{a.momentum}", gfx.UI["cobalt"])
        lo, hi = a.mon.level ** 3, (a.mon.level + 1) ** 3
        gfx.bar(surf, px + 6, py + 31, PANEL_W - 12, (a.shown_exp - lo) / (hi - lo) if hi > lo else 0, thickness=1, kind="exp")
        # bottom area
        if self.phase == "menu":
            self.text.draw(surf, self.frame)
            gfx.text(surf, 8, ui.BOX_Y + 14, "WHAT WILL")
            gfx.text(surf, 8, ui.BOX_Y + 26, a.mon.name[:10] + " DO?")
            self.menu.draw(surf)
        elif self.phase == "fight":
            gfx.box(surf, 0, ui.BOX_Y, gfx.W - 100, 48)
            self.menu.draw(surf)
            mv = movedata.get(a.mon.moves[self.menu.index][0])
            gfx.box(surf, gfx.W - 100, ui.BOX_Y, 100, 48)
            gfx.type_badge(surf, gfx.W - 92, ui.BOX_Y + 8, mv["type"])
            gfx.text(surf, gfx.W - 92, ui.BOX_Y + 22, "PP")
            gfx.text(surf, gfx.W - 92, ui.BOX_Y + 32, f"{a.mon.moves[self.menu.index][1]:>2}/{mv['pp']:<2}")
            gfx.text_right(surf, gfx.W - 8, ui.BOX_Y + 32, f"PWR {mv['power']}" if mv["power"] else "STATUS", gfx.UI["mid"])
        elif self.phase in ("bag", "team", "bag_target"):
            self.text.draw(surf, self.frame)
            self.menu.draw(surf)
            if self.phase == "bag" and self.bag_names:
                gfx.box(surf, 0, ui.BOX_Y + 16, gfx.W, 32)
                gfx.text(surf, 8, ui.BOX_Y + 28, itemdata.get(self.bag_names[self.menu.index])["desc"])
        else:
            self.text.draw(surf, self.frame)
            if self.submenu and self.submenu[0] == "learn":
                self.submenu[3].draw(surf)

    def _sprite_pos(self, side, base):
        x, y = base[0] + side.offset, base[1]
        if side.shake:
            x += (-3, 3, -2, 2)[side.shake % 4]
        if side.drop:
            y += side.drop
        if side.pop:
            y -= (side.pop * side.pop) // 12          # little hop in on entry
        elif side is self.ally and not side.shake:
            y += 1 if (self.frame // 30) % 2 else 0   # idle breathing bob
        if self.screen_shake:
            x += (-2, 2, -1, 1)[self.screen_shake % 4]
            y += (1, -1, 1, -1)[self.screen_shake % 4]
        return (x, y)

    def _draw_ball(self, surf):
        b = self.ball_anim
        t = b["t"]
        ball = gfx.art(sprites.BALL, palette=[(255, 255, 255), gfx.UI["gold"], (150, 85, 40), (60, 30, 15)], key="BALL")
        if t % 8 < 4:
            ball = gfx.art(sprites.BALL, palette=[(255, 255, 255), gfx.UI["gold"], (150, 85, 40), (60, 30, 15)], mirror=True, key="BALL")
        ex, ey = ENEMY_POS[0] + SPRITE // 2 - 4, ENEMY_POS[1] + SPRITE - 20
        if t < 20:
            f = t / 20
            sx, sy = ALLY_POS[0] + 50, ALLY_POS[1] + 30
            x = sx + (ex - sx) * f
            y = sy - 60 * (1 - (2 * f - 1) ** 2)
            surf.blit(ball, (int(x), int(y)))
            return
        x, y = ex, ey
        s = t - 40
        if s >= 0:
            k = s // 30
            if k < b["shakes"]:
                ph = (s % 30)
                x += [0, -2, -3, -2, 0, 2, 3, 2][(ph // 2) % 8] if ph < 16 else 0
        surf.blit(ball, (x, y))
